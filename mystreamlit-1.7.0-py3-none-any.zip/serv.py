# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-12-09 16:31:21
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-12-09 17:03:06
#服务器
import socket
import struct
server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.bind(("127.0.0.1",3008))
server.listen(3)
while True:
    print("start......")
    sock,adddr = server.accept()
    total_data = b''
    num = 0
    data = sock.recv(1024)
    total_data += data
    num =len(data)
    # 如果没有数据了，读出来的data长度为0，len(data)==0
    print(22222222222222,data)
    while len(data)>0:
        data = sock.recv(1024)
        num +=len(data)
        total_data += data
    with open("hadoop-2.10.1.tar.gz","wb") as f:
        f.write(total_data)
    sock.close()
sock.close()