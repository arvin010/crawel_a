from swgmodel.doc.dochomepage import *
import json
from interviews import *

class DocHomePage(RequestHandlers):
    """
       文档说明--配置篇
    """
    resdata = {"result": False, "message": 'successful', 'context': None}
    @certifyException
    async def get(self):
        """
            ---
            tags:
            - Document
            summary: Document Home Page API 文档说明--配置篇(首页)
            description: document home page operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """
        # 来源构建字典
        rest = [
            {"par1": "1. 统计日期默认是当日2.CPU和内存使用率是否可以区分到模型，待fuzi确认？3. fuzi确认调用次数要不要区分成功和失败的折线？"
                     "4、所有人进来看到的都是全部模型吗，还是只能看到自己所在团队的所有的模型"},
            {"par2": "查询编码是后台自动生成的，就是查询结果表名称；数据源编码是从数据源配置中提取的列表 查询的条件：就是参数名称列表"}
        ]
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'doc config ', 'code': self.get_status(), 'rest': rest}


