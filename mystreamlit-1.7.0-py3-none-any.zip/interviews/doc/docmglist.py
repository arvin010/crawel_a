from interviews import *
import json


class DocMGList(RequestHandlers):
    """
       文档说明--模型列表
    """
    resdata = {"result": False, "message": 'successful', 'context': None}
    @certifyException
    async def get(self):
        """
            ---
            tags:
            - Document
            summary: Doc Model Group List API 文档说明--模型列表
            description: Doc model group list operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """
        # 来源构建字典
        rest = [
            {"label1": "打开界面默认显示我有权限看到的模型（也就是我所在团队对应的模型组的模型）。默认相同模型组的模型排在一起。"
                     "相同模型组的有权限编辑的排在前面。"},
            {"label2": "+点击展示该模型下所有版本信息。-点击收起模型版本信息，仅显示模型记录。"},
            {"label3": "发布模型版本的人可以编辑该模型、新建/编辑/下线模型版本。团队成员可以查看所属团队关联的模型组里面的"
                     "模型和模型版本配置情况，但没法编辑、运行、发布。模型下线：支持填写下线时间。下线时间可更新。比如下线"
                     "时间是2021-9-1，那么从2021-9-01 00：00：00开始无法提供服务。"},
            {"label4": "文档说明内容4"},
        ]
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'doc config ', 'code': self.get_status(), 'rest': rest}


