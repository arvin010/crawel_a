from swgmodel.doc.docruns import *
import json
from interviews import *

class DocRuns(RequestHandlers):
    """
       文档说明--运行篇
    """
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def get(self):
        """
            ---
            tags:
            - Document
            summary: Document Runs API 文档说明--运行篇
            description: document runs operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """
        # 来源构建字典
        rest = [
            {"state": "状态：已发布、测试通过、测试失败、未测试。填写参数、选择文件包位置互换。删除发布界面。删除选择文件包。执行按钮、发布按钮放到当前状态后面"},
            {"par2": "内容2"},
            {"par3": "内容3"}
        ]

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'doc config ', 'code': self.get_status(), 'rest': rest}



