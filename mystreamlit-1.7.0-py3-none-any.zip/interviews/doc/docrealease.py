from swgmodel.doc.docrealease import *
from swgmodel.resultmodel import *
import json
from interviews import *


class DocRealease(RequestHandlers):
    """
       文档说明--发布篇
    """
    resdata = {"result": False, "message": 'successful', 'context': None}
    @certifyException
    async def get(self):
        """
            ---
            tags:
            - Document
            summary: Document Realease API 文档说明--发布篇
            description: document realease operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """
        # 来源构建字典
        rest = [
            {"par1": "文档说明 内容1"},
            {"par2": "文档说明 内容2"},
            {"par3": "文档说明 内容3"}
        ]

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'doc config ', 'code': self.get_status(), 'rest': rest}



