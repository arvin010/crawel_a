from swgmodel.doc.docconfig import *
import json
from interviews import *


class DocConfig(RequestHandlers):
    """
       文档说明--配置篇
    """
    resdata = {"result": False, "message": 'successful', 'context': None}
    @certifyException
    async def get(self):
        """
            ---
            tags:
            - Document
            summary: Document Config API 文档说明--配置篇
            description: document config api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """
        # try:
        # 来源构建字典
        rest = [
            {"modelrealeasecode": "模型发布编码由应用场景appcode、用户部门depcode、模型场景buscode、模型细类modelclass四个参数构成"},
            {"stepbar": "步骤条的对应模块填了，步骤条节点变成绿色。否则是灰色。当前鼠标焦点所在模块，对应步骤条节点是蓝色"},
            {"qureycode": "查询编码是后台自动生成的，就是查询结果表名称；数据源编码是从数据源配置中提取的列表 查询的条件：就是参数名称列表"},
            {"filepackageconfig": "1、左边文件可以拖拽或选中点击图标> 变到右边。右边反之亦然，右边变到左边后，对应的流程分配值就没了 2 左边的文件名来自模型配置上传的文件列表"},
            {"rfc": "注意流量分配加总必须等于1"},
        ]

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'doc config ', 'code': self.get_status(), 'rest': rest}


