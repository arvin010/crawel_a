from interviews import *
import json


class DocMGManagement(RequestHandlers):
    """
       文档说明--模型管理组
    """
    resdata = {"result": False, "message": 'successful', 'context': None}
    @certifyException
    async def get(self):
        """
            ---
            tags:
            - Document
            summary: Doc Model Group Managentment API 文档说明--模型管理组
            description: Doc model group managentment operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """
        # 来源构建字典
        rest = [
            {"par1": "1、超级管理员和模型组所属的团队的团队长才有编辑和删除权限。其中，团队长只能编辑和删除自己的团队的模型组。超级管理员可以编辑和删除所有模型组。2、团队成员只能查看模型组信息"},
            {"par2": "文档说明 内容2"},
        ]
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'doc config ', 'code': self.get_status(), 'rest': rest}


