from swgmodel.mconf.modelgroups import *
import json
from interviews import *
from interviews.mconf.models import Models


class ModelGroups(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}
    tablename='model_groups'

    @authException
    async def post(self, id):
        """
            ---
            tags:
            - ModelConfig
            summary: Model Groups API 模型组表
            description: model groups operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
                -   in: path
                    name: id
                    description: ID of post to get
                    required: true
                    type: string
                -   in: body
                    name: body
                    description: post data
                    required: true
                    schema:
                        type: array
                        items:
                            $ref: '#/definitions/ModelGroupsPostModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'modelgroup'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        col_list=self.mysql.desc(tablename='models')[1:-2]
        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, f'{key} is required');break
            if not idlist[inx]: self.set_status(202, f'empty {key}');break
            mdgroup_str = f"{row['appcode']}{row['depcode']}{row['buscode']}{row['modelclass']}"
            modelgroup=self.mysql.fetch_one(tablename='model_groups',field='modelgroup',condition=f"where modelgroup ='{mdgroup_str}'")
            #  check modelgroup
            if row['modelgroup'] != mdgroup_str :
                self.set_status(201, 'checkout error')
                break
            rest.append(insert_(self,tablename='model_groups',key='modelgroup',value=mdgroup_str,item=row))
            if not modelgroup:
                res=Models.gen_modelcode(self,row=row,col_list=col_list)
                if not res: self.set_status(202);break
        data={'type': 'get', 'desc': 'modelgroup', 'code': self.get_status(), 'rest': [mdgroup_str], 'idlist': [1]}
        return res

    @authException
    async def get(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Groups API 模型组表
        description: model groups operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: id
            description: ID of post to get
            required: true
            type: string
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        id = id.split('=', 1)[1].strip()
        idlist = rest = []
        if id:
            idlist = id.split(',') if ',' in id else [id]
            rest=get_(self,tablename=self.tablename,key=key,value=id)
        else:
            self.set_status(500, 'require id')
        return {'type': 'get', 'desc': 'id', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def delete(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Groups API 模型组表
        description: model groups operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelGroupsDeleteModel'
        """
        _params = json.loads(self.request.body)
        rest = idlist = []
        for item in _params:
            if ['id'] != list(item.keys()):
                self.set_status(500, 'params error')
                break
            idlist = item['id'].split(',') if ',' in item['id'] else [item['id']]
            for i in idlist:
                if not i: self.set_status(202, 'empty id'); break
                condition = 'where id={id}'.format(id=i)
                rest.append(self.mysql.delete_one(tablename='model_groups', condition=condition))
        rest = [i for i in rest if i]
        return {'type': 'delete', 'desc': 'id', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Groups API 模型组表
        description: model groups operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelGroupsPatchModel'
        """
        _params = json.loads(self.request.body)
        rest = []
        # 过滤前端参数
        for p in _params:
            for i in list(p['content'].keys()):
                if i not in self.mysql.desc(tablename='model_groups')[1:-2]:
                    p['content'].pop(i)
        idlist = [item.setdefault('id', None) for item in _params]
        for item in _params:
            if item.setdefault('id', None) == None: self.set_status(500, 'params error'); break
            if item['id']:
                field = ','.join(
                    ["{k}= null".format(k=k, v=v) if v == 'None' else "{k}='{v}'".format(k=k, v=v) for k, v in
                     item['content'].items()])
                rest.append(self.mysql.update_one(tablename='model_groups', field=field,
                                             condition="where id={id}".format(id=item['id'])))
            else:
                self.set_status(202, 'empty id')
                break
        rest = [i for i in rest if i]
        return {'type': 'patch', 'desc': 'id', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}