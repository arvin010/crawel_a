from swgmodel.mconf.modelrelease import *
import json
from interviews import *
from dccdatetime import DccDatetime
from time import time


class ModelRelease(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}
    _dccdatetime=DccDatetime()
    tablename='model_release'

    @authException
    async def post(self, id):
        """
            ---
            tags:
            - ModelConfig
            summary: Model Release API 模型发布表
            description: model release operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
                -   in: path
                    name: id
                    description: ID of post to get
                    required: true
                    type: string
                -   in: body
                    name: body
                    description: post data
                    required: true
                    schema:
                        type: array
                        items:
                            $ref: '#/definitions/ModelReleasePostModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'rlcode'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, f'{key} is required');break
            if not idlist[inx]: self.set_status(202, f'empty {key}');break
            rlstatus = self.mysql.fetch_all(tablename='model_release', field='rlstatus',condition=f'''where filepkgcode="{row.get('filepkgcode',None)}"''')[0]['rlstatus']
            row['rlstatus']=rlstatus if rlstatus and rlstatus.lower()!="none" else 'newdev'
            rest.append(insert_(self,tablename=self.tablename,key=key,value=idlist[inx],item=row,col_list=['rlcode','filepkgcode','rlstatus','verdesc']))
        return {'type': 'post', 'desc': f'{key} ', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}


    @staticmethod
    def gen_rlcode(self,modelcode=None):
        max=self.mysql.fetch_all(tablename='model_release',field='count(1) num',condition=f"where rlcode like '{modelcode}%' ")[0]['num']
        rlcode=f"{modelcode}_v{int(max)+1}"
        filepkgcode=f"{rlcode}_pkg_{int(time())}"
        row={'rlcode':rlcode,'filepkgcode':filepkgcode,'rlstatus':'newdev','operator':self._current_user}
        rest=self.mysql.insert_many(tablename='model_release', col_list=list(row.keys()), value_list=[[
            row.get(col,None) if col!='operator' else self._current_user for
            col in list(row.keys())]])
        return rest,rlcode,filepkgcode


    @authException
    async def get(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Release API 模型发布表
        description: model release operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: id
            description: ID of post to get
            required: true
            type: string
        """
        if '?' in id: id=id.split('?',1)[0].strip()
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        id = id.split('=', 1)[1].strip()
        idlist = rest = []
        if id:
            idlist = id.split(',') if ',' in id else [id]
            rest=get_(self,tablename=self.tablename,key=key,value=id)
        else:
            self.set_status(500, 'require id')
        return {'type': 'get', 'desc': 'id', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def delete(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Release API 模型发布表
        description: model release operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelReleaseDeleteModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = idlist = []
        for item in _params:
            if [key] != list(item.keys()): self.set_status(500, 'params error'); break
            idlist = item[key].split(',') if ',' in item[key] else [item[key]]
            for i in idlist:
                if not i: self.set_status(202, f'empty {key}'); break
                rest.append(self.mysql.delete_many(tablename=self.tablename, condition=f"where {key}='{i}'"))
        rest = [i for i in rest if i]
        return {'type': 'delete', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Release API 模型发布表
        description: model release operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelReleasePatchModel'

        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        for item in _params:
            if item.setdefault(key, None) == None: self.set_status(500, 'params error'); break
            if item.get(key,None):
                if item.get('rlstatus',None)=='beta':item['betatime']=self._dccdatetime.now()
                rest.append(update_(self,tablename=self.tablename,item=item,key=key,col_list=self.mysql.desc(tablename=self.tablename)[1:-2]))
            else:
                self.set_status(202, f'empty {key}')
                break
        rest = [i for i in rest if i]
        return {'type': 'patch', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}