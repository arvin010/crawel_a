from swgmodel.mconf.mparmsquery import *
import json
from interviews import *


class ModelParamQuery(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}
    tablename='model_parmas_query'

    @authException
    async def post(self,id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Param Query API 模型外部数据查询配置
        description: model param Query operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelParamQueryPostModel'

        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'rlcode'
        _params = json.loads(self.request.body)
        rest = [];desc=''
        idlist = [item.setdefault('rlcode', None) for item in _params]
        for inx, row in enumerate(_params):
            if not idlist[inx] or list(filter(lambda x: not row.get(x,None),['dscode','table_name','where_condition','datatype','sn'])) or row.get('isreq',None)==None:
                desc=f"【数据源编码、源表表名、查询条件、返回字段、是否必须、查询顺序】 不能有空";self.set_status(207);break
            if not idlist[inx]: self.set_status(202, 'empty rlcode');break
            row['datatype']={key.upper():val for key,val in row['datatype'].items()}
            row['cols']=','.join(list(row['datatype'].keys()))
            row['datatype']=json.dumps(row["datatype"]) if isinstance(row['datatype'],dict) else row['datatype']
            rest.append(insert_(self,tablename=self.tablename,key=key,key2='qrcode',item=row))
        return {'type': 'post', 'desc': f'{desc} ', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def get(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Param Query API 模型外部数据查询配置
        description: model param Query operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: id
            description: ID of post to get
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/ModelParamQueryGetModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        id = id.split('=', 1)[1].strip()
        idlist = rest = []
        if id:
            idlist = id.split(',') if ',' in id else [id]
            rest=get_(self,tablename=self.tablename,key=key,value=id)
        else:
            self.set_status(500)
        return {'type': 'get', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def delete(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Param Query API 模型外部数据查询配置
        description: model param Query operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: ID of post to delete
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelParamQueryDeleteModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = idlist = []
        for item in _params:
            if key not in list(item.keys()): self.set_status(500, 'params error');break
            idlist = str(item[key]).split(',') if ',' in str(item[key]) else [str(item[key])]
            for i in idlist:
                if not i: self.set_status(202, 'empty id'); break
                rest.append(self.mysql.delete_many(tablename=self.tablename, condition=f"where {key}='{i}'"))
        rest = [i for i in rest if i]
        return {'type': 'delete', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Param Query API 模型外部数据查询配置
        description: model param Query operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelParamQueryPatchModel'

        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        for item in _params:
            if item.setdefault(key, None) == None: self.set_status(500, 'params error'); break
            if item[key]:
                rest.append(update_(self,tablename=self.tablename,item=item,key=key,col_list=self.mysql.desc(tablename=self.tablename)[1:-2]))
            else:
                self.set_status(202)
                break
        rest = [i for i in rest if i]
        return {'type': 'patch', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

