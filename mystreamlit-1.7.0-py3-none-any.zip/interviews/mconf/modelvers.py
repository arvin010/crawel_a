from swgmodel.mconf.modelvers import *
import json
from interviews import *


class ModelVers(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}
    tablename='model_vers'

    @authException
    async def post(self, id):
        """
            ---
            tags:
            - ModelConfig
            summary: Model Vers API 模型版本管理
            description: model vers operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
                -   in: path
                    name: id
                    description: ID of post to get
                    required: true
                    type: string
                -   in: body
                    name: body
                    description: post data
                    required: true
                    schema:
                        type: array
                        items:
                            $ref: '#/definitions/ModelVersPostModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'modelcode'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, f'{key} is required');break
            if not idlist[inx]: self.set_status(202, f'empty {key}');break
            rest.append(insert_(self,tablename=self.tablename,key=key,value=idlist[inx],item=row))
        return {'type': 'post', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}


    @staticmethod
    async def gen_rlcode(self,modelcode=None,col_list=None):
        max=max_(self,tablename='model_vers',field='modelvers',condition=f"where modelcode = '{modelcode}'")
        rlcode=f"{modelcode}_v{int(max)+1}"
        row={'modelcode':modelcode,'modelvers':int(max)+1,'rlcode':rlcode,'rlstatus':'newdev'}
        rest=self.mysql.insert_many(tablename='model_vers', col_list=col_list, value_list=[[
            row.get(col,None) if col!='operator' else self._current_user  for
            col in col_list]])
        return rest,rlcode

    @authException
    async def get(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Vers API 模型版本管理
        description: model vers operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
        """
        if '?' in id: id=id.split('?',1)[0].strip()
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        id = id.split('=', 1)[1].strip()
        idlist = rest = []
        if id:
            idlist = id.split(',') if ',' in id else [id]
            rest=get_(self,tablename=self.tablename,key=key,value=id)
        else:
            self.set_status(500, f'require {key}')
        return {'type': 'get', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}


    @authException
    async def delete(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Vers API 模型版本管理
        description: model vers operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelVersDeleteModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = idlist = []
        for item in _params:
            if [key] != list(item.keys()):self.set_status(500, 'params error');break
            idlist = item[key].split(',') if ',' in item[key] else [item[key]]
            for i in idlist:
                if not i: self.set_status(202, f'empty {key}'); break
                rest.append(self.mysql.delete_many(tablename=self.tablename, condition=f"where {key}='{i}'"))
        rest = [i for i in rest if i]
        return {'type': 'delete', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Vers API 模型版本管理
        description: model vers operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelVersPatchModel'

        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        for item in _params:
            if item.setdefault(key, None) == None: self.set_status(500, 'params error'); break
            if item[key]:
                rest.append(update_(self,tablename=self.tablename,item=item,key=key,col_list=self.mysql.desc(tablename=self.tablename)[1:-2]))
            else:
                self.set_status(202, f'empty {key}')
                break
        rest = [i for i in rest if i]
        return {'type': 'patch', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}