from swgmodel.mconf.mparams import *
import json
from interviews import *


class ModelParams(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}
    tablename='model_params'

    @authException
    async def post(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Params API 模型参数配置表
        description: model params operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelParamsPostModel'

        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'rlcode'
        _params = json.loads(self.request.body)
        rest = [];desc=''
        idlist = [item.setdefault(key, None) for item in _params]
        pname=[item.get('pname',None) for item in _params]
        if len(pname)!=len(set(pname)):
            desc='参数名称有重复';self.set_status(207)
        else:
            for inx,row in enumerate(_params):
                if not idlist[inx] or list(filter(lambda x: not row.get(x,None),['pdatatype','pname'])) or  row.get('isreq',None)==None or  row.get('isformodel',None)==None :
                    desc=f"【参数名称、数据类型、api是否必须输入、是否模型输入】 不能有空"
                    self.set_status(207);break
                if not idlist[inx]: self.set_status(202,f'empty {key}');break
                rest.append(insert_(self,tablename=self.tablename,key=key,key2='pname',item=row))
        return {'type': 'post', 'desc': f'{desc}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def get(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Params API 模型参数配置表
        description: model params operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: id
            description: ID of post to get
            required: true
            type: string
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        id = id.split('=', 1)[1].strip()
        idlist = rest = []
        if id:
            idlist = id.split(',') if ',' in id else [id]
            rest=get_(self,tablename=self.tablename,key=key,value=id)
        else:
            self.set_status(500, f'require {key}')
        return {'type': 'get', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def delete(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Params API 模型参数配置表
        description: model params operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelParamsDeleteModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = idlist = []
        for item in _params:
            if key not in list(item.keys()): self.set_status(500, 'params error');break
            idlist = str(item[key]).split(',') if ',' in str(item[key]) else [str(item[key])]
            for i in idlist:
                if not i: self.set_status(202, f'empty {key}'); break
                condition = f"where {key}='{i}'"
                rest.append(self.mysql.delete_many(tablename=self.tablename, condition=condition))
        rest = [i for i in rest if i]
        return {'type': 'delete', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model Params API 模型参数配置表
        description: model params operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: ID of post to get
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelParamsPatchModel'

        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        for item in _params:
            if item.setdefault(key, None) == None: self.set_status(500, 'params error'); break
            if item[key]:
                rest.append(update_(self,tablename=self.tablename,item=item,key=key,col_list=self.mysql.desc(tablename=self.tablename)[1:-2]))
            else:
                self.set_status(202, f'empty {key}')
                break
        rest = [i for i in rest if i]
        return {'type': 'patch', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}
