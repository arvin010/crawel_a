from interviews import *
from swgmodel.mconf.teamusers import *
import json


class Teamusers(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @authException
    async def post(self, id):
        """
            ---
            tags:
            - ModelConfig
            summary: Teamusers API 团队成员表
            description: teamusers operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/TeamusersPostModel'
        """
        # try:
        _params = json.loads(self.request.body)
        rest = []
        # 过滤前端多余参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.mysql.desc(tablename='teamusers')[1:-2]:
                    p.pop(i)
        idlist = [item.setdefault('teamcode', None) for item in _params]
        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, '[teamcode] is required');break
            if not idlist[inx]: self.set_status(202, 'empty teamcode');break
            if not isinstance(int(row['enable']), int): break  # 校验enable是否整数
            rest.append(
                self.mysql.insert_many(tablename='teamusers', col_list=list(row.keys()), value_list=[list(row.values())]))
        return {'type': 'post', 'desc': 'teamcode', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def get(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Teamusers API 团队成员表
        description: teamusers operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: id
            description: ID of post to get
            required: true
            type: string
        """
        # try:
        id = id.split('=', 1)[1].strip()
        idlist = rest = []
        if id:
            idlist = id.split(',') if ',' in id else [id]
            if idlist[0] == '*':
                rest = self.mysql.fetch_all(tablename='teamusers')
            else:
                rest = [self.mysql.fetch_all(tablename='teamusers', condition='where id="{id}" '.format(id=id)) for id in
                        idlist]
            # 区分id = */单id/多id返回前端输出格式
            if len(rest) != 1 and idlist[0] != '*':
                rest = [i[0] for i in rest if i]
            elif idlist[0] == '*':
                rest = rest
            else:
                rest = rest[0]
        else:
            self.set_status(500, 'require id')
        return {'type': 'get', 'desc': 'id', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def delete(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Teamusers API 团队成员表
        description: teamusers operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/TeamusersDeleteModel'
        """
        _params = json.loads(self.request.body)
        rest = idlist = []
        for item in _params:
            if ['id'] != list(item.keys()):
                self.set_status(500, 'params error')
                break
            idlist = item['id'].split(',') if ',' in item['id'] else [item['id']]
            for i in idlist:
                if not i: self.set_status(202, 'empty id'); break
                condition = 'where id={id}'.format(id=i)
                rest.append(self.mysql.delete_one(tablename='teamusers', condition=condition))
        rest = [i for i in rest if i]
        return {'type': 'delete', 'desc': 'id', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Teamusers API 团队成员表
        description: teamusers operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:

        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/TeamusersPatchModel'

        """
        _params = json.loads(self.request.body)
        rest = []
        # 过滤前端参数
        for p in _params:
            for i in list(p['content'].keys()):
                if i not in self.mysql.desc(tablename='teamusers')[1:-2]:
                    p['content'].pop(i)
        idlist = [item.setdefault('id', None) for item in _params]
        for item in _params:
            if item.setdefault('id', None) == None: self.set_status(500, 'params error'); break
            if item['id']:
                field = ','.join(
                    ["{k}= null".format(k=k, v=v) if v == 'None' else "{k}='{v}'".format(k=k, v=v) for k, v in
                     item['content'].items()])
                rest.append(self.mysql.update_one(tablename='teamusers', field=field,
                                            condition="where id={id}".format(id=item['id'])))
            else:
                self.set_status(202, 'empty id')
                break
        rest = [i for i in rest if i]
        return {'type': 'patch', 'desc': 'id', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}
