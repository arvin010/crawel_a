from swgmodel.mconf.items import *
import json
from interviews import *


class Items(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @authException
    async def get(self):
        """
        ---
        tags:
        - ModelConfig
        summary: Items API 配置项
        description: items operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        res_dict = []
        # 获取item icode 分组数据
        rest = self.mysql.fetch_all(tablename='items i', field='i.item, i.itemname, i2.icode', condition='left join (SELECT \
            item, GROUP_CONCAT(`icode`)as icode from mpp.items group by item) i2 on i.item = i2.item')
        for i in rest:
            if i['item'] != 'teamcode':
                res_dict.append({'item': i['item'], 'itemname': i['itemname'], 'icode': i['icode'].split(',')})

        if res_dict:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return  {'type': 'get', 'desc': 'items', 'code': self.get_status(), 'rest': res_dict, 'idlist': [1,1,1]}






