from swgmodel.mconf.filepackage import *
import json
from interviews import *


class FilePackage(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}
    tablename='file_package'

    @authException
    async def post(self, id):
        """
            ---
            tags:
            - ModelConfig
            summary: Model File Package API 模型文件包
            description: model file package operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
                -   in: path
                    name: id
                    description: ID of post to get
                    required: true
                    type: string
                -   in: body
                    name: body
                    description: post data
                    required: true
                    schema:
                        type: array
                        items:
                            $ref: '#/definitions/FilePackagePostModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'rlcode'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, f'{key} is required');break
            if not idlist[inx]: self.set_status(202, f'empty {key}');break
            rest.append(insert_(self,tablename=self.tablename,key=key,value=idlist[inx],item=row))
        return {'type': 'post', 'desc': f'{key} ', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}


    @staticmethod
    async def gen_fpkgcode(self,rlcode=None,col_list=None):
        max=max_(self,tablename='file_package',field='filepkgvers',condition=f"where rlcode='{rlcode}'")
        filepkgcode=f"{rlcode}_fpkg_{int(max)+1}"
        filepkgvers=int(max)+1
        row={'filepkgcode':filepkgcode,'filepkgvers':filepkgvers,'rlcode':rlcode,'enable':0}
        rest=self.mysql.insert_many(tablename='file_package', col_list=col_list, value_list=[[
            row.get(col,None) if col!='operator' else self._current_user for
            col in col_list]])
        return rest,filepkgcode,filepkgvers

    @authException
    async def get(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model File Package API 模型文件包
        description: model file package operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: id
            description: ID of post to get
            required: true
            type: string
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        id = id.split('=', 1)[1].strip()
        idlist = rest = []
        if id:
            idlist = id.split(',') if ',' in id else [id]
            rest=get_(self,tablename=self.tablename,key=key,value=id)
        else:
            self.set_status(500, f'require {key}')
        return {'type': 'get', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def delete(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model File Package API 模型文件包
        description: model file package operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/FilePackageDeleteModel'
        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = idlist = []
        for item in _params:
            if [key] != list(item.keys()):self.set_status(500, 'params error'); break
            idlist = item[key].split(',') if ',' in item[key] else [item[key]]
            for i in idlist:
                if not i: self.set_status(202, 'empty id'); break
                rest.append(self.mysql.delete_many(tablename=self.tablename, condition=f"where {key}='{i}'"))
        rest = [i for i in rest if i]
        return {'type': 'delete', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - ModelConfig
        summary: Model File Package API 模型文件包
        description: Model File Package operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
            -   in: path
                name: id
                description: ID of post to get
                required: true
                type: string
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/FilePackagePatchModel'

        """
        key=id.split('=',1)[0].strip() if id.split('=',1)[0].strip() else 'id'
        _params = json.loads(self.request.body)
        rest = []
        idlist = [item.setdefault(key, None) for item in _params]
        for item in _params:
            if item.setdefault(key, None) == None: self.set_status(500, 'params error'); break
            if item[key]:
                rest.append(update_(self,tablename=self.tablename,item=item,key=key,col_list=self.mysql.desc(tablename=self.tablename)[1:-2]))
            else:
                self.set_status(202, f'empty {key}')
                break
        rest = [i for i in rest if i]
        return {'type': 'patch', 'desc': f'{key}', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}