from interviews import *
from swgmodel.ui.getmodellist import *
import json


class GetTeams(RequestHandlers):
    resdata = {"result": False,  "message": 'successful', 'context': None}
    @certifyException
    async def get(self, aduser):
        """
        ---
        tags:
        - UI
        summary: GetModelGroupList API 获取模型组信息
        description: get model list operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: aduser
            description: aduser of post to get
            required: true
            type: string
        """
        if '?' in aduser:aduser=aduser.split('?',1)[0]
        aduser = aduser.split('=', 1)[-1].strip()
        res = self.mysql.fetch_all(tablename='teamusers tu', field='distinct tu.teamcode,t.teamname', condition=f"join teams t on t.teamcode =tu.teamcode  where aduser ='{aduser}'  and tu.enable =1 ") if aduser else []
        rest=[]
        for dic in res:
            if any(str(d.get('teamcode',None)).lower()==str(dic.get('teamcode',None)).lower() for d in rest):
                pass
            else:
                rest.append(dic)
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'aduser ', 'code': self.get_status(), 'rest': rest}






