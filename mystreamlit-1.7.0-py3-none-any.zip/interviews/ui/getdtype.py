from swgmodel.ui.getteamname import *
import json
from interviews import *


class GetDtype(RequestHandlers):
    resdata = {"result": False,  "message": 'successful', 'context': None}
    dtype={
        'tianying:underwrite_risk_contral_model':{'RISKNAME':'str','MANAGECOM':'str','INSUREDSEX':'str','PAYMODE':'str','SIGNCOM':'str','SALECHNL':'str',
                                                  'SPECIALCONTTYPE':'str','DELIVERYMETHOD':'str','SALECHNL1':'str','SALECHNL2':'str','SALECHNL3':'str',
                                                  'CHNL_8CODE':'str','CUSTOMER_APPNTSEX':'str','CUSTOMER_IDTYPE':'str','CUSTOMER_MARRIAGE':'str','CUSTOMER_SMOKEFLAG':'str',
                                                  'CALLCENTER':'str','CARDTYPE':'str','CAMPAIGNTYPE':'str','REGIONAL':'str','CITY':'str','PRODUCTTYPE':'str','PRODUCTSUBTYPE':'str',
                                                  'SUBCHANNEL':'str','SPONSORNAME':'str','BIZUNITCODE':'str','PROSPECTSOURCE':'str','PROSPECTTYPE':'str','CVMORNOT':'str','VIPTYPE':'str',
                                                  'VIPGRADE':'str','RELATIONTOAPPNT':'str','INSURED_MARRIAGE':'str','INSURED_IDTYPE':'str','INSURED_SMOKEFLAG':'str','CUSTOMER_SENSITIVECODE':'str',
                                                  'TAXIDENTITY':'str','BEFDISRESULT':'str','CUSTOMERTYPE':'str','SUMSCORE':'str','CUSTOMERLEVEL':'str','PAYENDYEARFLAG':'str','INSUYEARFLAG':'str',
                                                  'INSURED_AGE':'float','PAYINTV1':'float','PREM1':'float','AMNT1':'float','CUSTOMER_AGE':'float','PREMBUDGET':'float','A_SUM_CON':'float',
                                                  'A_CRIT_POL':'float','B_SUM_CON':'float','B_CRIT_POL':'float','SUSPICIOUSTYPE':'float','EXCEPTIONCODE':'float','DISEASECODE':'float',
                                                  'N_POLNO':'float','N_MAINPOLNO':'float','N_ADDPOLNO':'float','N_RISKCODE':'float','M_PAYENDYEAR':'float','M_INSUYEAR':'float','M_FLOATRATE':'float',
                                                  'M_MULT':'float','S_SUMPREM':'float','S_RISKAMNT':'float','M_CLAIMTIMES':'float','H_RNEWFLAG':'float','S_RISKTYPE_H1':'float','S_RISKTYPE_H2':'float',
                                                  'S_RISKTYPE_L1':'float','S_RISKTYPE_L2':'float','S_RISKTYPE_L3':'float','S_RISKTYPE_R1':'float','S_RISKTYPE_R2':'float','S_RISKPERIOD_L':'float',
                                                  'S_RISKPERIOD_M':'float','S_RISKPERIOD_S':'float','CRIT_AMNT':'float','MIN_PAYYEARS':'float','MIN_YEARS':'float','CONTRACT_UWNO':'float',
                                                  'CONTRACT_UWERROR':'float','INSURED_UWNO':'float','INSURED_UWERROR':'float','RISK_UWNO':'float','RISK_UWERROR':'float'},

    }

    @certifyException
    async def get(self, tablename):
        """
        ---
        tags:
        - UI
        summary: GetDtype API 获取表数据类型
        description: get data type operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: tablename
            description: tablename of post to get
            required: true
            type: string
        """
        if '?' in tablename:tablename=tablename.split('?',1)[0]
        tablename = tablename.split('=', 1)[1].strip()
        rest=self.dtype[tablename]
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getteamname', 'code': self.get_status(), 'rest': rest}






