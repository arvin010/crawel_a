from swgmodel.ui.reactiontime import *
import json
from interviews import *


class ReactionTime(RequestHandlers):
    """
       返回期间内在线服务平均时间数据
    """
    resdata = {"result": False, "message": 'successful','context':None}
    temp_field = ('start_time', 'end_time')

    @certifyException
    async def post(self):
        """
            ---
            tags:
            - UI
            summary: Reaction Time API 获取在线服务平均响应时间以及每日数据
            description: reaction time operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ReactionTimePostModel'
        """
        _params = json.loads(self.request.body)
        # 过滤前端多余参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.temp_field:
                    p.pop(i)

        start_time = _params[0].get('start_time')
        end_time = _params[0].get('end_time')

        # 1.单位时间内在线服务平均响应时间
        avg_time = self.mysql.fetch_all(tablename='call_logs', field='avg(endtime-begintime) as avg_time',
                                       condition="""where createdtime BETWEEN '{start_time}' and '{end_time}'""".format(
                                           start_time=start_time, end_time=end_time))
        avg_time = str(round(avg_time[0]['avg_time'], 4))
        # 2.单位时间内的在线服务平均时间每日数据
        reactiontime_data = self.mysql.fetch_all(tablename='',
                            field='DATE(createdtime) as date, avg(time) as avgtime',
                            condition="""(select createdtime, (endtime-begintime) as time from call_logs cl where createdtime BETWEEN '{start_time}' and '{end_time}') bb
                            group by date """.format(start_time=start_time, end_time=end_time))

        for i in reactiontime_data:
            i['date'] = str(i['date'])
            i['avgtime'] = str(round(i['avgtime'], 4))
        rest = [{'avg_time':avg_time}, {'reactiontime_data':reactiontime_data}]

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'reactiontime', 'code': self.get_status(), 'rest': rest}

