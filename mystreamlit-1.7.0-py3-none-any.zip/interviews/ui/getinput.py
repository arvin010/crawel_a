from swgmodel.ui.getinput import *
import json
from interviews import *


class GetInput(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def get(self, rlcode):
        """
        ---
        tags:
        - UI
        summary: GetInput API 获取参数名称、参数值数据
        description: getinput operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: rlcode
            description: rlcode of post to get
            required: true
            type: string
        """
        rlcode = rlcode.split('=', 1)[1].strip()
        field = """rlcode, pname, pdatatype, isreq, isformodel, defaultv,samplev,description"""
        condition = "where rlcode = '{rlcode}'".format(rlcode=rlcode)
        rest = self.mysql.fetch_all(tablename='model_params', field=field, condition=condition)
        for row in rest:
            if row['samplev']=='None':
                row['samplev']=None
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getinput', 'code': self.get_status(), 'rest': rest}






