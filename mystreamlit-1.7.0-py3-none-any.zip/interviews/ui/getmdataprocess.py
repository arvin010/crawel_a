from swgmodel.ui.getmdataprocess import *
import json
from interviews import *


class GetMDataProcess(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def get(self,rlcode):
        """
        ---
        tags:
        - UI
        summary: GetMDataProcess API 获取预览页面--数据处理栏信息
        description: get model data process rules config operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: rlcode
            description: rlcode of post to get
            required: true
            type: string
        """
        rlcode = rlcode.split('=', 1)[1].strip()
        rest = []
        # rlcode = 'cvmdtcresxxx1v1'
        rest = self.mysql.fetch_all(tablename='model_dataprocess',condition="where rlcode = '{rlcode}'".format(rlcode=rlcode))

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getmdataprocess', 'code': self.get_status(), 'rest': rest}



