from interviews import RequestHandlers, authException
from swgmodel.ui.createteams import *
import json


class CreateTeams(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @authException
    async def post(self):
        """
            ---
            tags:
            - UI
            summary: CreateTeams API 添加团队
            description: create teams operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/CreateTeamsPostModel'
        """
        _params = json.loads(self.request.body)
        rest = []
        # 过滤前端多余参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.mysql.desc(tablename='teams')[1:-2]:
                    p.pop(i)
        idlist = [item.setdefault('teamcode', None) for item in _params]
        leader = _params[0].get('leader', None)
        teamcode_list = [i['teamcode'].lower() for i in self.mysql.fetch_all(tablename='teams', field='teamcode')]

        if leader is not None:
            userinfo = self.mysql.fetch_one(tablename='users', field='username, cname, role', condition="where aduser = '{aduser}'".format(aduser=leader))
            role = userinfo.get('role', None) if userinfo else None
        else:
            userinfo = None

        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, '[teamcode] is required'); break
            if not idlist[inx]: self.set_status(202, 'empty teamcode'); break
            if row['teamcode'].lower() in teamcode_list: self.set_status(203); break  # 数据库已存在teamcode则无法新增
            if userinfo is not None:
                rest.append(self.mysql.insert_many(tablename='teams', col_list=list(row.keys()), value_list=[list(row.values())]))
            else:
                self.set_status(201, 'empty data')
                break

        # 同步更新表teamusers
        if rest.count(1) == 1:
            value_list_tusers = [[_params[0]['teamcode'], _params[0]['leader'], userinfo['username'], userinfo['cname'], _params[0]['enable'], _params[0]['operator']]]
            self.mysql.insert_many(tablename='teamusers', col_list=['teamcode', 'aduser', 'ename', 'cname', 'enable', 'operator'], value_list=value_list_tusers)

        return {'type': 'post', 'desc': 'teamcode', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}
