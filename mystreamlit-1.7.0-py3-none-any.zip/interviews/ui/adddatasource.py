from swgmodel.ui.adddatasource import *
import json
from interviews import RequestHandlers,authException


class AddDataSource(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @authException
    async def post(self, id):
        """
        ---
        tags:
        - UI
        summary: Add Data Source API 添加数据源
        description: Add Data Source operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/AddDataSourcePostModel'

        """
        _params = json.loads(self.request.body)
        rest = []
        # 过滤前端多余参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.mysql.desc(tablename='datasource')[1:-2]:
                    p.pop(i)
        idlist = [item.setdefault('dscode', None) for item in _params]
        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, '[dscode] is required'); break
            if not idlist[inx]: self.set_status(202, 'empty dscode'); break
            if self.mysql.fetch_one(tablename='datasource',condition=f''' where dscode = '{row["dscode"]}' '''):
                self.set_status(203)
                break
            rest.append(
                self.mysql.insert_many(tablename='datasource', col_list=list(row.keys()), value_list=[list(row.values())]))

        return {'type': 'post', 'desc': 'dscode ', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}


    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - UI
        summary: Edit Data Source API 数据查询源-编辑
        description: Edit Data Source operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/AddDataSourcePatchModel'

        """
        _params = json.loads(self.request.body)
        rest = []
        # 过滤前端参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.mysql.desc(tablename='datasource')[1:-2]:
                    p.pop(i)
        idlist = [item.setdefault('dscode', None) for item in _params]
        for item in _params:
            if item.setdefault('dscode', None) == None: self.set_status(500, 'params error'); break
            if item['dscode']:
                field = ','.join(["{k}= null".format(k=k, v=v) if v == 'None' else "{k}='{v}'".format(k=k, v=v) for k, v in item.items()])
                rest.append(self.mysql.update_one(tablename='datasource', field=field, condition="where dscode='{dscode}'".format(dscode=item['dscode'])))
            else:
                self.set_status(202, 'empty dscode')
                break
        rest = [i for i in rest if i]

        return {'type': 'patch', 'desc': 'dscode', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}