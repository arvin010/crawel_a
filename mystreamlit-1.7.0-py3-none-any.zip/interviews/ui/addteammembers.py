from interviews import RequestHandlers, authException
from swgmodel.ui.addteammembers import *
import json
from lib import G


class AddTeamMembers(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @authException
    async def post(self, id):
        """
            ---
            tags:
            - UI
            summary: AddTeamMembers API 后台管理--添加团队成员接口
            description: add team members operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/AddTeamMembersPostModel'
        """
        try:
            _params = json.loads(self.request.body)
            rest = []
            # G.mlog.info(f"[{self.__class__.__name__}] [{self.post.__name__}] :{_params}")
            # 过滤前端多余参数
            for p in _params:
                for i in list(p.keys()):
                    if i not in self.mysql.desc(tablename='teamusers')[1:-2]:
                        p.pop(i)

            idlist = [item.setdefault('teamcode', None) for item in _params]
            ta_lis = [(i['teamcode'].lower(), i['aduser'].lower(), int(i['enable'])) for i in self.mysql.fetch_all(tablename='teamusers', field='teamcode, aduser, enable',
                                           condition='where enable = 1')]
            exist_teamcode = [i['teamcode'].lower() for i in self.mysql.fetch_all(tablename='teams', field='DISTINCT teamcode')]

            for inx, row in enumerate(_params):
                if row['aduser'] == '': self.set_status(500); break  # 缺aduser
                if not idlist[inx]: self.set_status(500); break  # 缺teamcode
                if row['teamcode'].lower() not in exist_teamcode: self.set_status(201); break  # 不允许添加不存在的团队
                if (row['teamcode'].lower(), row['aduser'].lower(), 1) in ta_lis: self.set_status(
                    203); break  # 已存在记录不能插入
                if not isinstance(int(row['enable']), int): self.set_status(201, 'enable value error'); break  # 校验enable是否整数
                # 若存在enable=0的记录，则enable值更新为1
                enable_flag = self.mysql.fetch_one(tablename='teamusers', field='enable',
                                                   condition="where teamcode = '{teamcode}' and aduser = '{aduser}' and enable = 0".format(teamcode=row['teamcode'], aduser=row['aduser']))
                if enable_flag:
                    field = ','.join(["{k}= null".format(k=k, v=v) if v == 'None' else "{k}='{v}'".format(k=k, v=v) for k, v in _params[0].items()])
                    rest.append(self.mysql.update_one(tablename='teamusers', field=field,
                                                      condition="where teamcode='{teamcode}' and aduser = '{aduser}'".format(teamcode=row['teamcode'], aduser=row['aduser']))); break
                rest.append(self.mysql.insert_many(tablename='teamusers', col_list=list(row.keys()), value_list=[list(row.values())]))

        except Exception as e:
            import traceback
            G.mlog.info(f"[{self.__class__.__name__}] [{self.post.__name__}]: {traceback.format_exc()}")
            self.set_status(401)

        return {'type': 'post', 'desc': 'teamcode or aduser', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

    @authException
    async def patch(self, id):
        """
        ---
        tags:
        - UI
        summary: Edit Team Members API   后台管理--团队成员列表编辑
        description: Edit Team Members operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/AddTeamMembersPatchModel'

        """
        _params = json.loads(self.request.body)
        rest = []
        # 过滤前端参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.mysql.desc(tablename='teamusers')[1:-2]:
                    p.pop(i)
        idlist = [item.setdefault('teamcode', None) for item in _params]

        for item in _params:
            if item.setdefault('teamcode', None) == None: self.set_status(500, 'params error'); break
            if item['teamcode'] and item['aduser']:
                field = ','.join(
                    ["{k}= null".format(k=k, v=v) if v == 'None' else "{k}='{v}'".format(k=k, v=v) for k, v in
                     item.items()])
                rest.append(self.mysql.update_one(tablename='teamusers', field=field,
                                                  condition="where teamcode='{teamcode}' and aduser = '{aduser}'".format(
                                                      teamcode=item['teamcode'], aduser=item['aduser'])))
            else:
                self.set_status(202, 'empty teamcode or aduser')
                break
        rest = [i for i in rest if i]

        return {'type': 'patch', 'desc': 'teamcode or aduser', 'code': self.get_status(), 'rest': rest,
                'idlist': idlist}
