from swgmodel.ui.getteamname import *
import json
from interviews import *


class GetTeamName(RequestHandlers):
    resdata = {"result": False,  "message": 'successful', 'context': None}

    @certifyException
    async def get(self, aduser):
        """
        ---
        tags:
        - UI
        summary: GetTeamName API 获取团队名称列表数据
        description: get team name operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: aduser
            description: aduser of post to get
            required: true
            type: string
        """
        aduser = aduser.split('=', 1)[1].strip()
        field = 'teamcode, teamname'
        condition = "where teamcode in (select teamcode from mpp.teamusers where aduser = '{aduser}')".format(aduser=aduser)
        rest = self.mysql.fetch_all(tablename='teams', field=field, condition=condition)

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getteamname', 'code': self.get_status(), 'rest': rest}






