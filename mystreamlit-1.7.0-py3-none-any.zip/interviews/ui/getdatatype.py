from swgmodel.ui.getdatatpye import *
import json
from interviews import *


class GetDataType(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def get(self):
        """
        ---
        tags:
        - UI
        summary: Get Data Type API 获取数据类型
        description: get data type operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        rest = ('str', 'float', 'int')

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getdatatype', 'code': self.get_status(), 'rest': rest}


