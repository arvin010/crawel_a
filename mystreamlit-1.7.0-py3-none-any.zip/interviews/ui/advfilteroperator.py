from swgmodel.ui.advfilteroperator import *
import json
from interviews import RequestHandlers, certifyException


class AdvFilterOperator(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def get(self):
        """
        ---
        tags:
         - UI
        summary: AdvFilterOperator API 获取高级筛选中的运算符列表可选项
        description: adv filter operator operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        operator_mapping = [{'等于': '=', '不等于': '<>'}]

        if operator_mapping:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'advfilteroperator', 'code': self.get_status(), 'rest': operator_mapping}
