from swgmodel.ui.getmparamsconfig import *
import json
from interviews import *


class GetMParamsConfig(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    # @certifyException('getmparamsconfig')
    async def get(self,rlcode):
        """
        ---
        tags:
        - UI
        summary: GetMParamsConfig API 获取预览页面--参数配置栏信息
        description: get model params config operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: rlcode
            description: rlcode of post to get
            required: true
            type: string
        """
        rlcode = rlcode.split('=', 1)[1].strip()
        rest = []
        # rlcode = 'cvmdtcresxxx1v1'
        rest = self.mysql.fetch_all(tablename='model_params', condition="where rlcode = '{rlcode}'".format(rlcode=rlcode))

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getmparamsconfig', 'code': self.get_status(), 'rest': rest}







