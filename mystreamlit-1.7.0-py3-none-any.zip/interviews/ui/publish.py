from interviews import *
from swgmodel.ui.getmodellist import *
import json
from dccdatetime import DccDatetime
from lib.metadata import Metadata


class Publish(RequestHandlers):
    resdata = {"result": False,  "message": 'successful', 'context': None}
    _dccdatetime=DccDatetime()
    @certifyException
    async def get(self, rlcode):
        """
        ---
        tags:
        - UI
        summary: GetModelGroupList API 获取模型组信息
        description: get model list operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: rlcode
            description: rlcode of post to get
            required: true
            type: string
        """
        if '?' in rlcode:rlcode=rlcode.split('?',1)[0]
        rlcode = rlcode.split('=', 1)[-1].strip()
        offline=online=None
        dev=self.mysql.fetch_all(tablename='model_release',condition=f'where rlcode="{rlcode}" and rlstatus in ("newdev","ondev")')
        if dev:
            offline=self.mysql.update_one(tablename='model_release',field=f'rlstatus="offline",offtime="{self._dccdatetime.now()}",operator="{self._current_user}"', condition=f'where rlcode="{rlcode}" and rlstatus in ("online")')
            online=self.mysql.update_one(tablename='model_release',field=f'rlstatus="online",ontime="{self._dccdatetime.now()}",operator="{self._current_user}"', condition=f'where rlcode="{rlcode}" and rlstatus in ("newdev","ondev","None")')
        if offline or online:
            Metadata().meta_data(rlcode=rlcode)
            rest=online
            self.set_status(200, 'ok')
        else:
            rest=[]
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'aduser ', 'code': self.get_status(), 'rest': rest}






