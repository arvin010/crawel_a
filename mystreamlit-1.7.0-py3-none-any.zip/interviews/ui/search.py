from swgmodel.ui.search import *
import json
from interviews import RequestHandlers, certifyException


class Search(RequestHandlers):
    """
        页面搜索框搜索功能
    """
    resdata = {"result": False, "message": 'successful','context': None}

    @certifyException
    async def post(self):
        """
            ---
        tags:
        - UI
        summary: Search API 搜索
        description: search operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/SearchPostModel'
        """
        # paramstr = paramstr.split('=', 1)[1].strip()
        _params = json.loads(self.request.body)
        querystr = _params[0].get('querystr', None)
        operator = _params[0].get('operator', None)
        # 获取数据内容
        rest = self.mysql.fetch_all(tablename='model_groups', condition="where lower(modelgroup) like '%{querystr}%'".format(querystr=querystr))

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'search', 'code': self.get_status(), 'rest': rest}
