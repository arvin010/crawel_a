from swgmodel.ui.getmodelrealease import *
import json
from interviews import RequestHandlers, certifyException
from lib.com import Pagination


class Getmglback(RequestHandlers):
    resdata = {"result": False,  "message": 'successful', 'context':None}

    @certifyException
    async def get(self, params):
        """
        ---
        tags:
        - UI
        summary: Getmglback API 用于后台管理页面获取模型组信息
        description: Get modelgroups list back operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: params
            description: aduser of post to get
            required: true
            type: string
        """
        # aduser=szw210614&pagenum=1&pagelimit=10
        dict_params = {}
        if params.count('&') != 0:
            params = params.split('&', 2)
            for i in params:
                dict_params[i.split('=', 1)[0]] = i.split('=', 1)[1].strip()
            aduser, pagenum, pagelimit = dict_params['aduser'], int(dict_params['pagenum']), int(dict_params['pagelimit'])
        else:
            params = params.split('=', 1).strip()
            dict_params[params[0]] = params[1]
            aduser, pagenum, pagelimit = dict_params['aduser'], 1, 1000

        # 获取登录用户的role，返回前端是否显示编辑、删除功能
        role_res = self.mysql.fetch_all(tablename='users', field='role', condition="where aduser = '{aduser}'".format(aduser=aduser))
        role = int(role_res[0]['role']) if role_res else None

        field = 'modelgroup, appcode, appname, depcode, depname, buscode, busname, modelclass, modelclassname, updatedtime'
        rest = self.mysql.fetch_all(tablename='model_groups', field=field)

        # 分页逻辑
        all_item = len(rest)
        obj = Pagination(current_page=pagenum, all_item=all_item, page_limit=pagelimit)
        current_list = rest[obj.page_start: obj.page_end]
        current_page = obj.current_page  # 分页数据
        all_page = obj.all_page  # 返回前端总页数
        # 返回前端：总页数/分页数据/当前页码
        rest = {'current_page': current_page, 'current_list': current_list, 'all_page': all_page, 'all_item': all_item}

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getmglback', 'code': self.get_status(), 'rest': rest}
