from interviews import *
from swgmodel.mconf.modelgroups import *
import json


class AddModelGroups(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @authException
    async def post(self, ):
        """
            ---
            tags:
            - UI
            summary: Model Groups API 模型组表
            description: model groups operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelGroupsPostModel'
        """
        _params = json.loads(self.request.body)
        rest = []
        # 过滤前端多余参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.mysql.desc(tablename='model_groups')[1:-2]:
                    p.pop(i)
        idlist = [item.setdefault('appcode', None) for item in _params]
        aduser = _params[0].get('operator', None)

        if aduser is not None:
            role_res = self.mysql.fetch_one(tablename='users u', field='role', condition=f"where aduser ='{aduser}'")
            role = role_res.get('role') if role_res else None
        else:
            role = None

        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, '[appcode] is required'); break
            if not idlist[inx]: self.set_status(202, 'empty appcode'); break
            # 拆增四个字段
            row['appcode'], row['appname'] = row['appcode'].split('-')[0].strip(), row['appcode'].split('-')[1].strip()
            row['depcode'], row['depname'] = row['depcode'].split('-')[0].strip(), row['depcode'].split('-')[1].strip()
            row['buscode'], row['busname'] = row['buscode'].split('-')[0].strip(), row['buscode'].split('-')[1].strip()
            row['modelclass'], row['modelclassname'] = row['modelclass'].split('-')[0].strip(), row['modelclass'].split('-')[1].strip()
            row['modelgroup'] = f"{row['appcode']}{row['depcode']}{row['buscode']}{row['modelclass']}"
            modelgroup = self.mysql.fetch_one(tablename='model_groups', field='modelgroup',condition=f"where modelgroup ='{row['modelgroup']}'")
            if modelgroup is None:
                rest.append(self.mysql.insert_many(tablename='model_groups', col_list=list(row.keys()), value_list=[list(row.values())]))
            else:
                self.set_status(201, "empty data")
                break

        return {'type': 'get', 'desc': 'addmodelgroup', 'code': self.get_status(), 'rest': rest, 'idlist': [1]}
