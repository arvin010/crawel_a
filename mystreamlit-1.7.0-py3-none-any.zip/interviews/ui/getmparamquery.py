from swgmodel.ui.getmparamquery import *
import json
from interviews import *


class GetMParamQuery(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def get(self,rlcode):
        """
        ---
        tags:
        - UI
        summary: GetMParamQuery API 获取预览页面--数据查询栏信息
        description: get model paramQuery rules config operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: rlcode
            description: rlcode of post to get
            required: true
            type: string
        """
        rlcode = rlcode.split('=', 1)[1].strip()
        rest = []
        rest = self.mysql.fetch_all(tablename='model_parmas_query', condition="where rlcode = '{rlcode}'".format(rlcode=rlcode))

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getmparamquery', 'code': self.get_status(), 'rest': rest}






