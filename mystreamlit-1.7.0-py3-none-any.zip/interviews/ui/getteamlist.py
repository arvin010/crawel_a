from swgmodel.ui.getteamname import *
import json
from interviews import RequestHandlers, certifyException
from lib.com import Pagination


class GetTeamList(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def get(self, params):
        """
        ---
        tags:
        - UI
        summary: GetTeamList API 获取对应团队的成员列表数据
        description: get team list operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: params
            description: params of post to get
            required: true
            type: string
        """
        # teamcode = 'ops'
        # 分页参数 teamcode=ops&pagenum=1&pagelimit=5
        dict_params = {}
        if params.count('&') != 0:
            params = params.split('&', 2)
            for i in params:
                dict_params[i.split('=', 1)[0]] = i.split('=', 1)[1].strip()
            teamcode, pagenum, pagelimit = dict_params['teamcode'], int(dict_params['pagenum']), int(dict_params['pagelimit'])
        else:
            params = params.split('=', 1)
            if params[0].strip() == 'teamcode':
                teamcode, pagenum, pagelimit = params[1].strip(), 1, 1000

        # 新增角色 只返回enable=1的记录
        field = "t.teamcode, t.aduser, t.ename, t.cname, t.enable, IF(t.aduser = (select leader from mpp.teams where teamcode = '{teamcode}'),1 ,0 ) as is_leader".format(teamcode=teamcode)
        condition = "where teamcode ='{teamcode}' and enable = 1".format(teamcode=teamcode)
        rest = self.mysql.fetch_all(tablename='teamusers t', field=field, condition=condition)

        # 分页逻辑
        all_item = len(rest)
        obj = Pagination(current_page=pagenum, all_item=all_item, page_limit=pagelimit)
        current_list = rest[obj.page_start: obj.page_end]
        current_page = obj.current_page  # 分页数据
        all_page = obj.all_page  # 返回前端总页数
        # 返回前端：总页数/分页数据/当前页码
        rest = {'current_page': current_page, 'current_list': current_list, 'all_page': all_page, 'all_item': all_item}

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getteamlist', 'code': self.get_status(), 'rest': rest}