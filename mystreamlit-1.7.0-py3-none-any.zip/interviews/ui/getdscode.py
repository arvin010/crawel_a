from swgmodel.ui.getdscode import *
import json
from interviews import *


class GetDSCode(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def get(self):
        """
        ---
        tags:
        - UI
        summary: Get DScode API  获取数据源编码(dscode)数据
        description: get dscode operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        rest = self.mysql.fetch_all(tablename='datasource', field='DISTINCT dscode')  # 不重复dscode
        rest = [{'dscode': [i['dscode'] for i in rest]}]
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getdscode', 'code': self.get_status(), 'rest': rest}



