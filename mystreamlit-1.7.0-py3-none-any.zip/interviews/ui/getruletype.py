from swgmodel.ui.getruletype import *
import json
from interviews import *


class GetRuleType(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def get(self):
        """
        ---
        tags:
        - UI
        summary: Get Rule Type API 获取规则类型数据
        description: get rule type operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        rest = ('python', 'regex')

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getruletype', 'code': self.get_status(), 'rest': rest}


