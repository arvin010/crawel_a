from interviews import *
from swgmodel.mconf.filepackage import *
import json
from time import time
from dccdatetime import DccDatetime


class AddFilePkg(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}
    _dccdatetime = DccDatetime()

    @certifyException
    async def post(self, rlcode):
        """
            ---
            tags:
            - UI
            summary: Model File Package API 模型文件包配置
            description: model file package operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/AddFilePackageModel'
        """
        _params = json.loads(self.request.body)
        res_fp = res_mr = desc = None
        idlist = [item.setdefault('rlcode', None) for item in _params]
        pkg_col = ['rlcode', 'filepkgcode', 'filename', 'rfc', 'operator']
        release_col = ['rlcode', 'filepkgcode', 'rlstatus', 'verdesc','alphatime', 'operator']
        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500);break
            if not idlist[inx]: self.set_status(202);break
            rlcode = row.get('rlcode', None)
            filepkgcode = row.get('filepkgcode', None)
            rlstatus = self.mysql.fetch_all(tablename='model_release', field='rlstatus',
                                            condition=f'where filepkgcode="{filepkgcode}"')[0][
                'rlstatus'] if filepkgcode else 'newdev'
            rlstatus=rlstatus.lower()
            verdesc=self.mysql.fetch_one(tablename='model_release', condition=f"where rlcode='{idlist[0]}' order by updatedtime desc")
            verdesc =verdesc if verdesc else {}
            old_list = row.get('old_list', None)
            old_list=[{'rfc':float(item.get('rfc',None)),'filename':item.get('filename',None)} for item in old_list]
            new_list = row.get('new_list', None)
            new_list=[{'rfc':float(item.get('rfc',None)),'filename':item.get('filename',None)} for item in new_list]
            rfc_list = list(map(lambda item: item.get('rfc', 0), new_list))
            if not new_list:
                res_mr = self.mysql.delete_many(tablename='model_release',
                                                condition=f'where filepkgcode="{filepkgcode}" and rlstatus="ondev"')
                res_fp = self.mysql.delete_many(tablename='file_package',
                                                condition=f'where filepkgcode="{filepkgcode}"')
                break
            else:
                if sum([i*10 for i in rfc_list]) != 10:
                    self.set_status(207)
                    desc = 'rfc 总和不为1'
                    break
                if 0 in list(rfc_list):
                    self.set_status(208)
                    desc = '不能有为0的rfc'
                    break
            if new_list != old_list:
                if rlstatus == 'online':
                    if not self.mysql.fetch_all(tablename='model_release',
                                                condition=f"where rlcode='{idlist[0]}' and rlstatus in('ondev')"):
                        filepkgcode = f"{rlcode}_pkg_{int(time())}"
                        res_mr = self.mysql.insert_many(tablename='model_release', col_list=release_col, value_list=[
                            [rlcode, filepkgcode, 'ondev', verdesc.get('verdesc',None),self._dccdatetime.now(), self._current_user]])
                        res_fp = [self.mysql.insert_many(tablename='file_package', col_list=pkg_col, value_list=[
                            [rlcode, filepkgcode, item.get('filename', None).lower(), item.get('rfc', None),
                             self._current_user]]) for item in new_list]
                    else:
                        self.mysql.delete_many(tablename='file_package', condition=f'where filepkgcode="{filepkgcode}"')
                        res_fp = [self.mysql.insert_many(tablename='file_package', col_list=pkg_col, value_list=[
                            [rlcode, filepkgcode, item.get('filename', None).lower(), item.get('rfc', None),
                             self._current_user]]) for item in new_list]
                elif rlstatus in ['newdev', 'ondev', 'none']:
                    self.mysql.delete_many(tablename='file_package', condition=f'where filepkgcode="{filepkgcode}"')
                    res_fp = [self.mysql.insert_many(tablename='file_package', col_list=pkg_col, value_list=[
                        [rlcode, filepkgcode, item.get('filename', None).lower(), item.get('rfc', None), self._current_user]])
                              for item in new_list]
                    if not new_list:
                        res_mr = self.mysql.delete_many(tablename='model_release',
                                                        condition=f'where filepkgcode="{filepkgcode}" and rlstatus="ondev"')
                    else:
                        res_mr = insert_(self, tablename='model_release', col_list=release_col, key='filepkgcode',
                                         item={'filepkgcode': filepkgcode, 'rlcode': rlcode, 'rlstatus': rlstatus if rlstatus!='none' else 'newdev','verdesc':verdesc.get('verdesc',None),'alphatime': self._dccdatetime.now(),'operator': self._current_user})
            else:
                desc = '文件未更改'
                self.set_status(207)
        if res_fp or res_mr:
            rest = [1]
        else:
            if self.get_status() == 200: self.set_status(201)
            rest = []
        return {'type': 'get', 'desc': f'{desc} ', 'code': self.get_status(), 'rest': filepkgcode}


