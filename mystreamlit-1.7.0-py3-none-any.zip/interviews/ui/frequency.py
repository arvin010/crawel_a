from swgmodel.ui.frequency import *
import json
from interviews import *

class Frequency(RequestHandlers):
    """
       获取时间范围内的模型调用总次数及每日调用数据
    """
    resdata = {"result": False, "message": 'successful','context':None}
    temp_field = ('start_time', 'end_time')

    @certifyException
    async def post(self):
        """
            ---
            tags:
            - UI
            summary: Frequency API 获取时间范围内的模型调用总次数及每日调用数据
            description: frequency operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ReactionTimePostModel'
        """
        _params = json.loads(self.request.body)
        # 过滤前端多余参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.temp_field:
                    p.pop(i)

        start_time = _params[0].get('start_time')
        end_time = _params[0].get('end_time')

        # 1.区间内调用总次数
        total_counts = self.mysql.fetch_all(tablename='call_logs', field='count(*) as total_counts',
                               condition="""where createdtime BETWEEN '{start_time}' and '{end_time}'""".format(start_time=start_time,end_time=end_time))
        # 2.区间内的日调用数据
        freq_data = self.mysql.fetch_all(tablename='call_logs',
                                    field='DATE(createdtime) as date, count(*) as total_counts',
                                    condition="""where DATE(createdtime) BETWEEN '{start_time}' and '{end_time}' group by DATE(createdtime)""".format(
                                    start_time=start_time, end_time=end_time))
        rest = [total_counts[0], {'freq_data:': freq_data}]

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'frequency', 'code': self.get_status(), 'rest': rest}


