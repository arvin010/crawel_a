from interviews import RequestHandlers, certifyException
from swgmodel.ui.changerole import *
import json


class ChangeRole(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def patch(self, id):
        """
        ---
        tags:
        - UI
        summary: ChangeRole API 更换团队长
        description: change role operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/ChangeRolePatchModel'
        """
        _params = json.loads(self.request.body)
        rest = []
        teamcode = [item.setdefault('teamcode', None) for item in _params][0]
        aduser = [item.setdefault('aduser', None) for item in _params][0]
        operator = [item.setdefault('operator', None) for item in _params][0]

        if teamcode and aduser:
            field = "leader = '{leader}' , operator = '{operator}'".format(leader=aduser, operator=operator)
            rest.append(self.mysql.update_one(tablename='teams', field=field, condition="where teamcode='{teamcode}'".format(teamcode=teamcode)))
        else:
            self.set_status(202, 'empty teamcode')

        rest = [i for i in rest if i]
        return {'type': 'patch', 'desc': 'teamcode', 'code': self.get_status(), 'rest': rest}