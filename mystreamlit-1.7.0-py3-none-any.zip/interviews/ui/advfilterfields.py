from swgmodel.ui.advfilterfields import *
import json
from interviews import RequestHandlers, certifyException


class AdvFilterFields(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def get(self):
        """
        ---
        tags:
        - UI
        summary: AdvFilterFields 获取高级筛选中的过滤字段可选项
        description: adv filter fields operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        fields_mapping = [{'应用场景': 'appcode', '模型应用部门': 'depcode', '模型场景':'buscode', '模型细类': 'modelclass', '创建日期': 'createdtime', '最后更新日期': 'updatedtime'}]

        if fields_mapping:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')

        return {'type': 'get', 'desc': 'advfilterfields', 'code': self.get_status(), 'rest': fields_mapping}
