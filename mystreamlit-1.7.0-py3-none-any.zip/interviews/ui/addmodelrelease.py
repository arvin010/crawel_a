from interviews import *
from swgmodel.mconf.models import *
from interviews.mconf.modelrelease import ModelRelease
import json


class AddModelRelease(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def get(self, rlcode):
        """
            ---
            tags:
            - UI
            summary: Models API 模型配置表
            description: model param Rules operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: path
                name: rlcode
                description: rlcode of post to get
                required: true
                type: string
        """
        # id = rlcode.split('=', 1)[1].strip() if rlcode else None
        # idlist = rlcode=[]
        # filepkgcode=desc=''
        # if id :
            # idlist = id.split(',') if ',' in id else [id]
            # modelcode=idlist[0][:idlist[0].rfind('_v')] if ('_v' in idlist[0] and len(idlist[0])>17) else idlist[0]
            # if self.mysql.fetch_all(tablename='model_release',field='count(1) num',condition=f"where rlcode like '{modelcode}%' and rlstatus in('ondev','newdev')")[0]['num'] < 1:
                # rest,rlcode,filepkgcode=ModelRelease.gen_rlcode(self,modelcode=modelcode)
                # rest,rlcode,filepkgcode=self.gen(self,id)
            # else:
            #     desc='Not allowed'
            #     self.set_status(207)
        # else:
        #     self.set_status(207, 'dev version exists')
        id = rlcode.split('=', 1)[1].strip() if rlcode else None
        desc,code,rlcode,filepkgcode=self.gen(self,id)
        self.set_status(code)
        return {'type': 'get', 'desc': f'{desc}', 'code': self.get_status(), 'rest': {'rlcode':rlcode,'filepkgcode':filepkgcode}}


    @staticmethod
    def gen(self,id,flag=False):
        idlist = rlcode=[]
        filepkgcode=desc=code=''
        if id :
            idlist = id.split(',') if ',' in id else [id]
            modelcode=idlist[0][:idlist[0].rfind('_v')] if ('_v' in idlist[0] and len(idlist[0])>17) else idlist[0]
            if flag or self.mysql.fetch_all(tablename='model_release',
                field='count(1) num',
                condition=f"where rlcode like '{modelcode}%' and rlstatus in('ondev','newdev')")[0]['num'] < 1:
                rest,rlcode,filepkgcode = ModelRelease.gen_rlcode(self,modelcode=modelcode)
                code=200
            else:
                desc='操作不允许'
                code=207
        else:
            desc='操作不允许'
            code=207
        return desc,code,rlcode,filepkgcode