from swgmodel.ui.getmodelrealease import *
import json
from interviews import *
async def f(item):
    item['modelvers']=item['rlcode'].split('_v',1)[-1]

class GetModelRealease(RequestHandlers):
    resdata = {"result": False,  "message": 'successful', 'context':None}

    @certifyException
    async def get(self, modelcode):
        """
        ---
        tags:
        - UI
        summary: GetModelRealease API 获取模型对应的模型发布编码等信息
        description: get model realease  operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: modelcode
            description: modelcode of post to get
            required: true
            type: string
        """
        rest=None
        if modelcode:
            modelcode: modelcode = modelcode.split('=', 1)[1].strip()
            rest=self.mysql.fetch_all(tablename=f"(select  rlcode, verdesc,operator,alphatime,ontime,createdtime,updatedtime,ifnull(rlstatus,'newdev') rlstatus,filepkgcode, sum(1)  over(partition by rlcode ORDER BY updatedtime DESC ) as _ from model_release mr where mr.rlcode like '{modelcode}%' and mr.rlstatus not in('offline') ) ",
                                      condition="m  where m._ = 1 order by createdtime  desc;")
            c=list(map(lambda item:f(item),rest))
            if rest:
                self.set_status(200, 'ok')
            else:
                self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getmodelrealease', 'code': self.get_status(), 'rest': rest}






