from swgmodel.ui.advancedfilter import *
import json
from interviews import RequestHandlers, certifyException


class AdvancedFilter(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def post(self):
        """
        ---
        tags:
        - UI
        summary: AdvancedFilter API 高级筛选功能
        description: advanced filter operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/AdvancedFilterPostModel'
        """
        # 1.取出筛选参数的字典(假设查询条件)
        _params = json.loads(self.request.body)
        aduser = _params[0].get('aduser', None)
        querylist = _params[0].get('querylist', None)
        rest = []

        # 2.校验带过来的参数是否符合规定
        non_datetype_tup = ('appcode', 'depcode', 'buscode', 'modelclass', 'modelgroup')
        datetype_tup = ('createdtime', 'updatedtime')

        # 3.根据查询记录数量拼接SQL语句
        query_str = ''
        if len(querylist) == 1:
            for index, i in enumerate(querylist):
                if i['field'] in non_datetype_tup:
                    condition = "where {field} {operator} '{value}'".format(field=i['field'], operator=i['operator'],value=i['value'])
                    rest = self.mysql.fetch_all(tablename='model_groups', condition=condition)
                elif i['field'] in datetype_tup:
                    condition = "where DATE({field}) {operator} '{value}'".format(field=i['field'], operator=i['operator'],value=i['value'])
                    rest = self.mysql.fetch_all(tablename='model_groups', condition=condition)
                else:
                    break
        else:
            for index, i in enumerate(querylist):
                value_ = i['value']
                if i['field'] not in datetype_tup:
                    p = f"{i['field']}" + ' ' + f"{i['operator']}" + ' ' + f"'{value_}'"
                else:
                    p = f"DATE({i['field']})" + ' ' + f"{i['operator']}" + ' ' + f"'{value_}'"
                has_and = '' if index == 0 else 'and'
                query_str += f"{has_and}" + ' ' + ''.join(p) + ' '
                if index == len(querylist) - 1:
                    condition = f"where {query_str}"
                    rest = self.mysql.fetch_all(tablename='model_groups', condition=condition)

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')

        return {'type': 'get', 'desc': 'advancedfilter', 'code': self.get_status(), 'rest': rest}
