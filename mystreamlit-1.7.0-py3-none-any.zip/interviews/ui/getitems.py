from swgmodel.ui.getitems import *
import json
from interviews import *


class GetItems(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def get(self):
        """
        ---
        tags:
        - UI
        summary: GetItems API 根据item获取配置项表数据
        description: get items operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        res_dict = []
        rest = self.mysql.fetch_all(tablename='items', field="item,GROUP_CONCAT(icode,'-',ivalue) as icode", condition="where item in ('appcode','depcode','buscode','modelclass') group by item")
        for i in rest:
            res_dict.append({i['item']: i['icode'].split(',')})

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getitems', 'code': self.get_status(), 'rest': res_dict}








