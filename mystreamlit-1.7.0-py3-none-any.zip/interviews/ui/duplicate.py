from swgmodel.mconf.models import *
import json
from interviews.ui.addmodelrelease import AddModelRelease
from interviews import *


class Duplicate(RequestHandlers):
    """
        Duplicate 
    """
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def get(self, rlcode):
        """
            ---
        tags:
        - UI
        summary: duplicate  复制已上线版本
        description: duplicate
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: rlcode
            description: rlcode of post to get
            required: true
            type: string
        """
        id = rlcode.split('=', 1)[1].strip() if rlcode else None
        flag=True if self.mysql.fetch_one(tablename='model_release', condition=f"where rlcode like'{id[:id.rindex('_v')+1]}%' order by updatedtime desc").get('rlstatus',None)  =='online' else False
        desc,code,rlcode,filepkgcode=AddModelRelease.gen(self,id,flag=flag)
        self.set_status(code)
        if code==200 and flag:
            item_release=self.mysql.fetch_one(tablename='model_release', condition=f"where rlcode ='{id}' order by updatedtime desc")
            if item_release.get('rlstatus',None) =='online':
                item_pkg=self.mysql.fetch_all(tablename='file_package', condition=f'''where rlcode ='{id}' and filepkgcode ="{item_release['filepkgcode']}"''')
                item_release['rlstatus']='newdev'
                tname_list=['model_params','model_parmas_query','model_dataprocess','model_param_rules']
                item_list=list(map(lambda tname:get_(self,tablename=tname,key='rlcode',value=id),tname_list))
                item_list.append(item_pkg)
                tname_list.append('file_package')
                col_lists={tname:self.mysql.desc(tablename=tname)[1:-2] for tname in tname_list}
                for items in item_list:
                    for item in items:
                        item['rlcode']=rlcode
                        item.pop('id')
                        if item.get('filepkgcode',None):
                            item['filepkgcode']=filepkgcode
                c=list(map(lambda tup:list(map(lambda item: self.mysql.insert_many(tablename=tup[0],col_list = col_lists[tup[0]],value_list=[[item.get(col,None) if col!='operator' else self._current_user.lower() for
                    col in col_lists[tup[0]]]]),tup[1])),zip(tname_list,item_list)))
                self.mysql.update_one(tablename='model_release',field=f'''verdesc="{item_release['verdesc']}"''',condition=f"where filepkgcode='{filepkgcode}'")
            else:
                self.set_status(207)
                desc='操作不允许'
        return {'type': 'get', 'desc': f'{desc}', 'code': self.get_status(), 'rest': {'rlcode':rlcode,'filepkgcode':filepkgcode}}

