from interviews import *
from swgmodel.ui.getmodellist import *
import json


class GetModelGroupList(RequestHandlers):
    resdata = {"result": False,  "message": 'successful', 'context': None}
    @authException
    async def get(self, aduser):
        """
        ---
        tags:
        - UI
        summary: GetModelGroupList API 获取模型组信息
        description: get model list operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: aduser
            description: aduser of post to get
            required: true
            type: string
        """
        aduser = aduser.split('=', 1)[-1].strip()
        rest=self.mysql.fetch_all(tablename='model_groups',field='modelgroup')
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        data={'type': 'get', 'desc': 'aduser ', 'code': self.get_status(), 'rest': rest, 'idlist': aduser}
        return data






