from interviews import *
from swgmodel.mconf.models import *
from interviews.mconf.models import Models
import json


class AddModel(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @authException
    async def post(self, ):
        """
            ---
            tags:
            - UI
            summary: Models API 模型配置表
            description: model param Rules operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/ModelsPostModel'
        """
        _params = json.loads(self.request.body)
        idlist = [item.setdefault('modelgroup', None) for item in _params]
        rest = []
        col_list=self.mysql.desc(tablename='models')[1:-2]
        for inx, row in enumerate(_params):
            if idlist[inx] == None: self.set_status(500, '[modelgroup] is required');break
            if not idlist[inx]: self.set_status(202, 'empty modelgroup');break
            modelcode=None
            if row.get('modelcode',None):
                modelcode=self.mysql.fetch_one(tablename='models',field='modelcode',condition=f"where modelcode ='{row.get('modelcode',None)}'")
            if not modelcode:
                rest.append(Models.gen_modelcode(self,row=row,col_list=col_list))
            else:
                rest.append(update_(self,tablename='models',item={'modelcode':row['modelcode'],'content':{k:v for k,v in row.items() if k!='modelcode'}},key='modelcode',col_list=col_list))
        return {'type': 'get', 'desc': 'models', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}
