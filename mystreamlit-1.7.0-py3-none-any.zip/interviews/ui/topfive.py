from swgmodel.ui.topfive import *
import json
from interviews import *

class TopFive(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}
    temp_field = ('start_time', 'end_time')

    @certifyException
    async def post(self):
        """
            ---
            tags:
            - UI
            summary: Top Five API 获取Top5模型数据
            description: top five operate api
            produces:
            - application/json
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
            parameters:
            -   in: body
                name: body
                description: post data
                required: true
                schema:
                    type: array
                    items:
                        $ref: '#/definitions/TopFivePostModel'
        """
        _params = json.loads(self.request.body)
        # 过滤前端多余参数
        for p in _params:
            for i in list(p.keys()):
                if i not in self.temp_field:
                    p.pop(i)
        start_time = _params[0].get('start_time')
        end_time = _params[0].get('end_time')

        # 统计rlcode调用次数 降序排列返回
        rest = self.mysql.fetch_all(tablename='call_logs', field='rlcode, COUNT(*) as count',\
            condition="where createdtime BETWEEN '{start_time}' and '{end_time}' group by rlcode\
             order by count desc limit 5".format(start_time=start_time,end_time=end_time))

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'topfive', 'code': self.get_status(), 'rest': rest}