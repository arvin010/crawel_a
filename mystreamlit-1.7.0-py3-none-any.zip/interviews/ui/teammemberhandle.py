from interviews import *
from swgmodel.ui.teammemberhandle import *
import json


class TeamMemberHandle(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def delete(self, params):
        """
        ---
        tags:
        - UI
        summary: TeamMemberHandle API 团队管理--团队成员逻辑删除
        description: team member handle operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/TeamMemberHandleDeleteModel'
        """
        # _params包含要删除的teamcode、aduser、enable=0、operator, 其中前两个字段用于确定唯一一条记录
        _params = json.loads(self.request.body)
        rest = []
        for p in _params:
            for i in list(p.keys()):
                if i not in self.mysql.desc(tablename='teamusers')[1:-2]:
                    p.pop(i)

        for item in _params:
            if item.setdefault('teamcode', None) == None: self.set_status(500, 'params error'); break
            if item['teamcode'] and item['aduser']:
                field = ','.join(["{k}= null".format(k=k, v=v) if v == 'None' else "{k}='{v}'".format(k=k, v=v) for k, v in item.items()])
                rest.append(self.mysql.update_one(tablename='teamusers', field=field, condition="where teamcode='{teamcode}' and aduser = '{aduser}'".format(teamcode=item['teamcode'], aduser=item['aduser'])))
            else:
                self.set_status(202, 'empty teamcode or aduser')
                break

        rest = [i for i in rest if i]
        return {'type': 'delete', 'desc': 'teamcode or aduser', 'code': self.get_status(), 'rest': rest}
