from swgmodel.ui.getexistmembers import *
import json
from interviews import RequestHandlers, certifyException


class GetExistMembers(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @certifyException
    async def get(self, teamcode):
        """
        ---
        tags:
        - UI
        summary: GetExistMember API 获取更换团队领导域账号时下拉选择框 供用户选择
        description: get exist member operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: teamcode
            description: params of post to get
            required: true
            type: string
        """
        if '?' in teamcode: teamcode = teamcode.split('?', 1)[0]
        teamcode = teamcode.split('=', 1)[-1].strip()
        field = 'DISTINCT aduser, cname, ename'
        condition = "where teamcode = '{teamcode}' and enable = 1".format(teamcode=teamcode)
        rest = self.mysql.fetch_all(tablename='mpp.teamusers', field=field, condition=condition)

        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')

        return {'type': 'get', 'desc': 'getexistmembers', 'code': self.get_status(), 'rest': rest}