from swgmodel.ui.getfilepackage import *
import json
from interviews import *


class GetFilePackage(RequestHandlers):
    """
        返回文件包配置列表
    """
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def get(self, filepkgcode):
        """
            ---
        tags:
        - UI
        summary: Get File Package API 获取文件包数据
        description: get file package operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: filepkgcode
            description: filepkgcode of post to get
            required: true
            type: string
        """
        filepkgcode = filepkgcode.split('=', 1)[1]
        rest = self.mysql.fetch_all(tablename='file_package fp', field='ANY_VALUE(fp.filepkgcode) filepkgcode ,ANY_VALUE(fp.filename) filename,ANY_VALUE(fp.rfc) rfc,ifnull(mr.rlstatus,"newdev") rlstatus',
                                    condition=f"join model_release mr   on fp.filepkgcode =mr.filepkgcode  where mr.filepkgcode = '{filepkgcode}' ")
        if rest:
            self.set_status(200, 'ok')
        else:
            self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getfilepackage', 'code': self.get_status(), 'rest': rest}





