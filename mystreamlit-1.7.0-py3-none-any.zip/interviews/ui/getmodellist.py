from swgmodel.ui.getmodellist import *
import json
from interviews import *


class GetModelList(RequestHandlers):
    resdata = {"result": False,  "message": 'successful', 'context': None}

    @certifyException
    async def get(self, modelgroup):
        """
        ---
        tags:
        - UI
        summary: GetModelList API 获取模型组下的模型信息
        description: get model list operate api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: path
            name: modelgroup
            description: modelgroup of post to get
            required: true
            type: string
        """
        rest=None
        if modelgroup:
            modelgroup = modelgroup.split('=', 1)[1].strip()
            field = 'modelcode,mcode, modelname, teamcode, modelgroup, modeldesc,ifnull(status,"online") status'
            condition = f"where modelgroup = '{modelgroup}' "
            rest = self.mysql.fetch_all(tablename='models', field=field, condition=condition)

            if rest:
                self.set_status(200, 'ok')
            else:
                self.set_status(201, 'data empty')
        return {'type': 'get', 'desc': 'getmodellist', 'code': self.get_status(), 'rest': rest}








