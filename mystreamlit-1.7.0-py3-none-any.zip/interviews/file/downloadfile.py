from interviews import RequestHandlers,runsException
import json,os
from swgmodel.resultmodel import *
from lib import G
from lib.com import get_project_root


class DownLoadFile(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}
    @runsException
    async def get(self, filename):
        """
        ---
        tags:
        - File
        summary: Download File API 下载文件
        description: model file package operate api
        produces:
        - application/json
        parameters:
        -   in: path
            name: filename
            description: ID of post to get
            required: true
            type: string
        responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """
        # self.set_header('Content-Type', 'application/octet-stream')
        # self.set_header('Content-Disposition', 'attachment; filename=%s' % filename)
        filename=filename[filename.rfind('=')+1:]
        postfix = filename[filename.rfind('.') + 1:]
        path=''
        for i in [get_project_root(self.application.g['projectname']), self.application.g['modelfiledir'],postfix,filename]:
            path=os.path.join(path,i).lower()
        with open(path, 'rb') as f:
            while True:
                data = f.read(4096)
                if not data:
                    break
                self.write(data)





