from interviews import  *
import json,os
from time import time
from lib import G

class ModelfUP(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}

    @staticmethod
    async def upfile(self):
        _path = G.config_dict['mpp']['modelfiledir']
        file_metas = self.request.files.get('upfile', None) if  self.request.files.get('upfile', None) else self.request.files.get('file', None)
        filename = file_metas[0]['filename']
        prefix,postfix=filename.split('.',1)
        filename_list = self.mysql.fetch_all(tablename='file_package', field='filename', condition=f"where filename = '{filename}'")
        filename_list=[row['filename'] for row in filename_list]
        exists=[1 for fn in filename_list if fn and filename == fn]

        #  Support only ['ppd', 'm', 'pkl']
        if postfix in ['ppd', 'm', 'pkl'] and not exists:
            filepath = os.path.join(os.path.join(_path, postfix), filename).lower()
            with open(filepath, 'wb') as up:
                up.write(file_metas[0]['body'])
            self.set_status(200, 'successful')
            desc='successful'
        elif exists:
            filename=None
            self.set_status(207, 'file exists')
            desc='file exists'
        else:
            desc='file type error'
            self.set_status(207, 'file type error')
        return filename,self.get_status(),desc

    @certifyException
    async def post(self):
        """
            ---
            tags:
            - File
            summary: Uploads a file 上传文件
            consumes:
              - multipart/form-data
            parameters:
              - in: formData
                name: upfile
                type: file
                description: The file to upload.
              - in: header
                name: rlcode
                description: upfile of post to get
                required: true
                type: string
              - in: header
                name: filepkgcode
                description: filepkgcode of post to get
                required: true
                type: string
            responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """
        filepkgcode=self.request.headers.get('filepkgcode',None)
        rlcode=self.request.headers.get('rlcode',None)
        if filepkgcode and rlcode:
            filename,code,desc=await self.upfile(self)
            desc=desc if code!=200 else 'successful'
        else:
            self.set_status(208)
            desc='require rlcode '
            filename=None
        return {'type': 'get', 'desc': desc, 'code': self.get_status(), 'rest': filename}