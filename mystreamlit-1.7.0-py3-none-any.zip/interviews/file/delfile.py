from interviews import RequestHandlers,certifyException
import json, os
from lib import G
from swgmodel.resultmodel import *
from lib.com import get_project_root


class DelFile(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context': None}
    @certifyException
    async def get(self, filename):
        """
        ---
        tags:
        - File
        summary: Model File Package API 删除文件
        description: model file package operate api
        produces:
        - application/json
        parameters:
        -   in: path
            name: filename
            description: ID of post to get
            required: true
            type: string
        responses:
                200:
                  description: result of data
                  schema:
                      $ref: '#/definitions/ResultModel'
        """

        filename=filename[filename.rfind('=')+1:]
        postfix = filename[filename.rfind('.') + 1:]
        path=''
        for i in [get_project_root(self.application.g['projectname']), self.application.g['modelfiledir'],postfix,filename]:
            path=os.path.join(path,i).lower()
        # if
        res=self.mysql.delete_many(tablename='file_package',condition=f'where filename="{filename}"')
        # res2=self.mysql.delete_many(tablename='model_files',condition=f'where filename="{filename}"')
        if res  :
            os.remove(path)
            self.set_status(200, 'ok')
            rest = "delete file sucessful"
        else:
            self.set_status(202, 'file not found')
            rest = "file not found"
        return {'type': 'get', 'desc': 'file', 'code': self.get_status(), 'rest': rest}


