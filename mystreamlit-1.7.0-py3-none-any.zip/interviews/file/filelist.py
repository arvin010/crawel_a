from interviews import *


class Filelist(RequestHandlers):
    resdata = {"result": False, "message": 'successful', 'context':None}

    @certifyException
    async def get(self, rlcode):
        """
           ---
           tags:
           - File
           summary: Filelist API 返回模型所有记录
           description: get file list operate api
           produces:
           - application/json
           responses:
               200:
                 description: result of data
                 schema:
                     $ref: '#/definitions/ResultModel'
           parameters:
           -   in: path
               name: rlcode
               description: rlode of post to get
               required: true
               type: string
        """
        rlcode = rlcode.split('=', 1)[1].strip()
        rest = self.mysql.fetch_all(tablename='file_package fp', field='ANY_VALUE(fp.filepkgcode) filepkgcode ,ANY_VALUE(fp.filename )filename ',
                                    condition=f"join model_release mr   on fp.filepkgcode =mr.filepkgcode  where mr.rlcode = '{rlcode}' and mr.rlstatus  in ('online')")
        if not rest:
            self.set_status(201)

        return {'type': 'get', 'desc': 'rlcode ', 'code': self.get_status(), 'rest': rest}
