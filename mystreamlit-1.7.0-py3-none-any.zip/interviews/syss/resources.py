from interviews import *

class Resources(RequestHandlers):
    resultData = {"result": False, "message": 'successful', 'context': {}}
    async def get(self):
        try:
            model_params = self.mysql.fetch_all(tablename='model_params', field='rlcode,pname,pdatatype,isreq')
            rlcode = set([i['rlcode'] for i in model_params])
            for i in rlcode:
                self.resultData['context'][i] = {}
                self.resultData['context'][i]['data']={}
                self.resultData['context'][i]['isreq'] = []
                for m in model_params:
                    if m['rlcode'] == i:
                        self.resultData['context'][i]['data'].update({m['pname']: m['pdatatype']})
                        model_params.remove(m)
                        if m['isreq'] == 1: self.resultData['context'][i]['isreq'].append(m['pname'])

        except Exception as err:
            self.resultData['result'] = False
            self.set_status(401, 'unknown error')
            self.resultData['message'] = 'unknown error'
            self.resultData['context'] = str(err)
        finally:
            return self.render("index.html", result=self.resultData)







