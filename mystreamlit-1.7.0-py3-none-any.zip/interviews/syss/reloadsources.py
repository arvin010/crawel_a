import json
from lib.metadata import Metadata
from interviews import *

class ReloadSources(RequestHandlers):
    resultData = {"result": False, "message": 'successful','context':None}
    @authException
    async def put(self,id):
        """
        ---
        tags:
        - LoadCache
        summary:  Load the cache API 缓存
        description: Load the cache
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   name: id
            in: path
            description: ID of post to reload redis
            required: true
            type: string

        """
        self.reload_md(id = id.split('=', 1)[1])

    @authException
    async def reload_md(self,id,filename=None):
        idlist=id.split(',') if ',' in id else [id]
        idlist=[None if '*' in id else id.strip() for id in idlist]
        rest=[Metadata().meta_data(rlcode=id,filename=filename) for id in idlist]
        if rest.count(1):
            self.set_status(200, 'successful')
        else:
            self.set_status(201, 'relod failed')
        return {'type': 'post', 'desc': 'rlcode', 'code': self.get_status(), 'rest': rest, 'idlist': idlist}

