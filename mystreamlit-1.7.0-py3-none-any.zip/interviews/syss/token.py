# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-10-27 17:15:35
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-02-10 14:34:39
from swgmodel.mconf.token import *
import json
from interviews import *

class Token(RequestHandlers):
    resdata = {"result": False, "message": 'successful','context':None}

    @certifyException
    async def post(self):
        """
            ---
        tags:
        - ModelConfig
        summary:  addition token   新增认证信息
        description: get token list api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/TokenModel'
        """
        _params = json.loads(self.request.body)[0]
        rest=''
        if _params:
            if self.mysql.fetch_all(tablename='token',condition=f'''where name="{_params.get('name',None)}" or token="{_params.get('token',None)}"'''):
                self.set_status(207)
                desc='用户编码或token值已存在'
            elif not _params.get('expire',None):
                self.set_status(207)
                desc='有效期值不能为0'
            else:
                rest=self.generate_token(day=_params.get('expire',30),username=_params.get('name','auth'),passwd=_params['name'])
                desc='successful'
        return {'type': 'get', 'desc': f'{desc}', 'code': self.get_status(), 'rest': {_params.get('name',None):rest if isinstance(rest,str) else rest[1]}}

    @certifyException
    async def put(self):
        """
            ---
        tags:
        - ModelConfig
        summary:  update token   更新认证信息
        description: get token list api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/TokenModel'
        """
        _params = json.loads(self.request.body)[0]
        rest=''
        if _params:
            token=self.mysql.fetch_all(tablename='token',field='token',condition=f'''where name="{_params.get('name',None)}" or token="{_params.get('token',None)}"''')[0].get('token','') if not _params.get('token',None) else _params.get('token',None)
            if token and  _params.get('expire',None):
                rest=self.generate_token(day=_params.get('expire',30),token=token,username=_params.get('name','auth'),passwd=_params['name'])
                desc='successful'
            elif not _params.get('expire',None):
                self.set_status(207)
                desc='有效期值不能为0'
            else:
                self.set_status(207)
                desc='用户编码或token值不存在'
        return {'type': 'get', 'desc': f'{desc}', 'code': self.get_status(), 'rest': {_params.get('name',None):rest if isinstance(rest,str) else rest[1]}}

    @certifyException
    async def patch(self):
        """
            ---
        tags:
        - ModelConfig
        summary:  update token scope   更新权限范围
        description: update token scope api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/TokenScopeModel'
        """
        _params = json.loads(self.request.body)[0]
        if _params and _params.get('name',None) and _params.get('rlcode',None):
            rest=insert_(self,tablename='token_scope',key='name',key2='rlcode',col_list=['name','rlcode'],item={'name':_params['name'],'rlcode':_params['rlcode']})
        if not rest: self.set_status(207);
        desc='successful' if rest else 'failed'
        return {'type': 'get', 'desc': f'{desc}', 'code': self.get_status(), 'rest': rest}



    @certifyException
    async def get(self,name=None):
        """
            ---
        tags:
        - ModelConfig
        summary:  get token list  获取认证列表
        description: get token list api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        return {'type': 'get', 'desc': f'succeessful', 'code': self.get_status(), 'rest': self.mysql.fetch_all(tablename='token')}
