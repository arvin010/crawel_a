import uuid
import json
from swgmodel.basemodel import *
from swgmodel.resultmodel import *
from interviews import *
from mservice import model
from lib.metadata import Metadata
from dccdatetime import DccDatetime


class ModelServiceHandler(RequestHandlers):
    resdata = logdata = []
    _dccdatetime = DccDatetime()

    async def post(self):
        """
        ---
        tags:
        - ModelService
        summary: Base API 模型服务
        description: model service api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultServiceModel'
        externalDocs:
            description: Learn more about user operations provided by this API.
            url: http://10.141.147.24:37977/api/v2/resources
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                type: array
                items:
                    $ref: '#/definitions/BaseModel'

        """
        ruuid = uuid.uuid4()
        __params = json.loads(self.request.body)
        ip = self.request.remote_ip
        await self.model_service(params=__params, ruuid=ruuid,
                                 user=self.current_user, ip=ip)

    @modelException
    async def model_service(self, params, user, ip, ruuid=None):
        result = []
        rlcode_list = list(map(lambda p: p.get('rlcode', None), params))
        if None in rlcode_list:
            self.set_status(500, 'params error')
        # model_result =map(lambda param: self.runner(param,ruuid=ruuid) ,params)
        model_result = await self.runner(params[0], ruuid=ruuid)
        for inx, rest in enumerate([model_result]):
            result.append({'desc': 'rlcode', 'context': rest.get(
                'context', None), 'message': rest['code'], 'warning': rest.get('warning', None)})
        return result, rlcode_list

    async def runner(self, param, ruuid=None):
        filename = param.get('filename', None)
        if filename:
            Metadata().meta_data(rlcode=param['rlcode'], filename=filename)
        rest = await model().runs(input_params=param, ruuid=ruuid, filename=filename)
        if rest["code"] != 0:
            await self.message(param, rest)
        if not rest.get('context', None):
            rest['context'] = str(rest)
        if isinstance(rest['context'], str):
            rest['context'] = {'error': rest.get('context', None)}
        return rest

    async def message(self, param, rest):
        addrs = ["fuzi.zou@cignacmb.com", "will.shen@cignacmb.com"]
        publisher = self.mysql.fetch_all(tablename='teamusers t', field='DISTINCT email',
                                         condition=f"right join  model_release m on t.aduser =m.operator where rlcode ='{param['rlcode']}' and rlstatus ='online'")[0]['email']
        if publisher:
            addrs.append(publisher)
        DccMail().send_mail(
            subject=f"{param['rlcode']}-{rest['code']}-{time.strftime('%Y-%m-%d:%H:%M:%S', time.localtime(time.time()))}", text=f"""<p>API接收数据: {param}</p><p>入模型数据:{rest.get('context',None)}</p><p>错误内容: {rest}</p>""", receiver=','.join(addrs))
