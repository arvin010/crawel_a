import json
from swgmodel.syss.authentic import *
from interviews import *


class Login(RequestHandlers):
    resdata = {"result": False, "message": 'succeeful'}

    @nonAuthException
    async def post(self):
        """
        ---
        tags:
        - Authentic
        summary: Login API 登录接口
        description: login api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                $ref: '#/definitions/LoginModel'

        """
        _params = json.loads(self.request.body)
        self.user = _params.get("username", None)
        if self.user:self.user.lower()
        self.ip = self.request.headers.get('remote_ip', None) if not self.request.remote_ip else self.request.remote_ip
        self.passwd = _params.get("password", None)
        self.redis.delete(f"{self.user}@{self.ip}")
        await self.signin(_params)

    @signinException
    async def signin(self, _params):
        isremember = _params.get("isRemember", None)
        return {'type': 'post', 'desc': 'aduser & passwd ', 'code': self.get_status(), 'rest': [1],'isremember': isremember, 'ip': self.ip, 'idlist': [1]}


class Register(RequestHandlers):
    resdata = {"Result": False, "Message": 'Succeeded'}

    @authException
    async def post(self):
        """
        ---
        tags:
        - Authentic
        summary: Register API 注册接口
        description: register api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        parameters:
        -   in: body
            name: body
            description: post data
            required: true
            schema:
                $ref: '#/definitions/RegisterModel'

        """
        _params = json.loads(self.request.body)
        aduser = _params.get("aduser", None)
        col_list = ['aduser', 'username', 'cname', 'role', 'enable']
        value_list = [[_params.get("aduser", None), _params.get("username", None), _params.get("cname", None),
                       _params.get("role", None), _params.get("enable", 0)]]
        rest = None
        if not self.mysql.fetch_one(tablename='users', field='aduser',
                                    condition=f'where aduser = "{aduser}"') and self.user == 'SZW201208':
            rest = self.mysql.insert_many(tablename='users', col_list=col_list, value_list=value_list)
        result = {'type': 'post', 'desc': 'aduser ', 'code': self.get_status(), 'rest': [1],
                  'idlist': [1]} if rest else {'type': 'post', 'desc': 'aduser ', 'code': self.set_status(201),
                                               'rest': [], 'idlist': [1]}
        return result


class Logout(RequestHandlers):
    @authException
    async def get(self):
        """
        ---
        tags:
        - Authentic
        summary: Logout API 退出(注销)接口
        description: logout api
        produces:
        - application/json
        responses:
            200:
              description: result of data
              schema:
                  $ref: '#/definitions/ResultModel'
        """
        resdata = {"result": False, "message": 'succeessful', 'context': 1}
        self.redis.delete(f"{self.user}@{self.ip}")
        # self.clear_cookie("user")
        # self.clear_cookie("token")
        return {'type': 'post', 'desc': 'logout', 'code': self.get_status(), 'rest': [1],'idlist': [1]}

