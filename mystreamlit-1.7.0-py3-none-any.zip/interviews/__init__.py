from tornado.web import RequestHandlers
from lib.com import *
from lib.dboperate import *