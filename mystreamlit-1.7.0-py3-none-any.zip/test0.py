# from dccsend import *


# mail = DccMail()
# mail_msg = """
# <p>Python 邮件发送测试...</p>
# """
# mail.send_mail("testmail", mail_msg)


import smtplib
from email.mime.text import MIMEText
from email.header import Header

sender = 'will.shen@cignacmb.com'
receivers = ['brook.peng@cignacmb.com']  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱

mail_msg = """
<p>Python 邮件发送测试...</p>
"""
message = MIMEText(mail_msg, 'html', 'utf-8')
message['From'] = Header("test", 'utf-8')
message['To'] = Header("测试", 'utf-8')

subject = 'Python SMTP 邮件测试'
message['Subject'] = Header(subject, 'utf-8')


try:
    smtpObj = smtplib.SMTP()
    smtpObj.connect("smtp2.cmc-xinnuo.com")
    smtpObj.sendmail(sender, receivers, message.as_string())
    print("邮件发送成功")
except Exception as err:
    print("Error: 无法发送邮件", err)
