# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-10 09:18:36
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-11-30 17:40:54
#! /usr/bin/env python
# -*- coding=utf-8 -*-
import regex
import copy
import traceback

class paramRuleCheck:
    def __init__(self):
        self._result = {}

    def param_rule_check(self, input_params, md, ruuid=None):
        model_params_rule = md['model_param_rules']
        for rule in model_params_rule:
            try:
                params_value = copy.deepcopy(input_params['params'])
                if not eval(rule['rule'], dict(params_value), globals()):
                    self._result['code'] =f'''RC{"".join(list(filter(str.isdigit, rule['rulecode'])))}'''   # 规则校验错误
                    self._result['context'] = f"{rule['rulecode']} 校验失败  rule语句: {rule['rule']} "
                    break
            except Exception as err:
                print(traceback.format_exc())
                self._result['code'] = rule['rulecode']  # 规则校验错误
                self._result['context'] = f"规则语法错误:{err} [{rule['rulecode']}:{ rule['rule']}]"
                break

        if self._result == {}:
            self._result['code'] = '0'

        return self._result


if __name__ == '__main__':
    md = {'model_param_rules': [
        {'rulecode': 'r003', 'sn': 2, 'type': 'regex', 'rule': 'regex.match(r"^1[35678]\d{5}[A-Z]{4}$", phone)'}]}
    r = paramRuleCheck().param_rule_check(
        input_params={'modelcode': 'face_recognition', 'modelvers': 'v1.0.1', 'params': {'phone': '1308190ITTP', }},
        md=md)
    print(r)
