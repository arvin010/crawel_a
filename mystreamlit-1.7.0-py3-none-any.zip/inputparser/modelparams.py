# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-11 14:54:38
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-11-24 17:14:57
#! /usr/bin/env python
# -*- coding=utf-8 -*-
import numpy as np

class ModelParams():
    def __init__(self):
        self._result = {}

    def model_params(self, input_params, md, ruuid=None):
        model_params_set = md['model_params']
        # must
        if set(list(input_params['params'].keys())) >= set(
                [row['pname'] for row in model_params_set if row['isreq'] == 1]):
            # Optional
            if set(input_params['params'].keys()) <= set([row['pname'] for row in model_params_set]):
                # 判断输入的参数是否有空值None
                vaf_parm_list = [parm for parm,value in input_params['params'].items() if  value ]
                default_value_list = [[parm['pname'],parm['defaultv'],parm['pdatatype']] for parm in model_params_set ]
                for row in default_value_list:
                    locals()['input_params']['params'][row[0]] = self.value_datatype_transf(row[1],row[2]) if row[0] not in vaf_parm_list \
                        else  self.value_datatype_transf(locals()['input_params']['params'][row[0]],row[2])
                for mkey in list(set([r['pname'] for r in model_params_set if r['isformodel']==1 and not r['defaultv']]) - set(list(input_params['params'].keys()))):
                    locals()['input_params']['params'][mkey]=None

                self._result['code'] = '0'
            else:
                self._result['code'] = 'PC002'  # 非法参数
                self._result['context'] = 'illegal parameter'
        else:
            self._result['code'] = 'PC001'  # 必填
            self._result[
                'context'] = f"api params required  by : {[row['pname'] for row in model_params_set if row['isreq'] == 1]}"
        # 保存模型必须输入参数
        self._result['isformodel'] = [row['pname'] for row in model_params_set if row['isformodel'] == 1]

        return self._result


    def value_datatype_transf(self,value:str,datatype:str) -> object:
        if value == 'np.nan':
            return np.nan
        elif value == '' or value is None:
            return None
        elif datatype == 'int':
            return int(value)
        elif datatype == 'float':
            return float(value)
        elif datatype == 'str':
            return str(value)
        else:
            return value




if __name__ == '__main__':
    md = {'model_files': [{'rfc': 1.0, 'filepkgcode': 'cvmcrkomdclmxxx1v1_fpkg_1', 'filecode': 'crkomdclmxxx1_file_claim_1', 'localfilename': '/xbox/modeld/modelfile/ppd/claim.ppd'}], 'model_params': [{'pname': 'rgtno', 'pdatatype': 'str', 'isreq':1, 'isformodel': 1, 'defaultv': ''}, {'pname': 'customerno', 'pdatatype': 'str', 'isreq': 1, 'isformodel': 0, 'defaultv': ''}, {'pname': 'agentcode', 'pdatatype': 'str', 'isreq': 0, 'isformodel': 0, 'defaultv': ''},
                                                                                                                                                                                                         {'pname': 'min_claimdays', 'pdatatype': 'float', 'isreq': 1, 'isformodel': 1, 'defaultv': '0'}, {'pname': 'hospitalizeddays', 'pdatatype': 'float', 'isreq': 0, 'isformodel': 1, 'defaultv': '0'}, {'pname': 'avg_pol_amnt_prem_pct', 'pdatatype': 'float', 'isreq': 0,'isformodel': 1, 'defaultv': '0'}, {'pname': 'min_polamnt', 'pdatatype': 'float', 'isreq': 0, 'isformodel': 1, 'defaultv': '0'}, {'pname': 'accid_age', 'pdatatype': 'int', 'isreq': 0, 'isformodel': 1, 'defaultv': '0'}], 'model_param_rules': [], 'model_params_query': [{'qrcode': 'qr002', 'sn': 1, 'dscode': 'ds001', 'table_name': 'apps_ds:crim_claim_model_policy_tmr_api', 'where_condition': 'agentcode', 'cols': 'AGENTCODE,MIN_CLAIM_PAY_POL_PCT,MIN_CLAIM_AMNT', 'datatype': "{'AGENTCODE':'str','MIN_CLAIM_PAY_POL_PCT':'float','MIN_CLAIM_AMNT':'float'}", 'isreq': 1, 'ds': [{'dstype': 'hbase', 'host': '10.142.51.24', 'port': '10000', 'username': '', 'passw': '', 'db': '', 'enable': 1}]}, {'qrcode': 'qr001', 'sn': 2, 'dscode': 'ds001', 'table_name': 'apps_ds:crim_claim_model_policy_customer_api','where_condition': 'customerno', 'cols': 'CUSTOMERNO,RGT_PAY_CNT,MAX_FACE_AMOUNT_CUST,AVG_ANP_CUST', 'datatype': "{'CUSTOMERNO':'str','AGENTCODE':'str','RGT_PAY_CNT':'float','MAX_FACE_AMOUNT_CUST':'float','AVG_ANP_CUST':'float'}", 'isreq':1, 'ds': [{'dstype': 'hbase', 'host': '10.142.51.24', 'port': '10000', 'username': '', 'passw': '', 'db': '', 'enable': 1}]}], 'model_dataprocess': [{'sn': 1, 'sqlstmt': 'select\r\nt1.rgtno,\r\nt1.min_claimdays,\r\nt1.hospitalizeddays,\r\nt1.avg_pol_amnt_prem_pct,\r\nt1.min_polamnt,\r\nt1.accid_age,\r\nt2.avg_anp_cust,\r\nt2.rgt_pay_cnt,\r\nt2.max_face_amount_cust,\r\nmin(min_claim_pay_pol_pct) as min_claim_pay_pol_pct,\r\nmin(min_claim_amnt) as min_claim_amnt\r\nfrom api t1\r\nleft join qr001 t2\r\non t1.customerno=t2.customerno\r\nleft join qr002 t3\r\non t1.agentcode=t3.agentcode\r\ngroup by t1.rgtno'}]}
    m = ModelParams().model_params(input_params={'modelcode': 'face_recognition', 'modelvers': 'v1.0.0', 'params': {'customerno': 'xxxx', 'rgtno':None,'min_claimdays':None}}, md=md)

    print(m)
