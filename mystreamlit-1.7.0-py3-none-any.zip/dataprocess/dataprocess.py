# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-07-16 11:31:59
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-10-14 11:35:59
# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-07-16 11:31:59
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-08-18 14:25:38
#! /usr/bin/env python
# -*- coding=utf-8 -*-
import sys
import traceback
import json
from dcclog import DccLog
from dccdb import Pysql

class DataProcess:

    ENCODING = 'utf-8'

    def __init__(self):
        try:
            self._log = DccLog()
            self._pysql = Pysql()
            self._result = {}

        except Exception as e:
            self._log.raiseError(sys._getframe().f_code.co_name, e, traceback.format_exc())

    def data_process(self,input_params,datals,md,locflag=None,tabname_list=None,ruuid=None):
        try:
            sql= md['model_dataprocess']
            sql=[i['sqlstmt'] for i in sql if i['sn']==locflag][0]
            df = self._pysql.pysql(sql=sql, datals=datals,tabname_list = tabname_list)
            self._result['context'] = df.T.to_dict()[0]
            self._result['code'] = '0'
            return self._result
        except Exception as e:
            self._log.raiseError(sys._getframe().f_code.co_name, e, traceback.format_exc())


    def if_data_process(self,input_params,locflag,md,ruuid):
        _cnt = md['model_dataprocess']
        _cnt=[i for i in _cnt if i['sn']==locflag]
        if len(_cnt) > 0 and [i['sqlstmt'] for i in _cnt if i['sn']==locflag][0]:
            return True
        else:
            return False


if __name__=='__main__':
    md={'model_params':[1,],'model_param_rules':[1,2],'model_params_query':[1],'datasource':[1],'model_dataprocess':[],'model_files':[1],'model_release':[1]}
    datals={'abc_pct_avg2': 1.0, 'ct_lt1m_pct_max': 0.6666666666666666, 'ct_max_avg': 1069.0, 'good_pct_avg1': 0.0, 'is_freepolicy': 1.0, 'last_dur': 2046.0, 'res_status': 0.0, 'thk_ab_cnt': 1.0}
    s=DataProcess().data_process(input_params={'modelcode':'face_recognition','modelvers':'v1.0.1','params':{'phone':'1308190ITTP',}},datals=datals,md=md)
    print(s)