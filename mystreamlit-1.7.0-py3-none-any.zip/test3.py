import time

s = time.strftime('%Y-%m-%d:%H:%M:%S', time.localtime(time.time()))
print(time.strftime('%Y-%m-%d:%H:%M:%S', time.localtime(time.time())))


# print(int(time.mktime(time.strptime(s, '%Y-%m-%d:%H'))) // (24 * 60 * 60))

# print(time.strptime("2021-11-08 14:34", '%Y-%m-%d %H:%M'))


# s=b'null'
# print(s.decode())

# d= [{'AMNT1': '3690.00', 'A_CRIT_POL': '@null@', 'A_SUM_CON': '@null@', 'BEFDISRESULT': '@null@', 'BIZUNITCODE': 'CMB CC(SH)', 'B_CRIT_POL': '3192', 'B_SUM_CON': '5', 'CALLCENTER': 'SH', 'CAMPAIGNTYPE': 'Build', 'CARDTYPE': 'Mixed', 'CHNL_8CODE': '01010103', 'CITY': 'SHANGHAI', 'CONTNO': 'P00024159616', 'CONTRACT_UWERROR': '0', 'CONTRACT_UWNO': '@null@', 'CRIT_AMNT': '0.0', 'CUSTOMERLEVEL': '@null@', 'CUSTOMERTYPE': '@null@', 'CUSTOMER_AGE': '@null@', 'CUSTOMER_APPNTSEX': '@null@', 'CUSTOMER_IDTYPE': '@null@', 'CUSTOMER_MARRIAGE': '@null@', 'CUSTOMER_SENSITIVECODE': '@null@', 'CUSTOMER_SMOKEFLAG': '@null@', 'CVMORNOT': 'N', 'DELIVERYMETHOD': 'P', 'DISEASECODE': '@null@', 'EXCEPTIONCODE': '@null@', 'H_RNEWFLAG': '-2', 'INSUREDSEX': '0', 'INSURED_AGE': '25.0', 'INSURED_IDTYPE': 'I', 'INSURED_MARRIAGE': '2', 'INSURED_SMOKEFLAG': 'N', 'INSURED_UWERROR': '0', 'INSURED_UWNO': '@null@', 'INSUYEARFLAG': 'A', 'MANAGECOM': '8601000001', 'MIN_PAYYEARS': '0', 'MIN_YEARS': '125', 'M_CLAIMTIMES': '0', 'M_FLOATRATE': '1.0000000000', 'M_INSUYEAR': '150', 'M_MULT': '1', 'M_PAYENDYEAR': '10', 'N_ADDPOLNO': '1', 'N_MAINPOLNO': '1', 'N_POLNO': '2', 'N_RISKCODE': '2', 'PAYENDYEARFLAG': 'Y', 'PAYINTV1': '12', 'PAYMODE': '4', 'PREM1': '10000.00', 'PREMBUDGET': '@null@', 'PRODUCTSUBTYPE': 'ROP DD V', 'PRODUCTTYPE': 'ROP', 'PROSPECTSOURCE': 'BAU', 'PROSPECTTYPE': 'OB', 'REGIONAL': 'East', 'RELATIONTOAPPNT': '00', 'RISKNAME': '招商信诺年金保险（万能型）', 'RISK_UWERROR': '0', 'RISK_UWNO': '@null@', 'SALECHNL': '01', 'SALECHNL1': '01', 'SALECHNL2': '01', 'SALECHNL3': '03', 'SIGNCOM': '8601000001', 'SPECIALCONTTYPE': '4', 'SPONSORNAME': 'CMB CC', 'SUBCHANNEL': 'Digital and TM Sales', 'SUMSCORE': '@null@', 'SUSPICIOUSTYPE': '@null@', 'S_RISKAMNT': '7380.0', 'S_RISKPERIOD_L': '4', 'S_RISKPERIOD_M': '0', 'S_RISKPERIOD_S': '0', 'S_RISKTYPE_H1': '0', 'S_RISKTYPE_H2': '0', 'S_RISKTYPE_L1': '0', 'S_RISKTYPE_L2': '0', 'S_RISKTYPE_L3': '0', 'S_RISKTYPE_R1': '2', 'S_RISKTYPE_R2': '2', 'S_SUMPREM': '200000.0', 'TAXIDENTITY': '1', 'VIPGRADE': '@null@', 'VIPTYPE': '@null@'}]

# for k,v in d[0].items():
# 	# print(k,v)

# 	if '@null@' == v:

# 		print(2222222222)

# rest=[{key:None if  value =='@null@'  else value for key,value in row.items() } for row in d]
# # print(rest)


# dtypes= {"HOLDER_CITY": "str", "HOLDER_NOW_AGE": "float", "IF_ACT_DD": "float", "L24MTH_ADD_CNT": "float", "L3MTH_PAYCNT": "float", "LST_LAPSED_GAP": "float", "LST_OB_GAP": "float", "LST_TBWL_DATE": "str", "OVERDUE_RATE": "float", "POLICYNO": "str", "TB_ANN_FLAG": "float", "TB_ANP": "float", "TB_FACEAMT": "float", "TB_LST_PAYTONOW_PCT": "float", "TB_PAYCOUNT": "float", "TB_PRODCODE_TENURE_MAX": "float", "HOLDER_PROVINCE": "str", "LST_TBWL_TO_NOW": "float", "TB_PRODCODE": "str", "TB_EXTRA1": "str"}


# rest=[{ "policyno": "P21V001563",
# 	 "usrid": "M8LIXX",
# 	 "batch_no": "000",
# 	 "L24MTH_ADD_CNT": "0",
# 	 "TB_PAYCOUNT": "5",
# 	 "L3MTH_PAYCNT": "0",
# 	 "TB_LST_PAYTONOW_PCT": "12.59",
# 	 "TB_ANP": "1317.5",
# 	 "TB_PRODCODE_TENURE_MAX": "0",
# 	 "LST_OB_GAP": "137.4",
# 	 "TB_FACEAMT": "250000.0",
# 	 "OVERDUE_RATE": null,
# 	 "HOLDER_NOW_AGE": "42",
# 	 "IF_ACT_DD": "0",
# 	 "LST_LAPSED_GAP": "138.0",
# 	 "TB_ANN_FLAG": "0",
# 	 "HOLDER_CITY": "北京市",
# 	 "CSR_L6MTH_TBWL_AHMANP": None,
# 	 "CSR_L1MTH_MAX_SUC_TENURE": None,
# 	 "CSR_EDU_NUM": "3",
# 	 "CSR_GRADE": None,
# 	 "csr_age_gap": None,
# 	 "csr_ifsame_prov": 0,
# 	 "lst_tbwl_to_now": "138.0",
# 	 "csr_l3mth_tbwl_prodcsuccnt": None,
# 	 "csr_l1mth_tbwl_extra1sucrate": None,
# 	 "csr_l3mth_tbwl_extra1_ifhigh": "0",
# 	 "lst_tbwl_date": "2010-01-01" }]


# [ { "policyno": "P21V001563", "usrid": "M8LIXX", "batch_no": "000", "L24MTH_ADD_CNT": "0", "TB_PAYCOUNT": "5", "L3MTH_PAYCNT": "0", "TB_LST_PAYTONOW_PCT": "12.59", "TB_ANP": "1317.5", "TB_PRODCODE_TENURE_MAX": "0", "LST_OB_GAP": "137.4", "TB_FACEAMT": "250000.0", "OVERDUE_RATE": null, "HOLDER_NOW_AGE": "42", "IF_ACT_DD": "0", "LST_LAPSED_GAP": "138.0", "TB_ANN_FLAG": "0", "HOLDER_CITY": "北京市", "CSR_L6MTH_TBWL_AHMANP": null, "CSR_L1MTH_MAX_SUC_TENURE": null, "CSR_EDU_NUM": "3", "CSR_GRADE": null, "csr_age_gap": null, "csr_ifsame_prov": 0, "lst_tbwl_to_now": "138.0", "csr_l3mth_tbwl_prodcsuccnt": null, "csr_l1mth_tbwl_extra1sucrate": null, "csr_l3mth_tbwl_extra1_ifhigh": "0", "lst_tbwl_date": "2010-01-01" } ]


# rest=[{key:eval(f'''{dtypes[f"{key}"]}("{value}")''')  if value and dtypes.get(f"{key}",None)  else value for key,value in row.items() } for row in rest]

# print(rest)
