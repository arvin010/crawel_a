import pandas as pd
import numpy as np
import os
import dill
import pickle
# from sklearn.externals import joblib
import joblib
from types import FunctionType, CodeType
import sys
import time
from tornado import httpserver, options, ioloop
from lib.com import get_host_ip
from setup import Setup
from lib.logcollect import LogService
from multiprocessing import Process
from lib.initaliza import Initializa
from lib import G

MODELFILEINSTANCE = None


class Service():
    def __init__(self):
        self.app_service()

    def app_service(self):
        Initializa()
        self.g = G.config_dict['mpp']
        # options.options.logging = "debug"
        options.parse_command_line()
        app = Setup()
        httpServer = httpserver.HTTPServer(app)
        httpServer.bind(self.g['port'], address=self.g['host'])
        httpServer.start()
        G.mlog.info(f"          |*** run time ... {time.ctime()}", func=sys._getframe().f_code.co_name)
        G.mlog.info(f"          |*** run {get_host_ip()}:{self.g['port']}", func=sys._getframe().f_code.co_name)
        ioloop.IOLoop.current().start()



if __name__=='__main__':
    Service()