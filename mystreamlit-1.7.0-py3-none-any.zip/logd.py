# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-11-02 09:16:04
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-21 10:23:09
import os
import sys
import time
from lib.com import get_host_ip
from lib.logcollect import LogService
from lib import G

MODELFILEINSTANCE = None


class Logd():
    def __init__(self):
        self.log_service()

    def log_service(self):
        _log = LogService()
        while True:
            _log.log_read()
            _log.log_write()
            time.sleep(6)
            G.mlog.info(f"          |*** log collect run time... {time.ctime()}", func=sys._getframe().f_code.co_name)


if __name__=='__main__':
    Logd()