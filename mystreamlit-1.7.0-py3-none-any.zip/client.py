# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-12-09 16:30:49
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-12-09 17:04:43
#客户端
import socket 
import struct
import os
import json
 
client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client.connect(("127.0.0.1",3008))
print("connect success.....")
filepath = "G://fs/upload/公共/hadoop-2.10.1.tar.gz"
img = open(filepath,"rb")
print(len(img.read()))
 
client.sendall(img.read())
img.close()
client.close()