import requests
import json,base64


def sign(user,pwd):
    login_url = 'http://10.142.145.185:8009/login'
    headers = {
        "Accept": "application/json, text/javascript, */*; q=0.01"
    }
    body = {'username': base64.b64encode(bytes(user,'utf-8')).decode('utf-8'), 'pwd': base64.b64encode(bytes(pwd,'utf-8')).decode('utf-8'), 'oreb': True}
    try:
        cookies = requests.post(url=login_url, headers=headers, data=json.dumps(body)).cookies.items()
        cookie = ''
        for name, value in cookies:
            cookie += f'{name}={value};'
        return cookie
    except Exception as err:
        print('获取cookie失败：\n{0}'.format(err))


def downloadfile(token,filename):
    headers={"Proxy-Connection": "keep-alive",
    "Pragma": "no-cache",
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36",
    "Accept-Language": "zh-CN,zh;q=0.8,en-US;q=0.6,en;q=0.4",
    "Referer": "www.xxx.com",
    "Accept-Charset": "gb2312,gbk;q=0.7,utf-8;q=0.7,*;q=0.7",
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Encoding":"gzip, deflate, sdch",
    "Cache-Control":"max-age=0",
    "Connection":"keep-alive",
    "Content-Type":"application/x-www-form-urlencoded",
    "Host":"127.0.0.1",
    "Upgrade-Insecure-Requests":"1",
    "X-Requested-With":"XMLHttpRequest"}
    headers.update(token)
    r=requests.session().post(f'http://10.142.145.185:8009/downloadfile/公共/{filename}',headers=headers)
    print(r.status_code)
    if r.status_code==200:
        with open(filename,'wb') as f:
            f.write(r.content)


if __name__=='__main__':
    cookie=sign(user='szw201208',pwd='Sxx..,,0')
    print(cookie)
    token={'user': 'szw201208','Cookie':cookie}
    filename='模型文件.zip'
    downloadfile(token=token,filename=filename)


