# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-13 14:23:52
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-20 17:51:48
from handles.doc.doc import *


doc_route=[
    # doc
    url(f"{G.prefix_ver}docconfig/?", DocConfig),
    url(f"{G.prefix_ver}docruns/?", DocRuns),
    url(f"{G.prefix_ver}docrealease/?", DocRealease),
    url(f"{G.prefix_ver}dochomepage/?", DocHomePage),
    url(f"{G.prefix_ver}docmodelgroups/?", DocModelGroups),
    url(f"{G.prefix_ver}docmglist/?", DocMGList),
    url(f"{G.prefix_ver}docmgmanagement/?", DocMGManagement),

]