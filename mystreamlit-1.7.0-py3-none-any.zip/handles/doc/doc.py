# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-13 14:14:33
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-09-02 10:01:04
#!/usr/bin/env python
# coding=utf-8
#DOC
from handles import *
from interviews.doc.docconfig import DocConfig
from interviews.doc.docruns import DocRuns
from interviews.doc.docrealease import DocRealease
from interviews.doc.dochomepage import DocHomePage
from interviews.doc.docmodelgroups import DocModelGroups
from interviews.doc.docmglist import DocMGList
from interviews.doc.docmgmanagement import DocMGManagement