#!/usr/bin/env python
# coding=utf-8
#UI
from handles import *
from interviews.ui.getdatatype import GetDataType
from interviews.ui.getdscode import GetDSCode
from interviews.ui.topfive import TopFive
from interviews.ui.reactiontime import ReactionTime
from interviews.ui.frequency import Frequency
from interviews.ui.getruletype import GetRuleType
from interviews.ui.getfilepackage import GetFilePackage
from interviews.ui.getinput import GetInput
from interviews.ui.getmodelrealease import GetModelRealease
from interviews.ui.getmodellist import GetModelList
from interviews.ui.getitems import GetItems
from interviews.ui.getteamname import GetTeamName
from interviews.ui.getteamlist import GetTeamList
from interviews.ui.addfilepkg import AddFilePkg
from interviews.ui.addmodergroup import AddModelGroups
from interviews.ui.addmodel import AddModel
from interviews.ui.getmodeldesc import GetModelDesc
from interviews.ui.getmparamsconfig import GetMParamsConfig
from interviews.ui.getmparamrules import GetMParamRules
from interviews.ui.getmparamquery import GetMParamQuery
from interviews.ui.getmdataprocess import GetMDataProcess
from interviews.ui.getmodegrouplist import GetModelGroupList
from interviews.ui.getteams import GetTeams
from interviews.ui.addmodelrelease import AddModelRelease
from interviews.ui.duplicate import Duplicate
from interviews.ui.getdtype import GetDtype
from interviews.ui.publish import Publish
from interviews.ui.advfilteroperator import AdvFilterOperator
from interviews.ui.advfilterfields import AdvFilterFields
from interviews.ui.advancedfilter import AdvancedFilter
from interviews.ui.search import Search
from interviews.ui.createteams import CreateTeams
from interviews.ui.getmglback import Getmglback
from interviews.ui.changerole import ChangeRole
from interviews.ui.adddatasource import AddDataSource  # 另外写添加数据源接口
from interviews.ui.addteammembers import AddTeamMembers  # 另外写添加团队成员接口
from interviews.ui.getexistmembers import GetExistMembers  # 另外更换团队长-已存在团员列表
from interviews.ui.teammemberhandle import TeamMemberHandle  # 另外添加删除团队成员




