from handles.ui.ui import *


ui_route=[

    # UI
    url(f"{G.prefix_ver}getdatatype/?", GetDataType),
    url(f"{G.prefix_ver}getdscode/?", GetDSCode),
    url(f"{G.prefix_ver}top5/?", TopFive),
    url(f"{G.prefix_ver}reactiontime/?", ReactionTime),
    url(f"{G.prefix_ver}frequency/?", Frequency),
    url(f"{G.prefix_ver}getruletype/?", GetRuleType),
    url(f"{G.prefix_ver}getruletype/?", GetRuleType),
    url(f"{G.prefix_ver}getfilepackage/(?P<filepkgcode>.+)?", GetFilePackage),
    url(f"{G.prefix_ver}getinput/(?P<rlcode>.+)?", GetInput),
    url(f"{G.prefix_ver}getmodelrealease/(?P<modelcode>.+)?", GetModelRealease),
    url(f"{G.prefix_ver}getmodellist/(?P<modelgroup>.+)?", GetModelList),
    url(f"{G.prefix_ver}getitems/?", GetItems),
    url(f"{G.prefix_ver}getteamname/(?P<aduser>.+)?", GetTeamName),
    url(f"{G.prefix_ver}getteamlist/(?P<params>.+)?", GetTeamList),  # 分页测试
    url(f"{G.prefix_ver}addfilepkg/(?P<rlcode>.+)?", AddFilePkg),
    url(f"{G.prefix_ver}addmodelgroups/?", AddModelGroups),
    url(f"{G.prefix_ver}addmodel/?", AddModel),
    url(f"{G.prefix_ver}getmodeldesc/(?P<rlcode>.+)?", GetModelDesc),
    url(f"{G.prefix_ver}getmparamsconfig/(?P<rlcode>.+)?", GetMParamsConfig),
    url(f"{G.prefix_ver}getmparamrules/(?P<rlcode>.+)?", GetMParamRules),
    url(f"{G.prefix_ver}getmparamquery/(?P<rlcode>.+)?", GetMParamQuery),
    url(f"{G.prefix_ver}getmdataprocess/(?P<rlcode>.+)?", GetMDataProcess),
    url(f"{G.prefix_ver}getmodelgrouplist/(?P<aduser>.+)?", GetModelGroupList),
    url(f"{G.prefix_ver}getteams/(?P<aduser>.+)?", GetTeams),
    url(f"{G.prefix_ver}addmodelrelease/(?P<rlcode>.+)?", AddModelRelease),
    url(f"{G.prefix_ver}duplicate/(?P<rlcode>.+)?", Duplicate),
    url(f"{G.prefix_ver}getdtype/(?P<tablename>.+)?", GetDtype),
    url(f"{G.prefix_ver}publish/(?P<rlcode>.+)?", Publish),
    url(f"{G.prefix_ver}advancedfilter/?", AdvancedFilter),  # 高级筛选
    url(f"{G.prefix_ver}advfilterfields/?", AdvFilterFields),
    url(f"{G.prefix_ver}advfilteroperator/?", AdvFilterOperator),
    url(f"{G.prefix_ver}search/?", Search),  # 文本框搜索
    url(f"{G.prefix_ver}createteams/?", CreateTeams),  # 添加团队
    url(f"{G.prefix_ver}getmglback/(?P<params>.+)?", Getmglback),  # 后台模型组管理显示
    url(f"{G.prefix_ver}changerole/(?P<id>.+)?", ChangeRole),  # 更换团队长
    url(f"{G.prefix_ver}adddatasource/(?P<id>.+)?", AddDataSource),  # 另写添加数据源接口
    url(f"{G.prefix_ver}addteammembers/(?P<id>.+)?", AddTeamMembers),  # 另写添加团队成员接口
    url(f"{G.prefix_ver}getexistmembers/(?P<teamcode>.+)?", GetExistMembers),  # 新增更换领导角色--团员名单
    url(f"{G.prefix_ver}teammemberhandle/(?P<params>.+)?", TeamMemberHandle),  # 新增团队成员操作--逻辑删除
]