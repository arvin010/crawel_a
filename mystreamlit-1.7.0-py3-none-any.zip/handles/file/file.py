# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-13 14:13:42
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-09-02 10:01:11
#!/usr/bin/env python
# coding=utf-8
#FILE
from handles import *
from interviews.file.modelfup import ModelfUP
from interviews.file.downloadfile import DownLoadFile
from interviews.file.delfile import DelFile
from interviews.file.filelist import Filelist