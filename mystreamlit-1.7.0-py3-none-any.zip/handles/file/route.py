# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-13 14:29:46
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-20 18:02:06
from handles.file.file import *


file_route=[
    # file
    url(f"{G.prefix_ver}upfile/?", ModelfUP),
    url(f"{G.prefix_ver}downloadfile/(?P<filename>.+)", DownLoadFile),
    url(f"{G.prefix_ver}delfile/(?P<filename>.+)", DelFile),
    url(f"{G.prefix_ver}filelist/(?P<rlcode>.+)", Filelist),


]