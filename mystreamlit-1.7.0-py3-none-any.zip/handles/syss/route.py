# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-13 14:29:58
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-20 18:02:01
from handles.syss.syss import *


syss_route=[
    #  sigin sigout
    url(f"{G.prefix_ver}register/?", Register),
    url(f"{G.prefix_ver}login/?", Login),
    url(f"{G.prefix_ver}logout/?", Logout),
    # modelservice
    url(f"{G.prefix_ver}modelservice/?", ModelServiceHandler),
    url(f"{G.prefix_ver}modeltest/?", ModelTestHandler),
    url(f"{G.prefix_ver}resources/?", Resources),
    url(r"/static/(.*)", StaticFileHandler, {"path": "/var/www"}),
    url(f"{G.prefix_ver}models/(?P<id>.+)?", Models),
    url(f"{G.prefix_ver}reloadsouces/(?P<id>.+)", ReloadSources),
    url(f"{G.prefix_ver}token/?", Token),
]