# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-13 14:13:28
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-11-08 14:52:41
#!/usr/bin/env python
# coding=utf-8
from lib import G
from tornado.web import url,StaticFileHandler
from interviews.syss.modelcall import ModelServiceHandler
from interviews.syss.modeltest import ModelTestHandler
from interviews.mconf.models import Models
from interviews.syss.auths import Register, Login, Logout
from interviews.syss.resources import Resources
from interviews.syss.reloadsources import ReloadSources
from interviews.syss.token import Token

