# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-11 09:35:38
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-09-02 10:00:29
#!/usr/bin/env python
# coding=utf-8
from handles.syss.route import *
from handles.mconf.route import *
from handles.file.route import *
from handles.ui.route import *
from handles.doc.route import *

routes.extend(syss_route)
routes.extend(mconf_route)
routes.extend(file_route)
routes.extend(ui_route)
routes.extend(doc_route)

