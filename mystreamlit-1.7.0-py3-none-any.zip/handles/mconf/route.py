# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-13 14:29:52
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-20 18:02:02
from handles.mconf.mconf import *


mconf_route=[
    # modelconfig
    url(f"{G.prefix_ver}modelparams/(?P<id>.+)?", ModelParams),
    url(f"{G.prefix_ver}modelparamrule/(?P<id>.+)?", ModelParamRule),
    url(f"{G.prefix_ver}modelparamquery/(?P<id>.+)?", ModelParamQuery),
    url(f"{G.prefix_ver}modeldataprocess/(?P<id>.+)?", ModelDataProcess),
    url(f"{G.prefix_ver}datasource/(?P<id>.+)?", DataSource),
    url(f"{G.prefix_ver}filepackage/(?P<id>.+)?", FilePackage),
    url(f"{G.prefix_ver}modelfiles/(?P<id>.+)?", ModelFiles),
    url(f"{G.prefix_ver}modelgroups/(?P<id>.+)?", ModelGroups),
    url(f"{G.prefix_ver}modelrelease/(?P<id>.+)?", ModelRelease),
    url(f"{G.prefix_ver}modelvers/(?P<id>.+)?", ModelVers),
    url(f"{G.prefix_ver}items/?", Items),
    url(f"{G.prefix_ver}users/(?P<id>.+)?", Users),
    url(f"{G.prefix_ver}teams/(?P<id>.+)?", Teams),
    url(f"{G.prefix_ver}teamusers/(?P<id>.+)?", Teamusers),

]