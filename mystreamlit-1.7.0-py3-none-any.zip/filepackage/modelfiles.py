#! /usr/bin/env python
# -*- coding=utf-8 -*-
from lib.com import logs
import random,json

class ModelFiles():
    def __init__(self):
        self._result={}
    @logs
    def model_files(self,md,ruuid=None):
        res=md['model_files']
        if len(res)>1:
            self._result['modelfile']= self._random_pick(rfc_list = [(i['rfc'],i['filename'],i['filepkgcode']) for i in res],ruuid=ruuid)
            self._result['code'] = '0'
        elif len(res)==1:
            self._result['modelfile']=(res[0]['filename'],res[0]['filepkgcode'])
            self._result['code'] = '0'
        else:
            self._result['code'] = 'FP001'
        return self._result

    def _random_pick(self,rfc_list,ruuid=None):
        '''
        [(rfc,file),(rfc,file)]
        '''
        x = random.uniform(0,1)
        rfc_tot = 0.0
        for rfc,filename,filepkgcode in rfc_list:
            rfc_tot += float(rfc)
            if x <= rfc_tot:
                break
        return filename,filepkgcode



if __name__=='__main__':
    md={'model_params':[1,],'model_param_rules':[1,2],'model_params_query':[1],'datasource':[1],'model_dataprocess':[],'model_files':[1],'model_release':[1]}
    m=ModelFiles().model_files(md=md)
    print(m)