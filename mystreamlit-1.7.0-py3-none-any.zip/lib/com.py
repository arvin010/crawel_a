#! /usr/bin/env python
# -*- coding=utf-8 -*-
import os
import sys
import traceback
import socket
import random
import string
from datetime import date, datetime
import numpy as np
import decimal
import time
import functools
import json
from lib.dbconn import *
from lib import G
import datetime
from decimal import *
from dccsend import *
import asyncio


def __func_params(func, *args, **kwargs):
    dict_param = {}
    if len(args) > 0:
        var_names = func.__code__.co_varnames
        if len(args) == len(var_names):
            dict_param = {var_names[i]: args[i] for i in range(len(var_names))}
    if len(kwargs) > 0:
        dict_param.update(kwargs.items())
    return dict_param


class ComplexEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        elif isinstance(obj, decimal.Decimal):
            return float(obj)
        else:
            return json.JSONEncoder.default(self, obj)


def logs(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        t_begin = time.time()
        func_params = __func_params(func, *args, **kwargs)
        result = func(*args, **kwargs)
        t_end = time.time()
        def f(x): return Redis(db=6).conn().lpush(
            f"{func_params.get('ruuid',None)}", x)
        if func.__name__ == 'model_call':
            f(json.dumps({'method': func.__name__, 'modelinput': func_params['model_data'], 'result': result,
                          'begintime': t_begin,
                          'endtime': t_end}))
        elif func.__name__ == 'model_files':
            f(json.dumps(
                {'method': func.__name__, 'filepkgcode': result['modelfile'][1], 'filename': result['modelfile'][0],
                 'begintime': t_begin, 'endtime': t_end}))
        else:
            f(json.dumps({'method': func.__name__,
                          'begintime': t_begin, 'endtime': t_end}))
        G.mlog.info(
            f"[ {func.__name__} ] executed time in : {t_end - t_begin}")
        return result

    return wrapper


def authException(func):
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            if not self.current_user:
                raise ValueError('authentic  failed')
            result = await func(self, *args, **kwargs)
            # for result in _result: result=result
            # try:
            #     result = dict(result)
            # except Exception as err:
            #     result=eval(str(_result))
            if self.get_status() not in G.code and not result['rest']:
                self.set_status(201, 'empty data')
            if result.get('idlist', None):
                if result['type'] != 'get' and (result['rest'].count(1) == len(result['idlist'])) and result['idlist'] and self.get_status() == 200:
                    self.set_status(200, 'successful')
                elif result['type'] == 'get' and len(result['rest']) == len(result['idlist']) and result['idlist'] and self.get_status() == 200:
                    self.set_status(200, 'successful')
            else:
                raise ValueError('idlist not found')
            self.resdata['result'], self.resdata['message'], self.resdata['context'] = __result_context(
                result, self.get_status())
            self.resdata['code'] = self.get_status()
        except Exception as err:
            if 'authorities' in str(err):
                self.set_status(405, 'authentic  failed')
                self.resdata = {"result": False, "message": '-1',
                                'context': 'authentic  failed', 'code': self.get_status()}
            else:
                self.set_status(401, 'unknown parameter error')
                self.resdata = {"result": False, "message": '-1',
                                'code': self.get_status(), 'context': traceback.format_exc()}
        finally:
            G.mlog.info(
                f"[]:[ {func.__name__} ] executed result : {self.resdata}")

            self.write(json.dumps(
                self.resdata, default=str, ensure_ascii=False))

    return wrapper


def certifyException(func):
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            if not self.current_user:
                raise ValueError('authentic  failed')
            result = await func(self, *args, **kwargs)
            # for result in _result: result=result
            # try:
            #     result = dict(result)
            # except Exception as err:
            #     result=eval(str(_result))
            if self.get_status() not in G.code and not result['rest']:
                self.set_status(201, 'empty data')
            if not result.get('idlist', None):
                if self.get_status() == 200:
                    self.set_status(200, 'successful')
            else:
                raise ValueError('decorator error')
            self.resdata['result'], self.resdata['message'], self.resdata['context'] = __result_context(
                result, self.get_status())
            self.resdata['code'] = self.get_status()
            # return result
        except Exception as err:
            if 'authorities' in str(err):
                self.set_status(405, 'authentic  failed')
                self.resdata = {"result": False, "message": '-1',
                                'context': 'authentic  failed', 'code': self.get_status()}
            else:
                self.set_status(401, 'unknown  parameter error')
                self.resdata = {"result": False, "message": '-1',
                                'code': self.get_status(), 'context': traceback.format_exc()}
        finally:
            G.mlog.info(
                f"[]:[ {func.__name__} ] executed result : {self.resdata}")
            self.write(json.dumps(
                self.resdata, default=str, ensure_ascii=False))

    return wrapper


def runsException(func):
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            if not self.current_user:
                raise ValueError('authentic  failed')
            await func(self, *args, **kwargs)
        except Exception as err:
            if 'authentic  failed' in str(err):
                self.set_status(405, 'authentic  failed')
                self.resdata = {"result": False, "message": '-1',
                                'context': 'authentic  failed', 'code': self.get_status()}
            else:
                self.set_status(401, 'unknown parameter error')
                self.resdata = {"result": False, "message": '-1',
                                'code': self.get_status(), 'context': traceback.format_exc()}
        finally:
            G.mlog.info(
                f"[]:[ {func.__name__} ] executed result : {self.resdata}")
            self.write(json.dumps(self.resdata, default=str))
    return wrapper


def nonAuthException(func):
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            await func(self, *args, **kwargs)
        except Exception as err:
            G.mlog.info(
                f"[]:[ {func.__name__} ] executed  : {traceback.format_exc()}")
    return wrapper


def signinException(func):
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        try:
            _result = await func(self, *args, **kwargs) if self.authentic() else {'type': 'post', 'desc': 'username & passwd ', 'code': self.set_status(210), 'rest': ['username & passwd'], 'idlist': [1]}
            for result in _result:
                result = result
            try:
                result = dict(result)
            except Exception as err:
                result = eval(str(_result))
            self.resdata['result'], self.resdata['message'], self.resdata['context'] = __result_context(
                result, self.get_status())
            if self.resdata['result']:
                self.resdata['context'] = {self.user: self.generate_token(
                    result['ip'], result['isremember'])}
            self.resdata['code'] = self.get_status()
            # return result
        except Exception as err:
            self.resdata = {"result": False, "message": 'unknown parameter error',
                            'code': self.get_status(), 'context': f"{traceback.format_exc()}"}
            self.set_status(401, 'unknown parameter error')
        finally:
            G.mlog.info(
                f"[]:[ {func.__name__} ] executed result : {self.resdata}")
            self.write(json.dumps(
                self.resdata, default=str, ensure_ascii=False))
    return wrapper


def modelException(func):
    @functools.wraps(func)
    async def wrapper(self, *args, **kwargs):
        t_begin = time.time()
        params = __func_params(func, *args, **kwargs)
        try:
            if not self.current_user:
                raise ValueError('authentic  failed')
            result, rlcode_list = await func(self, *args, **kwargs)
            # for item in _result: results=item
            # result = results[0]
            # rlcode_list=results[1]
            self.resdata = list(map(
                lambda item: {'result': True if item['message'] == '0' else True, 'message': item['message'],
                              'context': item['context'], 'warning': item['warning'], 'code': self.get_status()}, result))
            c = self.set_status(200, 'successful') if len(
                list(filter(lambda x: x['result'] == True, self.resdata))) == len(rlcode_list) else self.set_status(
                202, 'excute error')
        except Exception as err:
            if 'authorities' in str(err):
                self.set_status(405, 'authentic  failed')
                self.resdata = [{"result": False, "message": '-1',
                                 'context': 'authentic  failed', 'code': self.get_status()}]
            else:
                self.set_status(207, 'unknown parameter error')
                self.resdata = [{"result": False, "message": 'unknown parameter error',
                                 'code': self.get_status(), 'context': traceback.format_exc()}]
        finally:
            t_end = time.time()
            self.resdata = self.resdata[0]
            if isinstance(self.resdata['context'], str):
                self.resdata['context'] = {'error': self.resdata['context']}
            if isinstance(self.resdata['context'], list):
                self.resdata['context'] = self.resdata['context'][0]
            if params['params'][0].get('params', None).get('batch_no', None):
                self.resdata['batch_no'] = params['params'][0]['params']['batch_no']
            G.mlog.info(
                f"[]:[ {func.__name__} ] executed result : {self.resdata}")
            Redis(db=6).conn().lpush(f'{params["ruuid"]}', json.dumps(
                {'method': func.__name__, 'ip': params.get('ip', None), 'user': params.get('user', None), 'appinput': params.get('params', None),
                 'result': self.resdata,
                 'begintime': t_begin, 'endtime': t_end}, cls=ComplexEncoder))
            self.write(json.dumps(
                self.resdata, default=str, ensure_ascii=False))

    return wrapper


def replaces(string):
    string = string.replace('\\', '\\\\')
    string = string.replace("'", '"')
    return string


def __result_context(result, code):
    if code == 500:  #
        return False, f'required {result.get("rest",None)}', None
    elif code == 201:  #
        return True, '', result.get('rest', None)
    elif code == 202:  #
        return True, '', result.get('rest', None)
    elif code == 210:  #
        return False, f"authentic  failed", result.get('rest', None)
    elif code == 203:  #
        return False, f"{result.get('desc',None)} exist", None
    # elif code == 205:  #
    #     return False, f"{result.get('desc',None)} file type error", result.get('rest',None)
    elif result['type'] != 'get' and code == 200:
        return True, f"succesful", result['rest'].count(1)
    elif result['type'] == 'get' and code == 200:
        return True, f" succesful", result['rest']
    else:
        return False, f"{result['desc']}", result.get('rest', None)


def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()

    return ip


def get_host_name():
    return socket.getfqdn(socket.gethostname())


def get_project_root(projectname: str) -> str:
    curPath: str = os.path.abspath(os.path.dirname(__file__))
    if 'win32' in sys.platform:
        rootPath = curPath[:curPath.find(
            f"{projectname}\\") + len(f"{projectname}\\")]
    elif 'linux' in sys.platform:
        rootPath = curPath[:curPath.find(
            f"{projectname}/") + len(f"{projectname}")]
    return rootPath


async def coroutine_p(result):
    for result in _result:
        result = result
    try:
        result = dict(result)
    except Exception as err:
        result = eval(str(_result))
    await result


def random2string(num: int = 8) -> str:
    return ''.join(random.sample(string.digits + string.ascii_letters, num))


def value_datatype_transf(value: str, datatype: str) -> object:
    if value == 'np.nan':
        return np.nan
    elif value == '' or value is None:
        return None
    elif datatype == 'int':
        return int(value)
    elif datatype == 'float':
        return float(value)
    elif datatype == 'str':
        return str(value)
    else:
        return value


class Pagination:
    """
        数据的分页显示
    """

    def __init__(self, current_page, all_item, page_limit):  # 当前页 内容总数
        try:
            pagenum = int(current_page)
        except:
            pagenum = 1
        if pagenum < 1:
            pagenum = 1
        all_page, c = divmod(all_item, page_limit)  # all_page计算总页数 c剩余条数
        if c > 0:  # 如果剩余条数大于0，则在总页数的基础上加1，简单来说就是不够1页算1页
            all_page += 1
        self.current_page = pagenum  # 前端希望传哪一页的数据从page带过来
        self.all_page = all_page  # 总分页数
        self.page_limit = page_limit  # 每页多少条记录

    @property
    def page_start(self):  # 某页开始位
        return (self.current_page - 1) * self.page_limit

    @property
    def page_end(self):  # 某页结束位
        return self.current_page * self.page_limit
