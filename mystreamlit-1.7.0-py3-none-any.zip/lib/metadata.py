#! /usr/bin/env python
# -*- coding=utf-8 -*-

import pickle, joblib
from interviews import *
from lib import G


class Metadata(Mysql):

    def __init__(self):
        self.resdata={}
        self._md = {}
        self._file = {}
        self._path = os.path.join(get_project_root(G.config_dict['mpp']['projectname']), G.config_dict['mpp']['modelfiledir'])

    def meta_data(self, rlcode=None,filename=None):
        self.modelfile(rlcode=rlcode,filename=filename)
        self.params_update(rlcode=rlcode)
        self.rules_update(rlcode=rlcode)
        self.query_update(rlcode=rlcode)
        self.dataprocess_update(rlcode=rlcode)
        self.md_to_redis(db=5, rlcode=rlcode)

    def params_update(self, rlcode=None):

        model_params = self.fetch_all(tablename='model_params', field='rlcode,pname,pdatatype,isreq,isformodel,defaultv',
                                      condition=f'where rlcode="{rlcode}"' if rlcode else None)
        self._reflush_md(model_params, 'model_params')

    def rules_update(self, rlcode=None):
        model_param_rules = self.fetch_all(tablename='model_param_rules', field='rlcode,rulecode,sn,type,rule',
                                           condition=f'where rlcode="{rlcode}"' if rlcode else None)
        self._reflush_md(model_param_rules, 'model_param_rules')

    def modelfile(self, rlcode=None,filename=None):
        model_release = self.fetch_all(tablename='model_release',
                                       field='rlcode,filepkgcode,rlstatus,alphatime,betatime,ontime,offtime,operator',
                                       condition=f'where rlcode="{rlcode}" and rlstatus in ("online") ' if rlcode else None)
        model_files = self.fetch_all(tablename='file_package', field='DISTINCT(filename)') \
            if not filename and not rlcode else self.fetch_all(tablename='file_package', field='DISTINCT(filename)',condition=f"where filename='{filename}'")
        self._md={mr['rlcode']: {'model_files': self.fetch_all(tablename='file_package fp', field='rfc,filename,fp.filepkgcode',
                                                               condition=f"where fp.filepkgcode in (select mr.filepkgcode from model_release mr where rlcode ='{mr.get('rlcode',None)}' and rlstatus ='online')")}
        for mr in model_release} if (not filename) else {rlcode:{'model_files': self.fetch_all(tablename='file_package fp', field='DISTINCT (fp.filename), fp.rfc ,fp.filepkgcode',
                                                                                                              condition=f"join model_release mr on fp.filename ='{filename}' where mr.rlcode='{rlcode}'")}}
        self.file_to_redis(model_files)

    def query_update(self, rlcode=None):
        model_parmas_query = self.fetch_all(tablename='model_parmas_query',
                                            field='rlcode,qrcode,sn,dscode,table_name,where_condition,cols,datatype,isreq',
                                            condition=f'where rlcode="{rlcode}"' if rlcode else None)
        self._reflush_md(model_parmas_query, 'model_params_query')

        datasource = self.fetch_all(tablename='datasource', field='dscode,dstype,host,port,username,passw,db,enable')
        for key, data in self._md.items():
            for ds in data['model_params_query']:
                ds['ds'] = [{k: v for (k, v) in dc.items() if k != 'dscode'} for dc in datasource if
                            dc['dscode'] == ds['dscode']]

    def dataprocess_update(self, rlcode=None):
        model_dataprocess = self.fetch_all(tablename='model_dataprocess', field='rlcode,sn,sqlstmt',
                                           condition=f'where rlcode="{rlcode}"' if rlcode else None)
        self._reflush_md(model_dataprocess, 'model_dataprocess')

    def md_to_redis(self, db=5, rlcode=None):
        if not rlcode:
            for k, v in self._md.items():
                Redis(db=db).conn().getset(f'{k}', json.dumps(v, cls=ComplexEncoder))
        else:
            Redis(db=db).conn().getset(f'{rlcode}', json.dumps(self._md[rlcode], cls=ComplexEncoder))

    def _reflush_md(self, data, key):
        for (k, v) in self._md.items():
            v.update({key: [{k: v for (k, v) in p.items() if k != 'rlcode'} for p in data if k == p['rlcode']]})

    def get_md(self, key, ruuid=None):
        _md = Redis(db=5).conn().get(key)
        result = json.loads(_md.decode()) if _md else None
        return result

    def file_to_redis(self, model_files=None):
        for f in model_files:
            if f['filename'].split('.')[-1]  in['m','pkl']:
                self._file[f['filename']] = pickle.dumps(joblib.load(f"{os.path.join(os.path.join(self._path , 'm'),f['filename'])}"))
                Redis(db=7).conn().getset(f"{f['filename']}", self._file[f['filename']])
            elif f['filename'].split('.')[-1] == 'ppd':
                self._file[f['filename']] = open(f"{os.path.join(os.path.join(self._path , 'ppd'),f['filename'])}", 'rb').read()
                Redis(db=7).conn().getset(f"{f['filename']}", self._file[f['filename']])
        G.mlog.info(f"[ {self._file.keys()} ] meta data load done")


if __name__ == '__main__':
    Metadata().meta_data(rlcode='crkomdclmxxx1v1')

