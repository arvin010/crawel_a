import inspect
import getpass
from dcclog import DccLog

# global share variable
runid = None
runtype = None
rundataflow = None
config_dict = {}
logfile = None
ddate = None
datetime = None
osuser = getpass.getuser()
run_begin_time = None
run_end_time = None
run_tot_time = None
mlog = None
mlog = DccLog() if not mlog else mlog
logdata=[]
prefix_ver=None
code=[202, 500,203,207,208,205]
