# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-07-16 11:31:59
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-21 15:34:31
from interviews import *
import json
from time import sleep


class LogService(RequestHandlers,Mysql):
    def __init__(self):
        self.data = {}
        self.tablemap = {'runs': 'calls', 'data_process': 'sql', 'model_call': 'model_call', 'query': 'query',
                         'param_rule_check': 'rule', 'model_params': 'params', 'model_service': 'model_service',
                         'model_files': 'model_files'}


    @nonAuthException
    def log_read(self, db=6):
        _redis = Redis(db=db)._conn
        keys = _redis.keys()
        for k in keys:
            key = k.decode()
            self.data[key] = {}
            if _redis.llen(key) < 2: sleep(5);
            while True:
                item = _redis.rpop(key)
                if not item: break
                item = json.loads(item)
                self.update_data(key, self.tablemap[item['method']], item)
        log = lambda log: self.log_write;  log

    @nonAuthException
    def update_data(self, indkey, key, item):
        if item['method'] == 'model_service':
            self.data[indkey]['begintime'] = item.get('begintime', None)
            self.data[indkey]['endtime'] = item.get('endtime', None)
            self.data[indkey]['caller'] = item.get('user', None)
            self.data[indkey]['callerip'] = item.get('ip', None)
            self.data[indkey]['result'] = json.dumps(item.get('result', None), cls=ComplexEncoder)
            self.data[indkey]['appinput'] = json.dumps(item.get('appinput', None), cls=ComplexEncoder)
            self.data[indkey]['status'] = json.dumps(item['result']['message']  if item.get('result', None) else [], cls=ComplexEncoder)
            self.data[indkey]['rlcode'] =json.dumps(list(map(lambda c: c['rlcode'] ,item['appinput'])) if item.get('appinput', None) else [], cls=ComplexEncoder)
            self.data[indkey]['uuid'] = indkey
        elif item['method'] == 'model_call':
            self.data[indkey]['modelinput'] = json.dumps(item.get('modelinput', None))
            self.data[indkey]['modeloutput'] = json.dumps(item.get('result', None))
        elif item['method'] == 'model_files':
            self.data[indkey]['filepkgcode'] = item.get('filepkgcode', None)
            self.data[indkey]['filecode'] = item.get('filename', None)

    @nonAuthException
    def log_write(self):
        while self.data:
            key, item = self.data.popitem()
            if not item: continue
            # insert_(self,tablename='call_logs',key='uuid',item=item)
            col_list=desc(tablename='call_logs')[1:-2]
            insert_many(tablename='call_logs', col_list=col_list,value_list=[[
            item.get(col,None) if col!='operator' else self._current_user for col in col_list]])
            rest=json.loads(item['result'])  if item.get('result', None) else None
            if rest and  isinstance(rest,dict) and rest.get('message',None)=='0':
                m = list(map(lambda row: insert_many(tablename='call_result', col_list=['uuid', 'rkey', 'rvalue'],
                                                        value_list=[[key, k, v] for k, v in row.items()]) if row else [[]],
                             rest['context'])) if isinstance(rest['context'],list) else 0
                m=insert_many(tablename='call_result', col_list=['uuid', 'rkey', 'rvalue'],value_list=[[key, k, v] for k, v in rest['context'].items()])  if isinstance(rest['context'],dict) else 0


if __name__ == '__main__':
    l = LogService()
    l.log_read()
