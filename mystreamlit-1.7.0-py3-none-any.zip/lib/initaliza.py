# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-07-16 11:31:59
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-20 18:01:02
#! /usr/bin/env python
# -*- coding=utf-8 -*-

import os
import re
import sys
from lib.com import random2string
from lib import G
from dccfile import ConfigFile, DccFile
from dccdatetime import DccDatetime

class Initializa:

    def __init__(self):
        '''
        初始化，包括读取配置、设置日志文件
        :return:
        '''
        self._dccconfig = ConfigFile()
        self._dccfile = DccFile()
        self._dccdatetime = DccDatetime()
        self.init_config()
        self.init_log()

    def init_workdir(self):
        # 切换mpp工作目录为所在目录
        os.chdir(os.path.abspath(__file__).rsplit('/', 1)[0])

    def init_config(self):
        # 获取配置信息
        G.config_dict = self._dccconfig.get_all_config_file()
        G.prefix_ver=f"/{G.config_dict['mpp']['prefix']}/{G.config_dict['mpp']['version']}/"
        # 配置参数
        G.mlog.debug('config:{}'.format(G.config_dict), func=sys._getframe().f_code.co_name)

    # @mppRunsException(stage='Init')
    def init_log(self):
        # 设置默认的日志级别
        if G.config_dict['mpp'].get('loglevel', '') == 'debug' \
                or G.osuser in G.config_dict['mpp']['log_debug_osuser'].split(','):
            G.mlog.set_log_level(log_level='debug')
            G.mlog.info('config sets the loglevel to:debug', func=sys._getframe().f_code.co_name)

        # 设置输入参数的日志级别
        elif G.input_parms['debug']:
            G.mlog.set_log_level(log_level='debug')
            G.mlog.info('config sets the loglevel to:debug', func=sys._getframe().f_code.co_name)

        else:
            G.mlog.info('default loglevel:info', func=sys._getframe().f_code.co_name)

        # init logger,日志路径统一按配置文件路径
        self.get_log_file()
        G.logfile = self._logfile

        # 设置logger指向logfile
        G.mlog.set_log_file(G.logfile)
        G.mlog.info('log file {}'.format(G.logfile), func=sys._getframe().f_code.co_name)

    # @mppRunsException(stage='Init')
    def get_log_file(self):
        '''
        mpp的日志文件路径：{logdir}/{date}/logfile
        :param logdir:
        :return:
        '''
        # 日志路径统一按配置文件路径
        logdir = G.config_dict['mpp']['logdir']
        # 按日期分目录
        full_logdir = self._dccfile.file_path_join(logdir, str(self._dccdatetime.now(fm='d')).split(' ')[0])

        # 日志文件名
        filename = f"mpp_{re.sub('[-:]+',lambda x: '',DccDatetime().nows()).replace(' ','')}.log"

        # mkdir
        if not self._dccfile.path_exists(full_logdir):
            # 并发时，可能会有多个程序取创建日志目录，因此捕获一下错误，如果目录已存在，则不需要处理
            try:
                self._dccfile.make_dir(full_logdir)
                G.mlog.debug('make dir:{}'.format(full_logdir), func=sys._getframe().f_code.co_name)
                self._dccfile.chmod(full_logdir, 0o777)
                G.mlog.debug('chmod 777 {}'.format(full_logdir), func=sys._getframe().f_code.co_name)
            except Exception as err:
                G.mlog.warn('the directory should be created, but it already exists:{}'.format(full_logdir),
                             func=sys._getframe().f_code.co_name)

        else:
            G.mlog.debug('log path already exist.{}'.format(full_logdir), func=sys._getframe().f_code.co_name)

        # add filename
        self._logfile = self._dccfile.file_path_join(full_logdir, filename.lower())


if __name__=='__main__':
    Initializa()