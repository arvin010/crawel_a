# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-10 09:18:36
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-18 10:02:22
#! /usr/bin/env python
# -*- coding=utf-8 -*-
import pymysql
import redis
from lib import G
from dccfile import ConfigFile
from datetime import timedelta
from DBUtils.PooledDB import PooledDB
config=ConfigFile().get_all_config_file()



class Config(object):
    DEBUG = True
    SECRET_KEY = "umsuldfsdflskjdf"
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=20)
    SESSION_REFRESH_EACH_REQUEST = True
    SESSION_TYPE = "redis"
    config_mysql=config['mysql']
    config = {
        'creator': pymysql,
        'host': config_mysql['host'],
        'port': int(config_mysql['port']),
        'user': config_mysql['username'],
        'password': config_mysql['passwd'],
        'db': config_mysql['database'],
        'charset': config_mysql['charset'],
        'maxconnections': int(config_mysql['maxconnections']),
        'cursorclass': pymysql.cursors.DictCursor,
        'mincached': int(config_mysql['mincached']),
        'maxcached': int(config_mysql['maxcached']),
        'maxshared': int(config_mysql['maxshared']),
        'blocking': False,
        'maxusage': int(config_mysql['maxusage']),
        'setsession': [],
        'ping': 0
    }
    PYMYSQL_POOL = PooledDB(**config)




class Mysql(object):

    @staticmethod
    def open(cursor):
        POOL = Config.PYMYSQL_POOL
        conn = POOL.connection()
        cursor = conn.cursor(cursor=cursor)
        return conn, cursor

    @staticmethod
    def close(conn, cursor):
        conn.commit()
        cursor.close()
        conn.close()


    @classmethod
    def desc(cls, tablename, cursor=pymysql.cursors.DictCursor):
        conn, cursor = cls.open(cursor)
        sql = f" desc {tablename}"
        G.mlog.info(f" [mysql][ desc ] executed sql : {sql}")
        cursor.execute(sql)
        obj = cursor.fetchall()
        obj=[list(fields.values())[0]  for fields in obj if fields]
        cls.close(conn, cursor)
        return obj

    @classmethod
    def fetch_one(cls, tablename, field='*', condition=None, cursor=pymysql.cursors.DictCursor):
        conn, cursor = cls.open(cursor)
        sql = f" SELECT {field} FROM {tablename}  {condition} limit 1"
        G.mlog.info(f" [mysql][ fetch_one] executed sql : {sql}")
        cursor.execute(sql)
        obj = cursor.fetchone()
        cls.close(conn, cursor)
        return obj

    @classmethod
    def fetch_all(cls, tablename, field='*', condition=None, cursor=pymysql.cursors.DictCursor):
        conn, cursor = cls.open(cursor)
        sql = f" SELECT {field} FROM {tablename}  {condition}"
        G.mlog.info(f" [mysql][ fetch_all ] executed sql : {sql}")
        cursor.execute(sql)
        obj = cursor.fetchall()
        cls.close(conn, cursor)
        return obj

    @classmethod
    def insert_many(cls, tablename, col_list, value_list, cursor=pymysql.cursors.DictCursor):
        conn, cursor = cls.open(cursor)
        sql = f"INSERT INTO {tablename} ({','.join(col_list)}) VALUES ({','.join(['%s' for col in col_list])})"
        G.mlog.info(f" [mysql][ insert_many] executed sql : {sql} , value_list: {value_list}")
        row_changes = cursor.executemany(sql, value_list)
        cls.close(conn, cursor)
        return row_changes

    @classmethod
    def delete_many(cls, tablename, condition=None, cursor=pymysql.cursors.DictCursor):
        conn, cursor = cls.open(cursor)
        sql = f"DELETE FROM  {tablename} {condition}"
        G.mlog.info(f" [mysql][ delete_many ] executed sql : {sql}")
        row_changes = cursor.execute(sql)
        cls.close(conn, cursor)
        return row_changes

    @classmethod
    def delete_one(cls, tablename, condition=None, cursor=pymysql.cursors.DictCursor):
        conn, cursor = cls.open(cursor)
        sql = f"DELETE FROM  {tablename} {condition} limit 1"
        G.mlog.info(f" [mysql][ delete_one ] executed sql : {sql}")
        row_changes = cursor.execute(sql)
        cls.close(conn, cursor)
        return row_changes

    @classmethod
    def update_one(cls, tablename, field, condition, cursor=pymysql.cursors.DictCursor):
        conn, cursor = cls.open(cursor)
        sql = fr"UPDATE {tablename} SET {field}  {condition}"
        G.mlog.info(f" [mysql][ update_one ] executed sql : {sql}")
        row_changes = cursor.execute(sql)
        cls.close(conn, cursor)
        return row_changes


class Redis:
    def __init__(self, db=config['redis']['db']):
        _config_redis = config['redis']
        _pool = redis.ConnectionPool(host=_config_redis['host'], port=int(_config_redis['port']), db=int(db),
                                     password=_config_redis['passwd'], max_connections=int(_config_redis['max']))
        self._conn = redis.Redis(connection_pool=_pool, decode_responses=True)

    def conn(self):
        return self._conn
