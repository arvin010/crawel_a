# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2021-08-13 11:55:38
# @Last Modified by:   SZW201208
# @Last Modified time: 2021-12-09 11:17:10
def insert_(self:object,tablename:str,key:str,item:dict,col_list:list=None,key2:str=None,value:str=None,value2:str=None) -> dict:
    col_list=self.mysql.desc(tablename=tablename)[1:-2] if not col_list else col_list
    key='id' if 'id' in item.keys() and item.get('id',None) else key
    result=get_(self,tablename=tablename,key=key,value=item[key] if not value or key !='id' else value,key2=key2 if key2 else None,value2=item[key2] if key2 else None)
    if not result :
        rest=self.mysql.insert_many(tablename=tablename, col_list=col_list, value_list=[[
            item.get(col,None) if col!='operator' else self._current_user for
            col in col_list]])
    else:
        item={key:item[key],'content':{k:v for k,v in item.items() if k!=key}}
        rest=update_(self,tablename=tablename,item=item,key=key,col_list=col_list,key2=key2 if key !='id' else None)
    return  rest

def get_(self:object,tablename:str,key:str,value:str,idlist:list=None,key2:str=None,value2:str=None) -> list:
    idlist=idlist if idlist else str(value).split(',') if ',' in str(value) else [str(value)]
    idlist2=str(value2).split(',') if ',' in str(value2) else [str(value2)]
    result=[]
    if '*' in idlist:
        result = self.mysql.fetch_all(tablename=tablename)
    elif key2 and value2 and key !='id':
        rest = [self.mysql.fetch_all(tablename=tablename, condition=f"where {key}='{tup[0]}' and {key2}='{tup[1]}'") for tup in
                zip(idlist,idlist2)]
        c=[result.extend(row) for row in rest if row]
    else:
        rest = [self.mysql.fetch_all(tablename=tablename, condition=f"where {key}='{id}'") for id in
                idlist]
        c=[result.extend(row) for row in rest if row]
    return result


def get_and(self:object,tablename:str,keys:list,values:list) -> list:
    result=[]
    condition=' and '.join([f"{tup[0]}='{tup[1]}'" for tup in zip(keys,values)])
    rest = [self.mysql.fetch_all(tablename=tablename, condition=f"where {condition}")]
    c=[result.extend(row) for row in rest if row]
    return result

def get_or(self:object,tablename:str,keys:list,values:list) -> list:
    result=[]
    condition=' or '.join([f"{tup[0]}='{tup[1]}'" for tup in zip(keys,values)])
    rest = [self.mysql.fetch_all(tablename=tablename, condition=f"where {condition}")]
    c=[result.extend(row) for row in rest if row]
    return result

def update_(self:object,tablename:str,item:dict,key:str,col_list:list=None,key2:str=None) -> dict:
    col_list=self.mysql.desc(tablename=tablename)[1:-2] if not col_list else col_list
    s=[col_list.remove(col) for col in col_list if col not in list(item['content'].keys())]
    if key in col_list: col_list.remove(key)
    if key2:
        rest=self.mysql.update_one(tablename=tablename, field=','.join([f"{col}='{item['content'].get(col,None)}'"   if col!='operator' else  f"{col}='{self._current_user}'"  for col in col_list]),condition= f"WHERE {key}='{item.get(key,None)}' and {key2}='{item['content'].get(key2,None)}'" )
    else:
        rest=self.mysql.update_one(tablename=tablename, field=','.join([f"{col}='{item['content'].get(col,None)}'"   if col!='operator' else  f"{col}='{self._current_user}'"
                                                                        for col in col_list]),condition= f"WHERE {key}='{item.get(key,None)}'" )
    return rest

def max_(self:object,tablename:str,field:str,condition:str=None) -> int:
    max=self.mysql.fetch_one(tablename=tablename,field=f'MAX({field}) num',condition=condition)
    max=max['num'] if max['num'] else 0
    return int(max)