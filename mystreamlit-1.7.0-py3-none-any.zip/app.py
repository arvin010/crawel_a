

if __name__=='__main__':
    from service import *
    Service()
