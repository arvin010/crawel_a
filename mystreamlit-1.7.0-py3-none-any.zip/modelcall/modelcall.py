import pandas as pd
import numpy as np
import os
import time
import dill
import pickle
import traceback
import json
from lib import G
from lib.com import logs,Redis
# from sklearn.externals import joblib  # pip install scikit-learn==0.21.3 版本太新会报错，或直接import joblib
import joblib
from types import FunctionType, CodeType

@logs
def model_call(filename, model_data, filetype=None, ruuid=None):
    pic_type=['m','pkl']
    _result = {}
    try:
        G.mlog.info(f'filename: {filename} ;  model data :{model_data} ')
        file=Redis(db=7).conn().get(filename)
        if not file:
            raise ValueError('{filename} not found')
        if filetype == 'ppd':
            mapper=dill.loads(file,encoding='latin1')
            G.mlog.info('model load done  ppd')
            _result['code'] = '0'
            _result['context'] = mapper.fit(model_data)
        elif filetype in pic_type:
            model=pickle.loads(file)
            G.mlog.info(f'model load done  {filetype}')
            result = model.predict_proba(pd.DataFrame(model_data))[:, 1]
            G.mlog.info('result', result)
            _result['context'] = {'result': result[0]} if result else {'result': None}
            _result['code'] = '0'
            G.mlog.info(f'model output data: {_result["context"]}')
        else:
            _result['code'] = 'DC002'
            _result['context'] = {'error':f'filetype:{filetype}  the file format is not supported'}
    except Exception as err:
        _result['code'] = 'DC001'
        _result['context'] = {"modeldata" : model_data ,"error": f"{traceback.format_exc()}>>>{err}"}
        G.mlog.info(f"modelcall error info: {traceback.format_exc()}>>> {err} ,  'modeldata' :{model_data} ")
    finally:
        return _result


if __name__ == '__main__':
    _params = {"modelcode": "CRKOMDCLMXXX001", "modelvers": "v1.0.1",
               "params": {"rgtno": "86202006186292",
                          "customerno": "0000000006",
                          "agentcode": "BCD0000002",
                          "min_claimdays": 336.0,
                          "hospitalizeddays": 11.0,
                          "avg_pol_amnt_prem_pct": 0.75,
                          "min_polamnt": 250,
                          "accid_age": 27.0}

               }
    model_data = [
        {'rgtno': '86202006186292', 'min_claimdays': 336.0, 'hospitalizeddays': 11.0, 'avg_pol_amnt_prem_pct': 0.75,
         'min_polamnt': 250, 'accid_age': 27.0, 'AVG_ANP_CUST': 654.48, 'RGT_PAY_CNT': 0.0,
         'MAX_FACE_AMOUNT_CUST': 150000.0, 'min_claim_pay_pol_pct': 0.0, 'min_claim_amnt': 0.0}]
    model_data = [{'ct_max_avg': 1069.0, 'res_status': 0.0, 'thk_ab_cnt': 1.0, 'good_pct_avg1': 0.0, 'last_dur': 2046.0,
                   'abc_pct_avg2': 1.0, 'ct_lt1m_pct_max': 0.6666666666666666, 'is_freepolicy': 1.0,
                   'phone': '1308190ITTP'}]
    print(model_call(modelfile='CVMDTCRESXXX001_v1.0.1.ppd', model_data=model_data,ruuid='0005'))
