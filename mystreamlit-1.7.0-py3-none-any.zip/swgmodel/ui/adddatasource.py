from tornado_swagger.model import register_swagger_model


@register_swagger_model
class AddDataSourceModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        dscode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        dstype:
          type: string
          required: true
          description: The model's version.
          default: "hbase"
        host:
          type: string
          description: The rule's code.
          default: "10.142.51.24"
        port:
          type: number
          description: The rule's .
          default: 10000
        username:
          type: string
          description: The rule's type.
          default:
        passw:
          type: string
          description: The rule's context.
          default:
        db:
          type: string
          description: The rule's context.
          default:
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """


@register_swagger_model
class AddDataSourcePostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        dscode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        dstype:
          type: string
          required: true
          description: The model's version.
          default: "hbase"
        host:
          type: string
          description: The rule's code.
          default: "10.142.51.24"
        port:
          type: number
          description: The rule's .
          default: 10000
        username:
          type: string
          description: The rule's type.
          default:
        passw:
          type: string
          description: The rule's context.
          default:
        db:
          type: string
          description: The rule's context.
          default:
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """


@register_swagger_model
class AddDataSourcePatchModel:
        """
    ---
    type: object
    description: Post model representation
    properties:
        dscode:
          type: string
          required: true
          description: The model's code.
          default: ""
        dstype:
          type: string
          required: true
          description: The model's version.
          default: "hbase"
        host:
          type: string
          description: The rule's code.
          default: "10.142.51.24"
        port:
          type: string
          description: The rule's .
          default: 10000
        username:
          type: string
          description: The rule's type.
          default:
        passw:
          type: string
          description: The rule's context.
          default:
        db:
          type: string
          description: The rule's context.
          default:
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default:
          """