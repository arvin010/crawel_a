from tornado_swagger.model import register_swagger_model


@register_swagger_model
class ReactionTimeModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        start_time:
          type: string
          required: true
          description: The model's code.
          default: "2021-07-19 00:00:00"
        end_time:
          type: string
          required: true
          description: The model's code.
          default: "2021-07-20 23:59:59"
    """


@register_swagger_model
class ReactionTimePostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        start_time:
          type: string
          required: true
          description: The model's code.
          default: "2021-07-19 00:00:00"
        end_time:
          type: string
          required: true
          description: The model's version.
          default: "2021-07-20 23:59:59"
    """


