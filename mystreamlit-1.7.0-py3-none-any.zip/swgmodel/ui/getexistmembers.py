from tornado_swagger.model import register_swagger_model

@register_swagger_model
class GetExistMembersModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: ""
    """


@register_swagger_model
class GetExistMembersGetModel:
    """
     ---
     type: object
     description: Post model representation
     properties:
         teamcode:
           type: string
           description: The rule's code.
           default: ""
     """
