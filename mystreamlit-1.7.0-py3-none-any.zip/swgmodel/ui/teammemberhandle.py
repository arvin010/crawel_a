from tornado_swagger.model import register_swagger_model


@register_swagger_model
class TeamMemberHandleModel:
    """
     ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: ""
        aduser:
          type: number
          description: The rule's .
          default: ""
        enable:
          type: number
          description: The rule's context.
          default: ""
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """


@register_swagger_model
class TeamMemberHandleDeleteModel:
    """
     ---
    type: object
    description: Post model representation

    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: ""
        aduser:
          type: number
          description: The rule's .
          default: ""
        enable:
          type: number
          description: The rule's context.
          default: 0
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """





