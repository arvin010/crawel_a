from tornado_swagger.model import register_swagger_model


@register_swagger_model
class AdvancedFilterModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelname:
          type: string
          description: The rule's code.
          default: "close分层模型"
        appcode:
          type: string
          description: The rule's code.
          default: "CVM"
        depcode:
          type: number
          description: The rule's .
          default: "dtc"
        buscode:
          type: string
          description: The rule's type.
          default: "RES"
        modelclass:
          type: string
          description: The rule's context.
          default: "XXX"
        modelgroup:
          type: string
          description: The rule's context.
          default: "CVMdtcRESXXX"
        groupname:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
        groupdes:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """

@register_swagger_model
class AdvancedFilterPostModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            aduser:
              type: string
              required: true
              description: The model's code.
              default: "SZW210711"
            querylist:
              type: object
              required: true
              description: The model's code.
              default: [{"field": "depcode", "operator":"=", "value": "crk"}, {"field": "buscode", "operator":"=", "value": "pom"}, {"field": "createdtime", "operator":"=", "value": "2021-08-19"}]
    """