from tornado_swagger.model import register_swagger_model


@register_swagger_model
class AdvFilterOperatorModel:
    """
    ---
    type: object
    description: Post model representation

    """