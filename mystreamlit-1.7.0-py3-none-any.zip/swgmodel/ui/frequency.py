from tornado_swagger.model import register_swagger_model

@register_swagger_model
class FrequencyModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        dscode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        dstype:
          type: string
          required: true
          description: The model's version.
          default: "hbase"
        host:
          type: string
          description: The rule's code.
          default: "10.142.51.24"
        port:
          type: number
          description: The rule's .
          default: 10000
        username:
          type: string
          description: The rule's type.
          default:
        passw:
          type: string
          description: The rule's context.
          default:
        db:
          type: string
          description: The rule's context.
          default:
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class FrequencyPostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        start_time:
          type: string
          required: true
          description: The model's code.
          default: "2021-07-07 00:00:00"
        end_time:
          type: string
          required: true
          description: The model's version.
          default: "2021-07-12 23:59:59"
    """



