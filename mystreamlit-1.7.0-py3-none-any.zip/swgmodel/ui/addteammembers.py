from tornado_swagger.model import register_swagger_model


@register_swagger_model
class AddTeamMembersModel:
    """
     ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: ""
        aduser:
          type: number
          description: The rule's .
          default: ""
        enable:
          type: number
          description: The rule's context.
          default: "1"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """

@register_swagger_model
class AddTeamMembersPostModel:
    """
          ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: ""
        aduser:
          type: string
          description: The rule's code
          default: ""
        ename:
          type: string
          description: The rule's code.
          default: ""
        cname:
          type: string
          required: true
          description: The operator's ID.
          default: ""
        enable:
          type: string
          required: true
          description: The operator's ID.
          default: 1
        operator:
          type: string
          description: The rule's code.
          default: ""
    """


@register_swagger_model
class AddTeamMembersPatchModel:
    """
          ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: ""
        aduser:
          type: string
          description: The rule's code
          default: ""
        ename:
          type: string
          description: The rule's code.
          default: ""
        cname:
          type: string
          required: true
          description: The operator's ID.
          default: ""
        enable:
          type: string
          required: true
          description: The operator's ID.
          default: 1
        operator:
          type: string
          description: The rule's code.
          default: ""
    """