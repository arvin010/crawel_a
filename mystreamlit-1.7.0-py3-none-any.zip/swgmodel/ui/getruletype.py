from tornado_swagger.model import register_swagger_model

@register_swagger_model
class GetRuleType:
    """
    ---
    type: object
    description: Post model representation
    """