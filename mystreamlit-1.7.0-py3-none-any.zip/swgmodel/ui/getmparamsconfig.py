from tornado_swagger.model import register_swagger_model

@register_swagger_model
class GetMParamsConfigModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        appcode:
          type: string
          description: The rule's code.
          default: "test_data"
        depcode:
          type: number
          description: The rule's .
          default: 1
        buscode:
          type: string
          description: The rule's type.
          default: "python"
        modelclass:
          type: string
          description: The rule's context.
          default: "测试数据"
        modelgroup:
          type: string
          description: The rule's context.
          default: "test"
        groupname:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
        groupdes:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """

@register_swagger_model
class GetMParamsConfigGetModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        appcode:
          type: string
          description: The rule's code.
          default: "test_data"
        depcode:
          type: number
          description: The rule's .
          default: 1
        buscode:
          type: string
          description: The rule's type.
          default: "python"
        modelclass:
          type: string
          description: The rule's context.
          default: "测试数据"
        modelgroup:
          type: string
          description: The rule's context.
          default: "test"
        groupname:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
        groupdes:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """
