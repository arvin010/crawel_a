from tornado_swagger.model import register_swagger_model

@register_swagger_model
class CreateTeamsModel:
    """
     ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: "cvm"
        teamname:
          type: number
          description: The rule's .
          default: "客户资源及价值管理"
        leader:
          type: string
          description: The rule's type.
          default: "SZA160089"
        enable:
          type: string
          description: The rule's context.
          default: "1"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """

@register_swagger_model
class CreateTeamsPostModel:
    """
     ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: "cvm"
        teamname:
          type: number
          description: The rule's .
          default: "客户资源及价值管理"
        leader:
          type: string
          description: The rule's type.
          default: "SZA160089"
        enable:
          type: string
          description: The rule's context.
          default: "1"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """


@register_swagger_model
class TeamsDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class TeamsPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"teamcode": "cvm_test", "teamname": "客户资源及价值管理_test", "leader": "SZA160089_test", "enable":"8", "operator": "NO0000001"}
    """
