from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ChangeRoleModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        dscode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
    """


@register_swagger_model
class ChangeRolePatchModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          required: true
          description: The model's code.
          default: ""
        aduser:
          type: string
          required: true
          description: The model's code.
          default: ""
        operator:
          type: string
          required: true
          description: The model's code.
          default: ""
    """



