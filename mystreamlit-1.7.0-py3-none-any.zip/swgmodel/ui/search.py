from tornado_swagger.model import register_swagger_model

@register_swagger_model
class SearchModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        appcode:
          type: string
          description: The rule's code.
          default: "test_data"
    """

@register_swagger_model
class SearchPostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        querystr:
          type: string
          description: The rule's code.
          default: "cvm"
        operator:
          type: string
          description: The rule's code.
          default: "no0000001"
    """
