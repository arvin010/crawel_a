from tornado_swagger.model import register_swagger_model

@register_swagger_model
class BaseModel:
    """
    ---
    type: object
    description: Post model representation
    tags:
        - Auth
    properties:
        rlcode:
          type: string
          required: true
          description: The model's code.
          default: "cvmcrkomdclmxxx1v1"
        params:
          type: object
          default:  {"rgtno":"86202006186292",
                            "customerno":"0000000003",
                            "agentcode":"BBJBJ00019",
                            "min_claimdays":336.0,
                            "hospitalizeddays":11.0,
                            "avg_pol_amnt_prem_pct":0.75,
                            "min_polamnt":250,
                            "accid_age":27.0}
          properties:
            phone:
                type: string
                description: The model's phone.
                default: "1308190ITTP"
    """
