from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ModelParamQueryModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        modelvers:
          type: string
          required: true
          description: The model's version.
          default: "v1.0.1"
        qrcode:
          type: string
          description: The rule's code.
          default: "qr001"
        sn:
          type: number
          description: The rule's .
          default: 1
        dscode:
          type: string
          description: The rule's type.
          default: "ds001"
        table_name:
          type: string
          description: The rule's context.
          default: "test:dtcreso_sample"
        where_condition:
          type: string
          description: The rule's context.
          default: "phone"
        cols:
          type: string
          description: The rule's context.
          default: "phone,ct_max_avg,res_status,thk_ab_cnt,good_pct_avg1,last_dur,abc_pct_avg2,ct_lt1m_pct_max,is_freepolicy"
        datatype:
          type: string
          description: The rule's context.
          default: '{"phone":"str","ct_max_avg":"float","res_status":"float","thk_ab_cnt":"float","good_pct_avg1":"float","last_dur":"float","abc_pct_avg2":"float","ct_lt1m_pct_max":"float","is_freepolicy":"float"}'
        isreq:
          type: number
          description: The rule's .
          default: 1
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """

@register_swagger_model
class ModelParamQueryPostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        qrcode:
          type: string
          description: The rule's code.
          default: "qr001"
        sn:
          type: number
          description: The rule's .
          default: 1
        dscode:
          type: string
          description: The rule's type.
          default: "ds001"
        table_name:
          type: string
          description: The rule's context.
          default: "test:dtcreso_sample"
        where_condition:
          type: string
          description: The rule's context.
          default: "phone"
        cols:
          type: string
          description: The rule's context.
          default: "phone,ct_max_avg,res_status,thk_ab_cnt,good_pct_avg1,last_dur,abc_pct_avg2,ct_lt1m_pct_max,is_freepolicy"
        datatype:
          type: string
          description: The rule's context.
          default: '{"phone":"str","ct_max_avg":"float","res_status":"float","thk_ab_cnt":"float","good_pct_avg1":"float","last_dur":"float","abc_pct_avg2":"float","ct_lt1m_pct_max":"float","is_freepolicy":"float"}'
        isreq:
          type: number
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelParamQueryGetModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        dscode:
          type: string
          description: The rule's type.
          default: "ds001"
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
    """


@register_swagger_model
class ModelParamQueryDeleteModel:
     """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class ModelParamQueryPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"rlcode": "test_data", "qrcode":"test_data", "sn": 1, "dscode": ds001, "table_name": "test:dtcreso_sample", "where_condition": "phone", "cols": "phone,ct_max_avg,res_status,thk_ab_cnt,good_pct_avg1,last_dur,abc_pct_avg2,ct_lt1m_pct_max,is_freepolicy","datatype": "None", "isreq": 1, "operator": "SZxxxxxx"}
    """

