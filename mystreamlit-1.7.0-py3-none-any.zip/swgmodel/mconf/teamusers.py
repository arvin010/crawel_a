from tornado_swagger.model import register_swagger_model

@register_swagger_model
class TeamusersModel:
    """
     ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: "cvm_test"
        aduser:
          type: number
          description: The rule's .
          default: "SZA160089_test"
        enable:
          type: number
          description: The rule's context.
          default: "8"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "op_test"
    """

@register_swagger_model
class TeamusersPostModel:
    """
          ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: "cvm_test"
        aduser:
          type: number
          description: The rule's .
          default: "SZA160089_test"
        enable:
          type: number
          description: The rule's context.
          default: "8"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "op_test"
    """


@register_swagger_model
class TeamusersDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class TeamusersPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"teamcode": "cvm_test", "aduser": "SZA160089_test", "enable":"8", "operator": "op_test"}
    """
