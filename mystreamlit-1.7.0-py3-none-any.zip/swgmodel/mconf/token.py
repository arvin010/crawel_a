from tornado_swagger.model import register_swagger_model

@register_swagger_model
class TokenModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        name:
          type: string
          description: The rule's code.
          default: "token"
        day:
          type: number
          description: The rule's .
          default: 30
        token:
          type: string
          description: The rule's type.
          default: "fcf4387767558b6ef7e19ae0817a5985c5edba24da6b1fc508700b18aa57779cd06300fe4618bc0390dc00aecc286c6026b4213d9e1dad17b90fdf9e93c85ef6"
    """

@register_swagger_model
class TokenScopeModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        name:
          type: string
          description: The rule's code.
          default: "token"
        rlcode:
          type: string
          description: The rule's .
          default: "crkomdclmxxx_ops1_v2"
    """