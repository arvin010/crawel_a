from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ModelsModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: "ttwo"
        modelgroup:
          type: number
          description: The rule's .
          default: "crkomdclmxxx"
        sn:
          type: string
          description: The rule's type.
          default: "1"
        modelcode:
          type: string
          description: The rule's context.
          default: "crkomdclmxxxttwo1"
        modelname:
          type: string
          description: The rule's context.
          default:
        modeldesc:
          type: string
          description: The rule's context.
          default: "close%"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """

@register_swagger_model
class ModelsPostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        teamcode:
          type: string
          description: The rule's code.
          default: "ttwo"
        modelgroup:
          type: number
          description: The rule's .
          default: "crkomdclmxxx"
        sn:
          type: string
          description: The rule's type.
          default: "1"
        modelcode:
          type: string
          description: The rule's context.
          default: "crkomdclmxxxttwo1"
        modelname:
          type: string
          description: The rule's context.
          default:
        modeldesc:
          type: string
          description: The rule's context.
          default: "close%"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelsDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class ModelsPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"teamcode": "ttwo", "modelgroup": "crkomdclmxxx", "sn": "1", "modelcode":"crkomdclmxxxttwo1", "modelname": "None", "modeldesc":"close%", "operator": "SZxxxxxx"}
    """
