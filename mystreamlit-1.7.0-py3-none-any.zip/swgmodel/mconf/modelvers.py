from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ModelVersModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        id:
          type: string
          description: The rule's code.
          default: "test_data"
        modelcode:
          type: number
          description: The rule's .
          default: "crkomdclmxxx1"
        modelvers:
          type: string
          description: The rule's type.
          default: "1"
        rlcode:
          type: string
          description: The rule's context.
          default: "crkomdclmxxx1v2"
        verdesc:
          type: string
          description: The rule's context.
          default: "多模型ppd文件测试"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """

@register_swagger_model
class ModelVersPostModel:
    """
     ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: number
          description: The rule's .
          default: "crkomdclmxxx1"
        modelvers:
          type: string
          description: The rule's type.
          default: "1"
        rlcode:
          type: string
          description: The rule's context.
          default: "crkomdclmxxx1v2"
        verdesc:
          type: string
          description: The rule's context.
          default: "多模型ppd文件测试"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """


@register_swagger_model
class ModelVersDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class ModelVersPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"modelcode": "claim_lr_l2", "modelvers": "1", "rlcode": "None", "verdesc": "None", "operator": "SZxxxxxx"}
    """
