from tornado_swagger.model import register_swagger_model

@register_swagger_model
class FilePackageModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          description: The rule's code.
          default: "test_data"
        filepkgvers:
          type: number
          description: The rule's .
          default: 1
        filepkgcode:
          type: string
          description: The rule's type.
          default: "python"
        rfc:
          type: string
          description: The rule's context.
          default: "测试数据"
        filecode:
          type: string
          description: The rule's context.
          default: "test"
        filepkgdesc:
          type: string
          description: The rule's context.
          default: "全部"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class AddFilePackageModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          description: The rule's code.
          default: "crkomdclmxxx_ops1_v1"
        filepkgcode:
          type: string
          description: The rule's type.
          default: ""
        rlstatus:
          type: string
          description: The rlstatus.
          default: ""
        new_list:
          type: object
          required: true
          description: The new_list.
          default: [{"filename":"test.ppd", "rfc":"0.5", "operator": "SZxxxxxx"},{"filename":"test2.ppd", "rfc":"0.5", "operator": "SZxxxxxx"}]
        old_list:
          type: object
          required: true
          description: The old_list.
          default: [{"filename":"test.ppd", "rfc":"0.5", "operator": "SZxxxxxx"},{"filename":"test2.ppd", "rfc":"0.5", "operator": "SZxxxxxx"}]
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """

@register_swagger_model
class FilePackagePostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          description: The rule's code.
          default: "test_data"
        filepkgvers:
          type: number
          description: The rule's .
          default: 1
        filepkgcode:
          type: string
          description: The rule's type.
          default: "python"
        rfc:
          type: string
          description: The rule's context.
          default: 1
        filecode:
          type: string
          description: The rule's context.
          default: "test"
        filepkgdesc:
          type: string
          description: The rule's context.
          default: "全部"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class FilePackageDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class FilePackagePatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"rlcode": "test_data", "filepkgvers": "1", "filepkgcode": "crkomdclmxxx1v2_fpkg_1", "rfc": "1", "filecode":"test", "filepkgdesc":"xxx", "operator": "SZxxxxxx"}
    """
