from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ModelFilesModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: string
          description: The rule's code.
          default: "test_data"
        filename:
          type: number
          description: The rule's .
          default: 1
        filevers:
          type: string
          description: The rule's type.
          default: "python"
        filecode:
          type: string
          description: The rule's context.
          default: "测试数据"
        localfilename:
          type: string
          description: The rule's context.
          default: "test"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """

@register_swagger_model
class ModelFilesPostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: string
          description: The rule's code.
          default: "test_data"
        filename:
          type: number
          description: The rule's .
          default: 1
        filevers:
          type: string
          description: The rule's type.
          default: "python"
        filecode:
          type: string
          description: The rule's context.
          default: "测试数据"
        localfilename:
          type: string
          description: The rule's context.
          default: "test"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelFilesDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class ModelFilesPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"modelcode": "test_data", "filename": "claim_lr_l2", "filevers": "1", "filecode": "crkomdclmxxx1_file_claim_lr_l1_1", "localfilename":"test", "operator": "SZxxxxxx"}
    """
