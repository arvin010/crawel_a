from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ModelParamRuleModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        modelvers:
          type: string
          required: true
          description: The model's version.
          default: "v1.0.1"
        rulecode:
          type: string
          description: The rule's code.
          default: "r002"
        sn:
          type: number
          description: The rule's .
          default: 1
        type:
          type: string
          description: The rule's type.
          default: "python"
        rule:
          type: string
          description: The rule's context.
          default: "len(phone)==11"
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelParamRulePostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          description: The rule's code.
          default: "test_data"
        rulecode:
          type: string
          description: The rule's code.
          default: "v1.0.1"
        ruledesc:
          type: string
          description: The rule's code.
          default: ""
        sn:
          type: number
          description: The rule's .
          default: 1
        type:
          type: string
          description: The rule's type.
          default: "python"
        rule:
          type: string
          description: The rule's context.
          default: "len(phone)==11"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelParamRuleGetModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        rulecode:
          type: string
          description: The rule's code.
          default: "r002"
        type:
          type: string
          description: The rule's type.
          default: "python"
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
    """


@register_swagger_model
class ModelParamRuleDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class ModelParamRulePatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ''
            content:
              type: object
              required: true
              description: The model's code.
              default: {"rlcode": "cvmdtcresxxx1v1", "rulecode": "r002", "ruledesc": "参数规则", "sn": 1, "type": "regex", "rule": 'rule_test', "operator": "SZxxxxxx"}
    """
