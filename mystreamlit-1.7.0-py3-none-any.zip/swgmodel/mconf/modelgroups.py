from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ModelGroupsModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        appcode:
          type: string
          description: The rule's code.
          default: "CVM"
        depcode:
          type: number
          description: The rule's .
          default: "dtc"
        buscode:
          type: string
          description: The rule's type.
          default: "RES"
        modelclass:
          type: string
          description: The rule's context.
          default: "XXX"
        modelgroup:
          type: string
          description: The rule's context.
          default: "CVMdtcRESXXX"
        groupdes:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """

@register_swagger_model
class ModelGroupsPostModel:
    """
   ---
    type: object
    description: Post model representation
    properties:
        appcode:
          type: string
          description: The rule's code.
          default: "CVM"
        depcode:
          type: number
          description: The rule's .
          default: "dtc"
        buscode:
          type: string
          description: The rule's type.
          default: "RES"
        modelclass:
          type: string
          description: The rule's context.
          default: "XXX"
        modelgroup:
          type: string
          description: The rule's context.
          default: "CVMdtcRESXXX"
        groupdes:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelGroupsDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class ModelGroupsPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"appcode": "CVM", "depcode": "dtc", "buscode": "RES", "modelclass": "XXX", "modelgroup":"CVMdtcRESXXX", "groupname":"test", "groupdes": "", "operator": "SZxxxxxx"}
    """
