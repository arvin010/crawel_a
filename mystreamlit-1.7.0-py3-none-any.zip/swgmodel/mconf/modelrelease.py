from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ModelReleaseModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          description: The rule's code.
          default: "test_data"
        filepkgcode:
          type: number
          description: The rule's .
          default: 1
        rlstatus:
          type: string
          description: The rule's type.
          default: "python"
        alphatime:
          type: string
          description: The rule's context.
          default: "None"
        betatime:
          type: string
          description: The rule's context.
          default: "None"
        ontime:
          type: string
          required: true
          description: The operator's ID.
          default: "None"
        offtime:
          type: string
          required: true
          description: The operator's ID.
          default: "None"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ""
    """


@register_swagger_model
class ModelReleasePostModel:
    """
     ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          description: The rule's code.
          default: "test_data"
        filepkgcode:
          type: string
          description: The rule's .
          default: "1"
        rlstatus:
          type: string
          description: The rule's type.
          default: ""
        alphatime:
          type: string
          description: The rule's context.
          default: "2021-07-07 19:04:07"
        betatime:
          type: string
          description: The rule's context.
          default: "2021-07-07 19:04:07"
        ontime:
          type: string
          required: true
          description: The operator's ID.
          default: "2021-07-07 19:04:07"
        offtime:
          type: string
          required: true
          description: The operator's ID.
          default: "2021-07-07 19:04:07"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: ''
    """


@register_swagger_model
class ModelReleaseDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class ModelReleasePatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"rlcode": "test_data", "filepkgcode": "claim_lr_l2", "rlstatus": "", "alphatime": "None", "betatime": "None", "ontime": "None", "offtime": "None", "operator": "SZxxxxxx"}
    """
