from tornado_swagger.model import register_swagger_model


@register_swagger_model
class ModelParamsPostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        pname:
          type: string
          required: true
          description: The model's version.
          default: "phone"
        pdatatype:
          type: string
          description: The model's version.
          default: "str"
        isreq:
          type: number
          description: The model's version.
          default: 1
        isformodel:
          type: number
          description: The model's version.
          default: 1
        defaultv:
          type: string
          description: The model's version.
          default: ""
        operator:
          type: string
          description: The model's version.
          default: "NO0000001"
    """


@register_swagger_model
class ModelParamsGetModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: number
              required: true
              description: The model's code.
              default: 888
            rlcode:
              type: string
              description: The model's version.
              default: "test_data"
        """


@register_swagger_model
class ModelParamsDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """

@register_swagger_model
class ModelParamsPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"rlcode": "test_data", "pname": "phone", "pdatatype": "string", "isreq": 1, "isformodel": 1, "defaultv": "", "operator": "SZxxxxxx"}
    """
