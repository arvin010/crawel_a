from tornado_swagger.model import register_swagger_model


@register_swagger_model
class UsersModel:
    """
     ---
    type: object
    description: Post model representation
    properties:
        aduser:
          type: string
          description: The rule's code.
          default: "SZA190056_test"
        username:
          type: number
          description: The rule's .
          default: "Jack_test"
        cname:
          type: string
          description: The rule's type.
          default: '杰克_test'
        role:
          type: string
          required: true
          description: The operator's ID.
          default: '8'
        enable:
          type: string
          required: true
          description: The operator's ID.
          default: "1"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "op_test"
    """


@register_swagger_model
class UsersPostModel:
    """
         ---
    type: object
    description: Post model representation
    properties:
        aduser:
          type: string
          description: The rule's code.
          default: "SZA190056_test"
        username:
          type: number
          description: The rule's .
          default: "Jack_test"
        cname:
          type: string
          description: The rule's type.
          default: '杰克_test'
        role:
          type: string
          required: true
          description: The operator's ID.
          default: '8'
        enable:
          type: string
          required: true
          description: The operator's ID.
          default: "1"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "op_test"
    """


@register_swagger_model
class UsersDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class UsersPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: string
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"aduser": "SZA190056_test", "username": "Jack_test", "cname": "杰克_测试", "role":"1", "enable": "8", "operator": "op_test"}
    """
