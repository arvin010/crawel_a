from tornado_swagger.model import register_swagger_model

@register_swagger_model
class ModelDataProcessModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        modelvers:
          type: string
          required: true
          description: The model's version.
          default: "v1.0.1"
        locflag:
          type: number
          description: The rule's code.
          default: 1
        sql_statement:
          type: string
          description: The rule's .
          default: "select ct_max_avg,res_status,thk_ab_cnt,good_pct_avg1,last_dur,abc_pct_avg2,ct_lt1m_pct_max,is_freepolicy from qr001 t2"
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelDataProcessPostModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        rlcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        sn:
          type: number
          required: true
          description: The model's version.
          default: 1
        sqlstmt:
          type: string
          description: The rule's .
          default: "select ct_max_avg,res_status,thk_ab_cnt,good_pct_avg1,last_dur,abc_pct_avg2,ct_lt1m_pct_max,is_freepolicy from qr001 t2"
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelDataProcessGetModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        modelcode:
          type: string
          required: true
          description: The model's code.
          default: "test_data"
        modelvers:
          type: string
          required: true
          description: The model's version.
          default: "v1.0.1"
        locflag:
          type: number
          description: The rule's code.
          default: 1
        sql_statement:
          type: string
          description: The rule's .
          default: "select ct_max_avg,res_status,thk_ab_cnt,good_pct_avg1,last_dur,abc_pct_avg2,ct_lt1m_pct_max,is_freepolicy from qr001 t2"
        enable:
          type: number
          required: true
          description: The rule's .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "NO0000001"
    """


@register_swagger_model
class ModelDataProcessDeleteModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: number
              required: true
              description: The model's code.
              default: ""
    """


@register_swagger_model
class ModelDataProcessPatchModel:
    """
        ---
        type: object
        description: Post model representation
        properties:
            id:
              type: number
              required: true
              description: The model's code.
              default: ""
            content:
              type: object
              required: true
              description: The model's code.
              default: {"rlcode": "CRKOMDCLMXXX1V1", "sn": 1, "sqlstmt": "xxxxxx", "operator": "SZxxxxxx"}
    """
