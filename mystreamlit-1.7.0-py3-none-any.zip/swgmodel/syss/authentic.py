from tornado_swagger.model import register_swagger_model

@register_swagger_model
class RegisterModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        aduser:
          type: string
          required: true
          description: The aduser.
          default: "admin"
        username:
          type: string
          required: true
          description: The username.
          default: "admin"
        cname:
          type: string
          required: true
          description: The china name.
          default: "管理员"
        role:
          type: number
          description: The role.
          default: 1
        enable:
          type: number
          required: true
          description: The enable .
          default: 1
        operator:
          type: string
          required: true
          description: The operator's ID.
          default: "SZW201208"
    """
@register_swagger_model
class LoginModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        username:
          type: string
          required: true
          description: The username.
          default: "admin"
        password:
          type: string
          required: true
          description: The password.
          default: "admin"
    """