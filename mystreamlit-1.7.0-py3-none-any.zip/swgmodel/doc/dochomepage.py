from tornado_swagger.model import register_swagger_model

@register_swagger_model
class DocHomePageModel:
    """
    ---
    type: object
    description: Post model representation
    """


@register_swagger_model
class DocHomePageGetModel:
    """
    ---
    type: object
    description: Post model representation
    """



