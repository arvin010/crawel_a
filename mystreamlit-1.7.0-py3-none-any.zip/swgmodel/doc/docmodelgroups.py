from tornado_swagger.model import register_swagger_model

@register_swagger_model
class DocModelGroupsModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        start_time:
          type: string
          required: true
          description: The model's code.
          default: "2021-07-07 00:00:00"
        end_time:
          type: string
          required: true
          description: The model's code.
          default: "2021-07-12 23:59:59"
    """


@register_swagger_model
class DocModelGroupsGetModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        start_time:
          type: string
          required: true
          description: The model's code.
          default: "2021-07-07 00:00:00"
        end_time:
          type: string
          required: true
          description: The model's version.
          default: "2021-07-12 23:59:59"
    """


