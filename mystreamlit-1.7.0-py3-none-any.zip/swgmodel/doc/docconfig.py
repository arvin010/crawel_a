from tornado_swagger.model import register_swagger_model

@register_swagger_model
class DocConfigModel:
    """
    ---
    type: object
    description: Post model representation
    """


@register_swagger_model
class DocConfigGetModel:
    """
    ---
    type: object
    description: Post model representation
    """



