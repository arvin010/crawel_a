from tornado_swagger.model import register_swagger_model


@register_swagger_model
class ResultModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        result:
          type: boolean
          description: result for api.
          default: true
        message:
          type: string
          description: The api's code info.
          default: "successful"
        context:
          type: object
          default: {}
        warning:
          type: string
          default: null

    """


@register_swagger_model
class ResultServiceModel:
    """
    ---
    type: object
    description: Post model representation
    properties:
        result:
          type: boolean
          description: result for api.
          default: true
        message:
          type: string
          description: The api's code info.
          default: "successful"
        context:
          type: object
          default: {"phone": "1308190ITTP", "last_dur": 2046.0, "result": "T9"}
        warning:
          type: string
          default: null

    """
