#! /usr/bin/env python
# -*- coding=utf-8 -*-
import sys
import traceback
from dcclog import DccLog
from dcchdp import DccHbase,DccHbase2
from dccfile import ConfigFile

class HbaseReader:

    ENCODING = 'utf-8'

    def __init__(self):
        try:
            self._log = DccLog()
            self._hbase = DccHbase()
            self._configfile = ConfigFile()
            self.__config = self._configfile.get_all_config_file()

        except Exception as e:
            self._log.raiseError(sys._getframe().f_code.co_name, e, traceback.format_exc())

    def hbase_reader(self,tablename,rows,columns,tbds_user = None,tbds_id = None,tbds_key = None,dtypes = None):
        try:
            if tbds_user is None:
                tbds_user = self.__config['tbds']['tbds_user']

            if tbds_id is None:
                tbds_id = self.__config['tbds']['tbds_id']

            if tbds_key is None:
                tbds_key = self.__config['tbds']['tbds_key']

            self._hbase.tbds_auth(tbds_user,tbds_id,tbds_key)
            # rest=[{key:eval(f'''{dtypes[f"{key}"]}("{value}")''') if value else value if value and dtypes[f"{key}"] not in ['int','float'] else eval(f'''{dtypes[f"{key}"]}("{0}")''') for key,value in row.items() } for row in hbase_data]
            hbase_data=self._hbase.get_rows(tablename,rows,columns,dtypes=dtypes)
            # hbase_data=self._hbase.get_row(tablename,rows)
            rest=[{key:None if  value =='@null@'  else value for key,value in row.items() } for row in hbase_data]
            rest=[{key:eval(f'''{dtypes[f"{key}"]}("{value}")''') if value and dtypes.get(f"{key}",None) else value for key,value in row.items() } for row in rest]
            return rest
        except Exception as e:
            self._log.raiseError(sys._getframe().f_code.co_name, e, traceback.format_exc())

    def prd(self):
        _hbase = HbaseReader()
        rows = ",000082568826,000083092196,00008374540"
        df = _hbase.hbase_reader('mdsv:n001_new_year_sn', rows=rows, columns='AGE,ANP_ACT,ANP_ROPPA,HOLDER_CUST_NO,LAST_DUR,PHONE,POL_CNT_AH,POL_CNT_ROPDD,TENURE')


class HbaseReader2:

    ENCODING = 'utf-8'

    def __init__(self):
        try:
            self._log = DccLog()
            self._hbase = DccHbase2()
            self._configfile = ConfigFile()
            self.__config = self._configfile.get_all_config_file()

        except Exception as e:
            self._log.raiseError(sys._getframe().f_code.co_name, e, traceback.format_exc())

    def hbase_reader(self,tablename,rows,columns,dtypes = None):
        try:
            hbase_data=self._hbase.get_rows(tablename,rows,columns,dtypes = dtypes)
            # hbase_data=self._hbase.get_row(tablename,rows)
            rest=[{key:None if  value =='@null@'  else value for key,value in row.items() } for row in hbase_data]
            rest=[{key:eval(f'''{dtypes[f"{key}"]}("{value}")''')  if value and dtypes.get(f"{key}",None)  else value for key,value in row.items() } for row in rest]
            return rest
        except Exception as e:
            self._log.raiseError(sys._getframe().f_code.co_name, e, traceback.format_exc())

if __name__ == '__main__':
    _hbase_reader = HbaseReader2()
    _hbase_data_list = _hbase_reader.hbase_reader(tablename = 'apps_ds:crim_claim_model_policy_customer_api',
                                    rows = '0000000003',
                                    columns = 'RGT_PAY_CNT,MAX_FACE_AMOUNT_CUST,AVG_ANP_CUST',
                                    dtypes = {'AVG_ANP_CUST': 'float', 'MAX_FACE_AMOUNT_CUST': 'float', 'RGT_PAY_CNT': 'int'})
    print(_hbase_data_list)
