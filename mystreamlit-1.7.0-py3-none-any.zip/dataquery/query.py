#! /usr/bin/env python
# -*- coding=utf-8 -*-

import json
import sys
import time
import platform
import asyncio
if platform.system().lower()=="windows":
    from func_timeout import func_set_timeout as timeout
elif platform.system().lower()=="linux":
    from timeout_decorator import timeout


class Query():
    def __init__(self):
        self._result = {}

    @timeout(5)
    def query(self, input_params, md, ruuid):
        query_params_list = md['model_params_query']
        _query_data = {}
        for query_params in query_params_list:
            query_datasource = query_params['ds']
            if query_datasource[0]['dstype'] == 'hbase':
                from dataquery.hbasequery import HbaseReader2 as HbaseReader
                _hbase_reader = HbaseReader()
                _hbase_data_list = _hbase_reader.hbase_reader(tablename=query_params['table_name'],
                                                              rows=input_params['params'][
                                                                  query_params['where_condition']],
                                                              columns=query_params['cols'],
                                                              dtypes=json.loads(
                                                                  query_params['datatype'].replace("'", '"')) if
                                                              query_params['datatype'] else None)
                try:
                    if query_params['isreq'] == 1 and not _hbase_data_list:
                        self._result['code'] = 'QR001'
                        self._result['context'] = f"{input_params['rlcode']}:{query_params['qrcode']} query result is empty,rowkey = {input_params['params'][query_params['where_condition']]}"
                        return self._result
                    else:
                        _query_data[query_params['qrcode']] = _hbase_data_list
                except Exception as err:
                    self._result['code'] = 'QR002'
                    self._result['context'] = f"{input_params['modelcode']}:{err} query err"
            self._result['code'] = '0'
            self._result['context'] = _query_data
            return self._result

    def if_query_data(self, md):
        _cnt = md['model_params_query']
        if len(_cnt) > 0:
            return True
        else:
            return False


if __name__ == '__main__':
    md = {'model_params': [2], 'model_param_rules': [3], 'model_params_query': [2], 'datasource': [1],
          'model_dataprocess': [2], 'model_files': [2, 3, 4], 'model_release': [2]}

    s = Query().query(
        input_params={'modelcode': 'face_recognition', 'modelvers': 'v1.0.1', 'params': {'phone': '1308190ITTP', }},
        md=md)
    print(s)
