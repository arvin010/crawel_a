import requests
import json

# ip="10.142.115.57"
ip = "10.142.145.185"
# ip = "10.141.157.135"


def sign(username, password):
    r = requests.post(f'http://{ip}/api/v2.0.2/login',
                      data=json.dumps({"username": username, "password": password}))
    # print(json.loads(r.text))
    return {'sessions': username, 'authorities': json.loads(r.text).get('context').get(username)}


def api(token, datas):
    headers = {"Proxy-Connection": "keep-alive",
               "Pragma": "no-cache",
               "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36",
               "Accept-Language": "zh-CN,zh;q=0.8,en-US;q=0.6,en;q=0.4",
               "Referer": "www.xxx.com",
               "Accept-Charset": "gb2312,gbk;q=0.7,utf-8;q=0.7,*;q=0.7",
               "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
               "Accept-Encoding": "gzip, deflate, sdch",
               "Cache-Control": "max-age=0",
               "Connection": "keep-alive",
               "Content-Type": "application/x-www-form-urlencoded",
               "Host": "127.0.0.1",
               "Upgrade-Insecure-Requests": "1",
               "X-Requested-With": "XMLHttpRequest"}
    headers.update(token)
    # print(1111111111111111,headers)
    r = requests.session().post(
        f'http://{ip}/api/v2.0.2/modelservice', headers=headers, data=json.dumps(datas))
    print(1111111111111111, r.text)
    return json.loads(r.text)


if __name__ == '__main__':
    token = sign(username='szw201208', password='Sxx999999')
    print(token)
    # token={'sessions':'token_core','authorities':'cc7bc479accfffb89408e68f9f1778a4cef6e5d98a8c8990cbd2ed2cc3f4f1e85b1e3683ef03a38c351fd2317c987f0c695d4f3b756388d4d62528891ffa7578'}
    datas = [{"rlcode": "cpebadwbkxxx_CRIM18_v1", "params": {"dt_f": "1"}}]
    result = api(token=token, datas=datas)
    print(result)
