#!/usr/bin/env python
# coding=utf-8
import uuid
from multiprocessing import Process,Pool
from inputparser.modelparams import ModelParams
from inputparser.parameterrule import paramRuleCheck
from dataquery.query import Query
from dataprocess.dataprocess import DataProcess
from filepackage.modelfiles import ModelFiles
from modelcall.modelcall import *
import pandas as pd
# from  numba import jit
from lib.metadata import Metadata
from lib.com import value_datatype_transf


class model():

    async def runs(self,input_params,ruuid,filename=None):
        rest = {}

        # step1  load_md
        md = Metadata().get_md(input_params['rlcode'],ruuid=ruuid)
        if not md:
            rest['code']='LM001'
            return rest

        # step2  load modelfile
        rest = ModelFiles().model_files(md=md,ruuid=ruuid)

        if rest['code'] !='0':
            return rest
        else:
            filename=rest['modelfile'][0]
            filetype=rest['modelfile'][0].split('.')[-1]

        # step3 params check
        rest = ModelParams().model_params(input_params,md=md,ruuid=ruuid)
        if rest['code'] != '0':
            return rest
        else:
            isreq_model_params_list = rest['isformodel']

        # step3 params rule check
        rest = paramRuleCheck().param_rule_check(input_params,md=md,ruuid=ruuid)
        if rest['code'] != '0':
            return rest

        # step4 query data
        _query = Query()
        if _query.if_query_data(md=md):
            try:
                rest = _query.query(input_params,md=md,ruuid=ruuid)
            except :
                raise ValueError("connect HBASE time out ...")
            if rest['code'] == '0':
                _query_data = rest['context']
            else:
                return rest
        else:
            _query_data = {}

        # step5 dataprocess`
        if filetype in ['m','ppd']:
            _data_process = DataProcess()
            api_isreq_model = {param: value for param, value in input_params['params'].items() if param in isreq_model_params_list}
            if _data_process.if_data_process(input_params,1,md=md,ruuid=ruuid):
                datals = [input_params['params']]
                tabname_list = ['api']
                datals.extend(_query_data.values())
                tabname_list.extend(_query_data.keys())
                model_data = _data_process.data_process(input_params,datals,md=md,locflag=1,tabname_list = tabname_list,ruuid=ruuid)['context']
                model_data.update(api_isreq_model)
                model_data=[model_data]
            else:
                for row in _query_data.values():
                    if len(row)>1:
                        rest['warning']='multiple pieces of data'
                        api_isreq_model.update(row[0])
                    elif row:
                        api_isreq_model.update(row[0])

                model_data=[api_isreq_model]

        # step6 modelcall
        rest= model_call(filename=filename,filetype=filetype,model_data= model_data,ruuid=ruuid)
        if rest['code'] != '0':
            return rest
        else:
            model_output= rest['context']

        # step7 output process
        if _data_process.if_data_process(input_params,locflag=2,md=md,ruuid=ruuid):
            tabname_list = ['output']
            if isinstance(model_output,dict): model_data[0].update(model_output)
            if isinstance(model_output,list):model_data=model_output
            rest = _data_process.data_process(input_params, model_data, locflag=2,md=md, tabname_list=tabname_list,ruuid=ruuid)
        else:
            rest={"context":model_output,'code':'0'}
        return rest



if __name__=="__main__":
    _params1 = {"rlcode": "cvmdtcresxxx1v1",
               "params": {"phone":"1308190ITTP"}
                    }


    _params = {"rlcode": "crkomdclmxxx1v2",
               "params": {"rgtno":"86202006186292",
                            "customerno":"0000000006",
                            "agentcode":"BCD0000002",
                            "min_claimdays":336.0,
                            "hospitalizeddays":11.0,
                            "avg_pol_amnt_prem_pct":0.75,
                            "min_polamnt":250,
                            "accid_age":27.0}

                    }


    res=model().runs(input_params= _params,ruuid=uuid.uuid4())
    print(res)