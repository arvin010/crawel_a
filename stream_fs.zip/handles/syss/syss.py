# -*- coding: utf-8 -*-
# @Author: SZW201208
# @Date:   2022-01-20 17:14:15
# @Last Modified by:   SZW201208
# @Last Modified time: 2022-01-20 17:25:06
from tornado.web import url
from handles import *
from interviews.views import *
