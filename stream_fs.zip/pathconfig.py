# coding:utf-8
HomePath = ''

subPath = {
'szw201208':['1'],


}